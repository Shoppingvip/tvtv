<?php
// کتێبخانەی هاوبەشی PHP API — وەشانێکی PHP ی src/lib (admin، m3u، drive، db)
// پەیوەندی بە داتابەیسی Turso بە HTTP API (Hrana over HTTP — /v2/pipeline)
// بێ هیچ کتێبخانەیەکی دەرەکی — تەنها cURL — بۆ هۆستی وەک InfinityFree

// ─────────────────────────────── ڕێکخستن ───────────────────────────────

function iptv_config(): array
{
    static $cfg = null;
    if ($cfg !== null) return $cfg;
    $cfg = require __DIR__ . '/config.php';
    if (!is_array($cfg)) $cfg = [];
    return $cfg;
}

function turso_url(): string
{
    $u = trim((string)(iptv_config()['turso_url'] ?? ''));
    if ($u === '' || strpos($u, 'YOUR_') === 0) {
        json_out(['error' => 'داتابەیس ڕێک نەخراوە — فایلی api/config.php بکەرەوە و ناونیشانی Turso و توکن دابنێ'], 500);
    }
    if (stripos($u, 'libsql://') === 0) $u = 'https://' . substr($u, 10);
    return rtrim($u, '/');
}

function turso_token(): string
{
    return trim((string)(iptv_config()['turso_token'] ?? ''));
}

// ─────────────────────────────── وەڵامەکان ───────────────────────────────

function send_cors(): void
{
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET,POST,PUT,PATCH,DELETE,OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Admin-Token');
    header('Access-Control-Max-Age: 86400');
}

function json_out($data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    send_cors();
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

// داواکاری preflight (OPTIONS) — پێش هەموو endpoint ەکان بانگ دەکرێت
function handle_preflight(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
        http_response_code(204);
        send_cors();
        exit;
    }
}

function body_json(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || $raw === '') return [];
    $d = json_decode($raw, true);
    return is_array($d) ? $d : [];
}

function trim_str($v): string
{
    return trim((string)($v ?? ''));
}

function trim_null($v): ?string
{
    $s = trim((string)($v ?? ''));
    return $s === '' ? null : $s;
}

// ─────────────────────────────── Turso HTTP ───────────────────────────────

// بەهای PHP → بەهای Hrana
function hval($v): array
{
    if ($v === null) return ['type' => 'null'];
    if (is_bool($v)) return ['type' => 'integer', 'value' => $v ? '1' : '0'];
    if (is_int($v)) return ['type' => 'integer', 'value' => (string)$v];
    if (is_float($v)) return ['type' => 'float', 'value' => (string)$v];
    return ['type' => 'text', 'value' => (string)$v];
}

// خانەی وەڵام → بەهای PHP
function hcell($c)
{
    if (!is_array($c)) return $c;
    $t = isset($c['type']) ? (string)$c['type'] : 'text';
    if ($t === 'null') return null;
    $v = isset($c['value']) ? $c['value'] : null;
    if ($t === 'integer') return (int)$v;
    if ($t === 'float') return (float)$v;
    if ($t === 'blob') return $v;
    return (string)$v;
}

function turso_net_msg(string $err, int $eno): string
{
    if ($eno === CURLE_OPERATION_TIMEDOUT || strpos($err, 'timed out') !== false) {
        return 'وەڵام نەگەڕایەوە — داتابەیسەکە خاوە یان بەستەرەکە هەڵەیە';
    }
    if ($eno === CURLE_COULDNT_RESOLVE_HOST || strpos($err, 'Could not resolve') !== false) {
        return 'ناونیشانی داتابەیس هەڵەیە — فایلی config.php پشکنین بکە';
    }
    if (stripos($err, 'certificate') !== false || stripos($err, 'ssl') !== false) {
        return 'کێشەی گوێپاراستن (SSL) لە پەیوەندی بە داتابەیسدا';
    }
    return 'پەیوەندی بە داتابەیس نەکرا: ' . $err;
}

/**
 * ناردنی چەند داواکارییەک بۆ Turso بە یەک داواکاری HTTP
 * $stmts = [ ['sql' => '...', 'args' => [...]], ... ]
 * گەڕانەوە: ئەنجامەکانی pipeline
 */
function turso_pipeline(array $stmts): array
{
    if (count($stmts) === 0) return [];
    $reqs = [];
    foreach ($stmts as $st) {
        $args = isset($st['args']) && is_array($st['args']) ? $st['args'] : [];
        $reqs[] = [
            'type' => 'execute',
            'stmt' => [
                'sql'  => (string)$st['sql'],
                'args' => array_map('hval', array_values($args)),
            ],
        ];
    }
    $ch = curl_init(turso_url() . '/v2/pipeline');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode(['requests' => $reqs], JSON_UNESCAPED_UNICODE),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . turso_token(),
        ],
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT        => 60,
        CURLOPT_FOLLOWLOCATION => true,
    ]);
    $res = curl_exec($ch);
    if ($res === false) {
        $err = curl_error($ch);
        $eno = curl_errno($ch);
        curl_close($ch);
        throw new RuntimeException(turso_net_msg($err, $eno));
    }
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);
    $data = json_decode((string)$res, true);
    if ($code === 401 || $code === 403) {
        throw new RuntimeException('توکنی داتابەیس هەڵەیە یان کۆتایی هاتووە — فایلی config.php پشکنین بکە');
    }
    if (!is_array($data) || !isset($data['results']) || !is_array($data['results'])) {
        throw new RuntimeException('وەڵامی داتابەیس نەگونجا (HTTP ' . $code . ') — ناونیشان و توکن پشکنین بکە');
    }
    foreach ($data['results'] as $r) {
        if (is_array($r) && ($r['type'] ?? '') === 'error') {
            $msg = isset($r['error']['message']) ? (string)$r['error']['message'] : 'هەڵەی داتابەیس';
            throw new RuntimeException('داتابەیس: ' . $msg);
        }
    }
    return $data['results'];
}

function turso_rows(string $sql, array $args = []): array
{
    $results = turso_pipeline([['sql' => $sql, 'args' => $args]]);
    $r = isset($results[0]) ? $results[0] : null;
    $res = (is_array($r) && isset($r['response']['result'])) ? $r['response']['result'] : null;
    if (!is_array($res)) return [];
    $cols = [];
    foreach (($res['cols'] ?? []) as $c) {
        $cols[] = (string)(is_array($c) && isset($c['name']) ? $c['name'] : '');
    }
    $out = [];
    foreach (($res['rows'] ?? []) as $row) {
        if (!is_array($row)) continue;
        $o = [];
        foreach ($row as $i => $cell) {
            $name = isset($cols[$i]) && $cols[$i] !== '' ? $cols[$i] : 'c' . $i;
            $o[$name] = hcell($cell);
        }
        $out[] = $o;
    }
    return $out;
}

function turso_one(string $sql, array $args = []): ?array
{
    $rows = turso_rows($sql, $args);
    return isset($rows[0]) ? $rows[0] : null;
}

function turso_exec(string $sql, array $args = []): void
{
    turso_pipeline([['sql' => $sql, 'args' => $args]]);
}

function turso_scalar(string $sql, array $args = [])
{
    $row = turso_one($sql, $args);
    if ($row === null || count($row) === 0) return null;
    $first = array_values($row);
    return $first[0];
}

// ─────────────────────────────── خشتەکان ───────────────────────────────

// دروستکردنی خشتەکان ئەگەر نەبوون — هاوشێوەی src/instrumentation.ts
function ensure_schema(): void
{
    static $done = false;
    if ($done) return;
    $ddl = [
        "CREATE TABLE IF NOT EXISTS \"Settings\" (\"id\" TEXT NOT NULL PRIMARY KEY DEFAULT 'main', \"appName\" TEXT NOT NULL DEFAULT 'تیڤی ئەپی من', \"adminPin\" TEXT, \"xtreamHost\" TEXT, \"xtreamUsername\" TEXT, \"xtreamPassword\" TEXT, \"m3uUrl\" TEXT, \"updatedAt\" DATETIME NOT NULL)",
        "CREATE TABLE IF NOT EXISTS \"M3uSource\" (\"id\" TEXT NOT NULL PRIMARY KEY, \"name\" TEXT NOT NULL DEFAULT '', \"url\" TEXT NOT NULL, \"section\" TEXT NOT NULL DEFAULT 'both', \"sortOrder\" INTEGER NOT NULL DEFAULT 0, \"createdAt\" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP)",
        "CREATE TABLE IF NOT EXISTS \"Banner\" (\"id\" TEXT NOT NULL PRIMARY KEY, \"name\" TEXT NOT NULL DEFAULT '', \"data\" TEXT NOT NULL, \"sortOrder\" INTEGER NOT NULL DEFAULT 0, \"createdAt\" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP)",
        "CREATE TABLE IF NOT EXISTS \"Product\" (\"id\" TEXT NOT NULL PRIMARY KEY, \"name\" TEXT NOT NULL, \"price\" TEXT NOT NULL DEFAULT '', \"description\" TEXT NOT NULL DEFAULT '', \"image\" TEXT, \"sortOrder\" INTEGER NOT NULL DEFAULT 0, \"createdAt\" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP)",
        "CREATE TABLE IF NOT EXISTS \"Favorite\" (\"id\" TEXT NOT NULL PRIMARY KEY, \"itemType\" TEXT NOT NULL, \"itemId\" TEXT NOT NULL, \"name\" TEXT NOT NULL, \"logo\" TEXT, \"extra\" TEXT, \"createdAt\" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP)",
        "CREATE UNIQUE INDEX IF NOT EXISTS \"Favorite_itemType_itemId_key\" ON \"Favorite\"(\"itemType\", \"itemId\")",
        "CREATE TABLE IF NOT EXISTS \"History\" (\"id\" TEXT NOT NULL PRIMARY KEY, \"itemType\" TEXT NOT NULL, \"itemId\" TEXT NOT NULL, \"name\" TEXT NOT NULL, \"logo\" TEXT, \"extra\" TEXT, \"watchedAt\" DATETIME NOT NULL)",
        "CREATE UNIQUE INDEX IF NOT EXISTS \"History_itemType_itemId_key\" ON \"History\"(\"itemType\", \"itemId\")",
        "CREATE TABLE IF NOT EXISTS \"DriveVideo\" (\"id\" TEXT NOT NULL PRIMARY KEY, \"fileId\" TEXT NOT NULL, \"name\" TEXT NOT NULL, \"folderId\" TEXT, \"folderName\" TEXT, \"thumbnail\" TEXT, \"size\" TEXT, \"sortOrder\" INTEGER NOT NULL DEFAULT 0, \"createdAt\" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP)",
        "CREATE UNIQUE INDEX IF NOT EXISTS \"DriveVideo_fileId_key\" ON \"DriveVideo\"(\"fileId\")",
    ];
    $stmts = [];
    foreach ($ddl as $sql) $stmts[] = ['sql' => $sql, 'args' => []];
    turso_pipeline($stmts);
    // ستوونی driveApiKey — ئەگەر پێشتر نەبوو زیاد دەکرێت (بێ زیان)
    try {
        turso_exec("ALTER TABLE \"Settings\" ADD COLUMN \"driveApiKey\" TEXT");
    } catch (Throwable $e) {
        // پێشتر هەیە — پشتگوێ بخرێت
    }
    $done = true;
}

// ناسنامەی تایبەت — هاوشێوەی cuid ی Prisma
function cuid(): string
{
    return 'c' . dechex((int)(microtime(true) * 1000)) . bin2hex(random_bytes(9));
}

// کاتی ISO UTC — هاوشێوەی new Date().toISOString()
function sql_now(): string
{
    return "strftime('%Y-%m-%dT%H:%M:%fZ','now')";
}

// ─────────────────────────────── دەسەڵاتی بەڕێوەبەر ───────────────────────────────

function admin_token(string $pin): string
{
    return hash('sha256', 'iptv-admin-v1:' . $pin);
}

function settings_row(): array
{
    ensure_schema();
    $s = turso_one("SELECT * FROM \"Settings\" WHERE \"id\" = 'main'");
    if (!$s) {
        turso_exec("INSERT INTO \"Settings\" (\"id\", \"appName\", \"updatedAt\") VALUES ('main', 'تیڤی ئەپی من', " . sql_now() . ")");
        $s = turso_one("SELECT * FROM \"Settings\" WHERE \"id\" = 'main'");
    }
    return is_array($s) ? $s : [];
}

function is_admin(): bool
{
    $s = settings_row();
    if (empty($s['adminPin'])) return false;
    $tok = isset($_COOKIE['iptv_admin']) ? (string)$_COOKIE['iptv_admin'] : '';
    return $tok !== '' && hash_equals(admin_token((string)$s['adminPin']), $tok);
}

function forbidden(): void
{
    json_out(['error' => 'تەنها بەڕێوەبەر دەتوانێت ئەم کردارە بکات — تکایە کۆدی بەڕێوەبەر دابنێ'], 403);
}

function set_admin_cookie(string $pin): void
{
    $val = $pin !== '' ? admin_token($pin) : '';
    $exp = $pin !== '' ? time() + 43200 : time() - 3600; // ١٢ کاتژمێر یان سڕینەوە
    if (PHP_VERSION_ID >= 70300) {
        setcookie('iptv_admin', $val, [
            'expires'  => $exp,
            'path'     => '/',
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    } else {
        setcookie('iptv_admin', $val, $exp, '/');
    }
}

function build_status(bool $admin): array
{
    $s = settings_row();
    $usingXtream = !empty($s['xtreamHost']) && !empty($s['xtreamUsername']) && !empty($s['xtreamPassword']);
    $hasM3u = !empty($s['m3uUrl']) || has_any_source();
    $mode = $usingXtream ? 'xtream' : ($hasM3u ? 'm3u' : null);
    return [
        'configured'        => $mode !== null,
        'appName'           => (string)($s['appName'] ?? 'تیڤی ئەپی من'),
        'mode'              => $mode,
        'host'              => ($admin && $usingXtream) ? (string)$s['xtreamHost'] : null,
        'username'          => ($admin && $usingXtream) ? (string)$s['xtreamUsername'] : null,
        'm3uUrl'            => ($admin && $mode === 'm3u') ? (isset($s['m3uUrl']) ? (string)$s['m3uUrl'] : null) : null,
        'hasAdminPin'       => !empty($s['adminPin']),
        'isAdmin'           => $admin,
        'expiryDate'        => null,
        'activeConnections' => null,
        'maxConnections'    => null,
        'status'            => null,
    ];
}

// ─────────────────────────────── M3U ───────────────────────────────

function ensure_migrated(): void
{
    $c = turso_one("SELECT COUNT(*) AS n FROM \"M3uSource\"");
    if ((int)($c ? $c['n'] : 0) > 0) return;
    $s = settings_row();
    if (empty($s['m3uUrl'])) return;
    turso_exec(
        "INSERT INTO \"M3uSource\" (\"id\", \"name\", \"url\", \"section\", \"sortOrder\") VALUES (?, 'لیستی سەرەکی', ?, 'both', 0)",
        [cuid(), (string)$s['m3uUrl']]
    );
}

function list_sources(): array
{
    ensure_migrated();
    return turso_rows("SELECT * FROM \"M3uSource\" ORDER BY \"sortOrder\" ASC, \"createdAt\" ASC");
}

function has_any_source(): bool
{
    ensure_migrated();
    $c = turso_one("SELECT COUNT(*) AS n FROM \"M3uSource\"");
    return (int)($c ? $c['n'] : 0) > 0;
}

function parse_m3u(string $text): array
{
    $lines = preg_split('/\r?\n/', $text);
    $channels = [];
    $pending = null;
    if (!is_array($lines)) return $channels;
    foreach ($lines as $raw) {
        $line = trim((string)$raw);
        if ($line === '') continue;
        if (strpos($line, '#EXTINF') === 0) {
            $pos = strrpos($line, ',');
            $name = trim(substr($line, $pos === false ? 0 : $pos + 1));
            $logo = preg_match('/tvg-logo="([^"]*)"/', $line, $m) ? $m[1] : '';
            $group = preg_match('/group-title="([^"]*)"/', $line, $m) ? $m[1] : '';
            $tvgId = preg_match('/tvg-id="([^"]*)"/', $line, $m) ? $m[1] : '';
            $pending = [
                'name'  => $name !== '' ? $name : 'بێ ناو',
                'logo'  => $logo,
                'group' => $group !== '' ? $group : 'گشتی',
                'tvgId' => $tvgId,
            ];
        } elseif ($line[0] !== '#' && $pending !== null) {
            $url = $line;
            $kind = 'live';
            if (preg_match('/\/movie\//i', $url)) $kind = 'movie';
            elseif (preg_match('/\/series\//i', $url)) $kind = 'series';
            $channels[] = [
                'name'  => $pending['name'] !== '' ? $pending['name'] : 'بێ ناو',
                'logo'  => $pending['logo'] !== '' ? $pending['logo'] : '',
                'group' => $pending['group'] !== '' ? $pending['group'] : 'گشتی',
                'url'   => $url,
                'tvgId' => $pending['tvgId'] !== '' ? $pending['tvgId'] : '',
                'kind'  => $kind,
            ];
            $pending = null;
        }
    }
    return $channels;
}

// ─────────────────────────────── HTTP ───────────────────────────────

/**
 * داواکاری GET بە cURL — بۆ لیستی M3U، Xtream، Drive
 * گەڕانەوە: ['status', 'body', 'final_url', 'content_type', 'error']
 */
function http_get(string $url, int $timeout, array $extraHeaders = [], bool $followRedirects = true): array
{
    $hdrs = ['User-Agent: Mozilla/5.0 (IPTV Web Player)'];
    foreach ($extraHeaders as $k => $v) $hdrs[] = $k . ': ' . $v;
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => $hdrs,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT        => $timeout,
        CURLOPT_FOLLOWLOCATION => $followRedirects,
        CURLOPT_MAXREDIRS      => 6,
    ]);
    $res = curl_exec($ch);
    $err = $res === false ? curl_error($ch) : '';
    $eno = $res === false ? curl_errno($ch) : 0;
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $ct = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    $final = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    curl_close($ch);
    return [
        'status'       => $code,
        'body'         => (string)$res,
        'final_url'    => $final,
        'content_type' => $ct,
        'error'        => $err,
        'errno'        => $eno,
    ];
}

// وەرگێڕانی هەڵەی تۆڕ بۆ کوردی — هاوشێوەی netErrMsg لە کۆدەکەدا
function net_msg(array $r): string
{
    if (!empty($r['error'])) {
        $e = (string)$r['error'];
        if (strpos($e, 'timed out') !== false || strpos($e, 'Timeout') !== false) {
            return 'وەڵام نەگەڕایەوە — سێرڤەرەکە خاوە یان داخڵە';
        }
        if (strpos($e, 'Could not resolve') !== false || strpos($e, 'getaddrinfo') !== false) {
            return 'نەکرا پەیوەندی بە سێرڤەرەکە بکرێت — ناونیشانەکە پشکنین بکە';
        }
        if (strpos($e, 'refused') !== false) {
            return 'سێرڤەرەکە ڕەتی کردەوە — پۆرتەکە هەڵەیە لەوانەیە';
        }
        if (stripos($e, 'certificate') !== false || stripos($e, 'ssl') !== false) {
            return 'کێشەی گوێپاراستن (SSL) لە سێرڤەرەکەدا هەیە';
        }
        return $e;
    }
    return 'پەیوەندی نەکرا';
}

// ─────────────────────────────── کاش ───────────────────────────────

function cache_dir(): string
{
    $cfg = iptv_config();
    $dir = trim((string)($cfg['cache_dir'] ?? ''));
    if ($dir === '') $dir = sys_get_temp_dir() . '/iptv-cache';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    return $dir;
}

function cache_get(string $key): ?array
{
    $f = cache_dir() . '/' . md5($key) . '.json';
    if (!is_file($f)) return null;
    $d = json_decode((string)@file_get_contents($f), true);
    return is_array($d) ? $d : null;
}

function cache_set(string $key, $data): void
{
    $f = cache_dir() . '/' . md5($key) . '.json';
    @file_put_contents($f, json_encode(['at' => time(), 'data' => $data], JSON_UNESCAPED_UNICODE), LOCK_EX);
}

// ─────────────────────────────── Xtream ───────────────────────────────

function ttl_for_action(string $action): ?int
{
    if (preg_match('/^get_(live|vod|series)_categories$/', $action)) return 10 * 60;
    if ($action === 'get_live_streams' || $action === 'get_vod_streams' || $action === 'get_series') return 10 * 60;
    if ($action === 'get_vod_info' || $action === 'get_series_info') return 5 * 60;
    if ($action === 'get_short_epg' || $action === 'get_simple_data_table') return 60;
    return null;
}

function test_xtream(string $host, string $username, string $password): array
{
    $base = rtrim($host, '/');
    if (!preg_match('/^https?:\/\//i', $base)) {
        throw new RuntimeException('ناونیشانی سێرڤەر دەبێت بە http:// یان https:// دەست پێبکات');
    }
    $url = $base . '/player_api.php?username=' . rawurlencode($username) . '&password=' . rawurlencode($password);
    $r = http_get($url, 15);
    if (!empty($r['error'])) throw new RuntimeException(net_msg($r));
    if ($r['status'] < 200 || $r['status'] >= 300) throw new RuntimeException('وەڵامی سێرڤەر نەگەڕایەوە');
    $data = json_decode($r['body'], true);
    if (!is_array($data) || !isset($data['user_info']) || (int)($data['user_info']['auth'] ?? 0) !== 1) {
        throw new RuntimeException('زانیارییەکان هەڵەن — ناساندنی بەکارهێنەر سەرکەوتوو نەبوو');
    }
    $u = $data['user_info'];
    $exp = null;
    if (!empty($u['exp_date'])) {
        $ts = (int)$u['exp_date'];
        if ($ts > 0) $exp = gmdate('Y-m-d\TH:i:s', $ts) . '.000Z';
    }
    return [
        'expiryDate'        => $exp,
        'activeConnections' => isset($u['active_cons']) ? (string)$u['active_cons'] : null,
        'maxConnections'    => isset($u['max_connections']) ? (string)$u['max_connections'] : null,
        'status'            => isset($u['status']) ? (string)$u['status'] : null,
    ];
}
