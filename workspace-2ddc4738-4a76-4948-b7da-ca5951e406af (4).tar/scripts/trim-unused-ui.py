#!/usr/bin/env python3
# دیاریکردنی کامپۆنێنتە بێکاردەکانی ui — بە بەدواداچوونی هەموو import-ەکان
import os, re

root = '/tmp/deploy-stage'
ui_dir = os.path.join(root, 'src/components/ui')
src_dir = os.path.join(root, 'src')

all_ui = {os.path.splitext(f)[0] for f in os.listdir(ui_dir) if f.endswith('.tsx')}

used = set()
pat = re.compile(r"components/ui/([a-zA-Z0-9-]+)")

for dp, dn, fn in os.walk(src_dir):
    for f in fn:
        if not f.endswith(('.tsx', '.ts')):
            continue
        p = os.path.join(dp, f)
        if os.path.normpath(p).startswith(os.path.normpath(ui_dir)):
            continue
        with open(p) as fh:
            txt = fh.read()
        for m in pat.finditer(txt):
            if m.group(1) in all_ui:
                used.add(m.group(1))

# داخڵکردنی پشتبەستنەکانی ناوخۆیی ui (./button)
changed = True
while changed:
    changed = False
    for name in list(used):
        f = os.path.join(ui_dir, name + '.tsx')
        if not os.path.exists(f):
            continue
        with open(f) as fh:
            txt = fh.read()
        for m in re.finditer(r"from ['\"]\./([a-zA-Z0-9-]+)['\"]", txt):
            if m.group(1) in all_ui and m.group(1) not in used:
                used.add(m.group(1))
                changed = True

unused = sorted(all_ui - used)
print('USED:', sorted(used))
print('UNUSED COUNT:', len(unused))
for u in unused:
    os.remove(os.path.join(ui_dir, u + '.tsx'))
print('سڕایەوە — ماوە:', len(os.listdir(ui_dir)))
