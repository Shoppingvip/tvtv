import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { isAdminRequest, forbidden } from '@/lib/admin'

export const dynamic = 'force-dynamic'

// مارکێت — کاڵاکانی فرۆشتن
// GET — بۆ هەمووان (تەماشاکەریش دەتوانێت کاڵاکان ببینێت)
export async function GET() {
  try {
    const items = await db.product.findMany({
      orderBy: [{ sortOrder: 'asc' }, { createdAt: 'desc' }],
      select: { id: true, name: true, price: true, description: true, image: true },
    })
    return NextResponse.json({ items })
  } catch {
    return NextResponse.json({ items: [] })
  }
}

// POST — زیادکردنی کاڵا (تەنها بەڕێوەبەر)
export async function POST(req: NextRequest) {
  try {
    if (!(await isAdminRequest(req))) return forbidden()

    const body = (await req.json()) as {
      name?: string
      price?: string
      description?: string
      image?: string
    }
    const name = (body.name ?? '').trim()
    const price = (body.price ?? '').trim()
    const description = (body.description ?? '').trim()
    const image = (body.image ?? '').trim() || null

    if (!name) {
      return NextResponse.json({ error: 'ناوی کاڵا پێویستە' }, { status: 400 })
    }
    if (name.length > 120) {
      return NextResponse.json({ error: 'ناوی کاڵا زۆر درێژە' }, { status: 400 })
    }
    if (description.length > 2000) {
      return NextResponse.json({ error: 'وردەکارییەکە زۆر درێژە' }, { status: 400 })
    }
    if (price.length > 60) {
      return NextResponse.json({ error: 'نرخەکە زۆر درێژە' }, { status: 400 })
    }
    // وێنە — دەبێت data URL بێت
    if (image) {
      if (!/^data:image\/(png|jpe?g|webp|gif);base64,[A-Za-z0-9+/=]+$/.test(image)) {
        return NextResponse.json({ error: 'فایلەکە وێنە نییە (PNG، JPG، WEBP یان GIF)' }, { status: 400 })
      }
      // سنووری قەبارە — ٢.٥ مێگابایت
      if (image.length > 2_500_000) {
        return NextResponse.json({ error: 'قەبارەی وێنەکە زۆر گەورەیە — وێنەی بچووکتر هەڵبژێرە' }, { status: 400 })
      }
    }

    const count = await db.product.count()
    if (count >= 500) {
      return NextResponse.json({ error: 'ژمارەی کاڵا گەیشتووەتە سنوور — تکایە کاڵای کۆن بسڕەوە' }, { status: 400 })
    }

    const product = await db.product.create({
      data: {
        name,
        price: price.slice(0, 60),
        description: description.slice(0, 2000),
        image,
        sortOrder: count,
      },
    })
    return NextResponse.json({ ok: true, id: product.id })
  } catch {
    return NextResponse.json({ error: 'هەڵەیەک ڕوویدا لە زیادکردنی کاڵا' }, { status: 500 })
  }
}

// DELETE — سڕینەوەی کاڵا (تەنها بەڕێوەبەر) — ?id=xxx یان ?id=ALL
export async function DELETE(req: NextRequest) {
  try {
    if (!(await isAdminRequest(req))) return forbidden()

    const id = new URL(req.url).searchParams.get('id') ?? ''
    if (id === 'ALL') {
      await db.product.deleteMany({})
      return NextResponse.json({ ok: true })
    }
    if (!id) return NextResponse.json({ error: 'ناسنامەی کاڵا نەنێردرا' }, { status: 400 })
    await db.product.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'هەڵەیەک ڕوویدا لە سڕینەوەی کاڵا' }, { status: 500 })
  }
}
