<?php
// دڵخوازەکان — وەشانێکی PHP ی src/app/api/favorites/route.ts
require __DIR__ . '/lib.php';
handle_preflight();

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// ---- GET — لیستی دڵخوازەکان (تەنها بەڕێوەبەر) ----
if ($method === 'GET') {
    try {
        if (!is_admin()) forbidden();
        $items = turso_rows("SELECT * FROM \"Favorite\" ORDER BY \"createdAt\" DESC");
        json_out(['items' => $items]);
    } catch (Throwable $e) {
        json_out(['error' => 'هەڵە لە خوێندنەوەی دڵخوازەکان'], 500);
    }
}

// ---- POST — زیادکردن/لابردن (تۆگل) ----
if ($method === 'POST') {
    try {
        if (!is_admin()) forbidden();
        $body = body_json();
        $itemType = trim_str($body['itemType'] ?? '');
        $itemId = trim_str($body['itemId'] ?? '');
        $name = trim_str($body['name'] ?? '');
        if ($itemType === '' || $itemId === '' || $name === '') {
            json_out(['error' => 'زانیاری ناتەواو'], 400);
        }
        $logo = trim_null($body['logo'] ?? null);
        $extra = trim_null($body['extra'] ?? null);

        $existing = turso_one("SELECT \"id\" FROM \"Favorite\" WHERE \"itemType\" = ? AND \"itemId\" = ?", [$itemType, $itemId]);
        if ($existing) {
            turso_exec("DELETE FROM \"Favorite\" WHERE \"id\" = ?", [$existing['id']]);
            json_out(['ok' => true, 'added' => false]);
        }
        turso_exec(
            "INSERT INTO \"Favorite\" (\"id\", \"itemType\", \"itemId\", \"name\", \"logo\", \"extra\", \"createdAt\") VALUES (?, ?, ?, ?, ?, ?, " . sql_now() . ")",
            [cuid(), $itemType, $itemId, $name, $logo, $extra]
        );
        json_out(['ok' => true, 'added' => true]);
    } catch (Throwable $e) {
        json_out(['error' => 'هەڵە لە تۆمارکردن'], 500);
    }
}

// ---- DELETE ----
if ($method === 'DELETE') {
    try {
        if (!is_admin()) forbidden();
        $itemType = isset($_GET['itemType']) ? (string)$_GET['itemType'] : '';
        $itemId = isset($_GET['itemId']) ? (string)$_GET['itemId'] : '';
        if ($itemType === 'ALL') {
            turso_exec("DELETE FROM \"Favorite\"");
            json_out(['ok' => true]);
        }
        if ($itemType === '' || $itemId === '') {
            json_out(['error' => 'زانیاری ناتەواو'], 400);
        }
        turso_exec("DELETE FROM \"Favorite\" WHERE \"itemType\" = ? AND \"itemId\" = ?", [$itemType, $itemId]);
        json_out(['ok' => true]);
    } catch (Throwable $e) {
        json_out(['error' => 'هەڵە لە سڕینەوە'], 500);
    }
}

json_out(['error' => 'ڕێگەیەکی نەزانراو'], 405);
