# ڕێنمایی: بڵاوکردنەوەی ئەپەکە لەسەر Tencent Cloud بە دۆمەینی تایبەت

ئەم ڕێنماییە ئەپەکەت دادەنێت لەسەر سێرڤەرێکی Tencent Cloud بە دۆمەینێکی هاوبەش وەک:
`https://tv.dۆمەینەکەت.com` — بە HTTPS، ٢٤ کاتژمێر، و هەموو گۆڕانکارییەک یەکسەر دەگاتە هەموو بەکارهێنەران.

**کاتی پێویست:** ~٣٠–٤٥ خولەک

---

## ⚠️ یەکەم بڕیاری گرنگ: هەرێمی سێرڤەر — هۆنگ کۆنگ هەڵبژێرە!

| | هۆنگ کۆنگ 🇭🇰 | چینی ناوەندی (بێجین/شانگهای...) |
|---|---|---|
| ICP filing (تۆمارکردنی حکومی، چەند هەفتە) | ❌ پێویست نییە ✅ | ⚠️ **ناچارەکەرە** |
| Google Drive کار دەکات؟ | ✅ بەڵێ | ❌ **قەدغەیە** |
| خێرایی بۆ بەکارهێنەری کوردستان | باشە | باشترە بەڵام بێ سوود ئەگەر Drive نەبێت |

**بڕیار: هەرێمی Hong Kong** — چونکە تایبەتمەندی Google Drive-ی ئەپەکە پێویستی بە گەیشتن بە Google هەیە و ICP پێویست نییە.

---

## هەنگاوی ١ — سێرڤەرێک بکڕە (Lighthouse)

1. بڕۆ بۆ **cloud.tencent.com** → هەژمار دروست بکە (بە ئیمەیڵ/فەیسبووک).
2. لە گەڕاندا بنووسە: **Lighthouse** (轻量应用服务器) یان بڕۆ بۆ `cloud.tencent.com/product/lighthouse`.
3. **Create** بکە و ئەمانە هەڵبژێرە:
   - Region: **Hong Kong**
   - Image: **Ubuntu Server 24.04 LTS**
   - Plan: هەر پلانێکی بچووک (2C2G بەسە بۆ دەستپێک)
4. دوای دروستکردن، لە پەڕەی سێرڤەرەکە **Public IP Address** -ەکە کۆپی بکە (وەک `43.128.xx.xx`).
5. لە بەشی **Password/Key** پاسۆردێک بۆ user ی `root` دابنێ.

## هەنگاوی ٢ — دۆمەین بکڕە و بەستی پێوە بکە

1. بڕۆ بۆ **domains.tencent.com** (Domains/域名注册) → دۆمەینێک بگەڕێ و بیکڕە
   (`.com` نزیکەی ¥٧٥/ساڵ، `.xyz` یان `.online` هەرزانترن).
2. بڕۆ بۆ **DNSPod** (`console.dnspod.cn`) → **Add Domain** → دۆمەینەکەت زیاد بکە.
3. دوو تۆمی **A** زیاد بکە کە ڕێنیشان بکەن بۆ IP ی سێرڤەرەکەت:

   | Host | Type | Value |
   |------|------|-------|
   | `@` | A | `43.128.xx.xx` (IP ی سێرڤەر) |
   | `tv` | A | `43.128.xx.xx` |

4. چەند خولەکێک چاوەڕێ بکە (تا ٣٠ خولەک) تا DNS چالاک دەبێت.

## هەنگاوی ٣ — پۆرتەکان بکەرەوە (Firewall)

لە کۆنسۆڵی Lighthouse → سێرڤەرەکەت → **Firewall** tab → ئەم یاسایانە دڵنیابە:

| Port | بۆچی |
|------|------|
| 22 | SSH — بۆ چوونە ژوورەوە |
| 80 | HTTP — بۆ Caddy |
| 443 | HTTPS — بۆ Caddy |

## هەنگاوی ٤ — بچۆ ژوورەوە و ئامرازەکان دابمەزرێنە

لە کۆمپیوتەرەکەت Terminal (یان PowerShell) بکەرەوە:

```bash
ssh root@43.128.xx.xx
```

دوای چوونە ژوورەوە، ئەم فەرمانانە یەک بە یەک جێبەجێ بکە:

```bash
# نوێکردنەوە + ئامرازە بنەڕەتییەکان
apt update && apt install -y unzip curl caddy

# Bun (بۆ کارپێکردنی ئەپەکە)
curl -fsSL https://bun.sh/install | bash
source ~/.bashrc
```

## هەنگاوی ٥ — ئەپەکە بارکە و بنیاد بنێ

1. لە کۆمپیوتەرەکەت فایلی `iptv-app-deploy.zip` بنێرە بۆ سێرڤەرەکە:

```bash
# لە کۆمپیوتەرەکەت (ناوێ فۆڵدەری download):
scp iptv-app-deploy.zip root@43.128.xx.xx:/opt/iptv-app.zip
```

2. لەسەر سێرڤەرەکە:

```bash
mkdir -p /opt/iptv-app
cd /opt/iptv-app
unzip /opt/iptv-app.zip
bun install          # پاکێجەکان
bun run build        # بنیادنان (~٢–٣ خولەک)
```

## هەنگاوی ٦ — ئەپەکە بکە خزمەتێکی هەمیشەیی (systemd)

```bash
# ڕێرەوەکان بگۆڕە ئەگەر پێویست بوو
chmod +x /opt/iptv-app/deploy/start-prod.sh
cp /opt/iptv-app/deploy/iptv.service /etc/systemd/system/iptv.service
systemctl daemon-reload
systemctl enable --now iptv
systemctl status iptv   # دەبێت بڵێت active (running)
```

ئێستا ئەپەکە لەسەر سێرڤەرەکە لە پۆرتی 3000 کار دەکات — بەڵام هێشتا تەنها ناوخۆییە.

## هەنگاوی ٧ — دۆمەین + HTTPS بە Caddy

```bash
# فایلی Caddyfile وەربگرە و دۆمەینەکەت تێدا بگۆڕە
cp /opt/iptv-app/deploy/Caddyfile.tencent /etc/caddy/Caddyfile
nano /etc/caddy/Caddyfile     # tv.YOUR-DOMAIN.com بگۆڕە بۆ دۆمەینە ڕاستەقینەکەت
systemctl reload caddy
```

🎉 تەواو! Caddy خۆکارانە HTTPS دەگرێت. دوای ~٢ خولەک بکەرەوە:

```
https://tv.dۆمەینەکەت.com
```

## هەنگاوی ٨ — ڕێکخستنی یەکەم

1. لینکەکە بکەرەوە → ناوی ئەپ و **کۆدی بەڕێوەبەر (Admin PIN)** دابنێ.
2. زانیاری **M3U** یان **Xtream** دابنێ — کەناڵ و فیلمەکان دێن.
3. لە پانێلی بەڕێوەبردنەوە **Google Drive** لینکە هاوبەشەکان زیاد بکە.

## هەنگاوی ٩ — بۆ بەکارهێنەران

- **مۆبایل:** لینکەکە بە Chrome بکەنەوە → ⋮ → **Add to Home screen** → وەک ئەپ دادەمەزرێت
- **تیڤی:** بە ڕیمۆت دوگمەی **شێوازی تیڤی** لە سەرەوە کلیک بکە — ڕووکار گەورە دەبێت و بە ڕیمۆت دەجوڵێت
- **APK:** لە [pwabuilder.com](https://www.pwabuilder.com) لینکەکە دابنێ و APK داگرە

---

## چاککردنەوەی کێشەکان

| کێشە | چارەسەر |
|------|---------|
| سایت کردنەوەی نییە | `systemctl status iptv` و `journalctl -u iptv -n 50` |
| HTTPS نییە | `journalctl -u caddy -n 50` — دۆمەین و DNS بپشکنە |
| دۆمەین کار ناکات | `ping tv.dۆمەینەکەت.com` — دەبێت IP ی سێرڤەر بگەڕێنێتەوە |
| دووبارە بنیادنان | `cd /opt/iptv-app && bun run build && systemctl restart iptv` |
| پاشکۆی داتا | داتاکان لە `/opt/iptv-app/db/custom.db` — ئەو فایلە پارێزە |

## تێبینی گرنگ

- **داتاکان لەسەر سێرڤەرەکەت دەمێنن** (داتابەیسی SQLite) — پێویست بە Turso نییە
- **Google Drive** لەسەر هۆنگ کۆنگ بێ کێشە کار دەکات — بۆیە هەرێمەکە نەگۆڕە
- فۆنتی ئەپەکە **ناوخۆییە** — هیچ پێویستی بە Google Fonts نییە
