<?php
// مێژووی تەماشاکردن — وەشانێکی PHP ی src/app/api/history/route.ts
require __DIR__ . '/lib.php';
handle_preflight();

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// ---- GET — ٢٤ تۆماری کۆتایی ----
if ($method === 'GET') {
    try {
        if (!is_admin()) forbidden();
        $items = turso_rows("SELECT * FROM \"History\" ORDER BY \"watchedAt\" DESC LIMIT 24");
        json_out(['items' => $items]);
    } catch (Throwable $e) {
        json_out(['error' => 'هەڵە لە خوێندنەوەی مێژوو'], 500);
    }
}

// ---- POST — تۆمارکردن/نوێکردنەوە (upsert) ----
if ($method === 'POST') {
    try {
        if (!is_admin()) forbidden();
        $body = body_json();
        $itemType = trim_str($body['itemType'] ?? '');
        $itemId = trim_str($body['itemId'] ?? '');
        $name = trim_str($body['name'] ?? '');
        if ($itemType === '' || $itemId === '' || $name === '') {
            json_out(['error' => 'زانیاری ناتەواو'], 400);
        }
        $logo = trim_null($body['logo'] ?? null);
        $extra = trim_null($body['extra'] ?? null);

        turso_exec(
            "INSERT INTO \"History\" (\"id\", \"itemType\", \"itemId\", \"name\", \"logo\", \"extra\", \"watchedAt\") " .
            "VALUES (?, ?, ?, ?, ?, ?, " . sql_now() . ") " .
            "ON CONFLICT(\"itemType\", \"itemId\") DO UPDATE SET " .
            "\"name\" = excluded.\"name\", \"logo\" = excluded.\"logo\", \"extra\" = excluded.\"extra\", \"watchedAt\" = " . sql_now(),
            [cuid(), $itemType, $itemId, $name, $logo, $extra]
        );
        json_out(['ok' => true]);
    } catch (Throwable $e) {
        json_out(['error' => 'هەڵە لە تۆمارکردن'], 500);
    }
}

// ---- DELETE ----
if ($method === 'DELETE') {
    try {
        if (!is_admin()) forbidden();
        $itemId = isset($_GET['itemId']) ? (string)$_GET['itemId'] : '';
        if ($itemId === 'ALL') {
            turso_exec("DELETE FROM \"History\"");
            json_out(['ok' => true]);
        }
        if ($itemId !== '') {
            turso_exec("DELETE FROM \"History\" WHERE \"itemId\" = ?", [$itemId]);
        }
        json_out(['ok' => true]);
    } catch (Throwable $e) {
        json_out(['error' => 'هەڵە لە سڕینەوە'], 500);
    }
}

json_out(['error' => 'ڕێگەیەکی نەزانراو'], 405);
