#!/usr/bin/env python3
"""Wrap all fetch('/api...') and fetch(`/api...`) calls with apiUrl() in the IPTV app.

Also inserts the `import { apiUrl } from '@/lib/api'` after the 'use client'
directive in each touched file. Idempotent: running twice changes nothing.
"""
import re
import sys
from pathlib import Path

ROOT = Path("/home/z/my-project")
FILES = [
    "src/components/iptv/setup.tsx",
    "src/components/iptv/details.tsx",
    "src/components/iptv/drive.tsx",
    "src/components/iptv/sources.tsx",
    "src/components/iptv/browse.tsx",
    "src/app/page.tsx",
]

RE_SQ = re.compile(r"fetch\('(/api[^']*)'")
RE_BT = re.compile(r"fetch\(`(/api[^`]*)`")
IMPORT = "import { apiUrl } from '@/lib/api'"

total = 0
for rel in FILES:
    p = ROOT / rel
    src = p.read_text(encoding="utf-8")
    n1 = len(RE_SQ.findall(src))
    n2 = len(RE_BT.findall(src))
    if n1 == 0 and n2 == 0 and IMPORT in src:
        print(f"SKIP {rel} (already wrapped)")
        continue
    out = RE_SQ.sub(r"fetch(apiUrl('\1')", src)
    out = RE_BT.sub(r"fetch(apiUrl(`\1`)", out)
    if IMPORT not in out:
        if out.lstrip().startswith("'use client'"):
            idx = out.index("'use client'")
            eol = out.index("\n", idx) + 1
            out = out[:eol] + IMPORT + "\n" + out[eol:]
        else:
            out = IMPORT + "\n" + out
    p.write_text(out, encoding="utf-8")
    print(f"OK   {rel}: {n1} single-quote + {n2} template wrapped")
    total += n1 + n2

print(f"TOTAL wrapped: {total}")

# leftover check: any unwrapped '/api' fetches left anywhere in src?
leftover = []
for p in (ROOT / "src").rglob("*.ts*"):
    txt = p.read_text(encoding="utf-8", errors="ignore")
    if "src/lib/api.ts" in str(p):
        continue
    for m in re.finditer(r"fetch\((['`])(/api[^'`]+)\1", txt):
        leftover.append(f"{p.relative_to(ROOT)}: {m.group(0)[:60]}")
if leftover:
    print("LEFTOVER unwrapped fetches:")
    for l in leftover:
        print("  " + l)
    sys.exit(1)
print("No leftover unwrapped /api fetches.")
