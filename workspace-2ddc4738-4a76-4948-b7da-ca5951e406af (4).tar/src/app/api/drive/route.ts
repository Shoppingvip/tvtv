// بەڕێوەبردنی فلیمەکانی Google Drive — تەنها بەڕێوەبەر زیادکردن و سڕینەوە دەکات
// هەمووان لیستەکە دەبینن لە بەشی فلیمەکان
// شێوازی کارکردن: فایل/فۆڵدەر لە Drive بکە بە «هەر کەسێک بە بەستەر» — بێ کلیل کار دەکات
// (کلیلی API ئارەزوومەندانەیە — بۆ فۆڵدەری گەورە وردترە)
import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { isAdminRequest, forbidden } from '@/lib/admin'
import {
  extractDriveId,
  driveThumbUrl,
  cleanMovieName,
  listFolderVideos,
  verifyFilePublic,
} from '@/lib/drive'
import { backupDbFile } from '@/lib/backup'

export const dynamic = 'force-dynamic'

// ناوی ڕەسەنی فایلەکە لە پەڕەی Drive وەردەگرێت — «name.mp4 - Google Drive»
async function fetchTitle(fileId: string): Promise<string | null> {
  try {
    const res = await fetch(`https://drive.google.com/file/d/${encodeURIComponent(fileId)}/view`, {
      signal: AbortSignal.timeout(20000),
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
        Accept: 'text/html,*/*',
      },
    })
    if (!res.ok) return null
    const html = await res.text()
    // نازناوەکە وەردەگرین — پەڕەی چوونەژوورەوە نازناوی «Sign in - Google Accounts» هەیە
    // (پەڕەی ئاسایی Drive بەستەری sign-in لەخۆ دەگرێت — بۆیە تەنها نازناوەکە دەپشکنین)
    const t = /<title>([^<]+)<\/title>/i.exec(html)?.[1] ?? ''
    if (/sign in|google accounts|چوونەژوورەوە/i.test(t)) return null
    // نازناوەکە بە هەر زمانێک دەبێت: «NAME - Google Drive» یان «NAME - Google 雲端硬碟»...
    // دوا « - » دەدۆزینەوە و بەشی پێش ئەوە ناوی فایلەکەیە
    const decoded = t
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'")
      .trim()
    for (const sep of [' - ', ' – ', ' — ']) {
      const i = decoded.lastIndexOf(sep)
      if (i > 0 && /google/i.test(decoded.slice(i + sep.length))) {
        return decoded.slice(0, i).trim() || null
      }
    }
    return decoded || null
  } catch {
    return null
  }
}

// خوێندنەوەی هەموو فلیمەکانی Drive — بۆ هەمووان
export async function GET() {
  try {
    const items = await db.driveVideo.findMany({
      orderBy: [{ sortOrder: 'asc' }, { createdAt: 'asc' }],
    })
    // ئایا کلیلی API دانراوە؟ (خۆی نانێردرێتەوە — تەنها نیشانەکە)
    const s = await db.settings.findUnique({ where: { id: 'main' }, select: { driveApiKey: true } })
    return NextResponse.json({ items, hasKey: !!s?.driveApiKey })
  } catch {
    return NextResponse.json({ error: 'هەڵە لە خوێندنەوەی فلیمەکانی Drive' }, { status: 500 })
  }
}

// زیادکردن:
//   { link: 'https://drive.google.com/...' } → خۆکارانە دەزانێت فایلە یان فۆڵدەر
//   { action: 'save-key', apiKey: '...' }     → پاشەکەوتکردنی کلیلی API (ئارەزوومەندانە)
export async function POST(req: NextRequest) {
  if (!(await isAdminRequest(req))) return forbidden()
  try {
    const body = (await req.json()) as { link?: string; action?: string; apiKey?: string }

    // ---- پاشەکەوتکردنی کلیلی API (ئارەزوومەندانە) ----
    if (body.action === 'save-key') {
      const key = (body.apiKey ?? '').trim() || null
      await db.settings.upsert({
        where: { id: 'main' },
        update: { driveApiKey: key },
        create: { id: 'main', driveApiKey: key },
      })
      backupDbFile('drive-key-saved')
      return NextResponse.json({ ok: true, hasKey: !!key })
    }

    const link = (body.link ?? '').trim()
    if (!link) {
      return NextResponse.json({ error: 'داواکارییەکە بەتاڵە' }, { status: 400 })
    }

    const parsed = extractDriveId(link)
    if (!parsed) {
      return NextResponse.json(
        { error: 'بەستەرەکە نەناسرا — تکایە بەستەری هاوبەشی فایل یان فۆڵدەر دابنێ (Share → Copy link)' },
        { status: 400 }
      )
    }

    // ---- هێنانی فلیمەکانی فۆڵدەر ----
    if (parsed.type === 'folder') {
      const s = await db.settings.findUnique({ where: { id: 'main' }, select: { driveApiKey: true } })
      const { folderName, files } = await listFolderVideos(parsed.id, s?.driveApiKey)

      // ئەوانەی پێشتر هەن فەرامۆش بکە — تەنها نوێیان زیاد بکە
      const existing = new Set((await db.driveVideo.findMany({ select: { fileId: true } })).map((x) => x.fileId))
      const max = await db.driveVideo.aggregate({ _max: { sortOrder: true } })
      let order = (max._max.sortOrder ?? -1) + 1
      const fresh = files.filter((f) => !existing.has(f.id))

      for (const f of fresh) {
        await db.driveVideo
          .create({
            data: {
              fileId: f.id,
              name: cleanMovieName(f.name).slice(0, 120),
              folderId: parsed.id,
              folderName: (folderName ?? 'Google Drive').slice(0, 60),
              thumbnail: f.thumbnail ?? driveThumbUrl(f.id),
              size: f.size ?? null,
              sortOrder: order++,
            },
          })
          .catch(() => {}) // دووبارەیی — پشتگوێ بخە
      }

      backupDbFile('drive-folder-imported')
      return NextResponse.json({
        ok: true,
        kind: 'folder',
        imported: fresh.length,
        folderName: folderName ?? 'Google Drive',
      })
    }

    // ---- زیادکردنی فلیمی تاک ----
    const fid = parsed.id

    // پشکنین — فایلەکە بە گشتی بەشکراوە؟
    await verifyFilePublic(fid)

    const dup = await db.driveVideo.findUnique({ where: { fileId: fid } })
    if (dup) {
      return NextResponse.json({ error: `«${dup.name}» پێشتر زیادکراوە` }, { status: 409 })
    }

    // ناوی ڕەسەنی فایلەکە — ئەگەر نەکرا ناوی گشتی
    const realName = await fetchTitle(fid)
    const max = await db.driveVideo.aggregate({ _max: { sortOrder: true } })

    const created = await db.driveVideo.create({
      data: {
        fileId: fid,
        name: (realName ? cleanMovieName(realName) : 'فلیمی Drive').slice(0, 120),
        thumbnail: driveThumbUrl(fid),
        sortOrder: (max._max.sortOrder ?? -1) + 1,
      },
    })
    backupDbFile('drive-video-added')
    return NextResponse.json({ ok: true, kind: 'file', id: created.id, name: created.name })
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : 'نەکرا فلیمەکە زیاد بکرێت' },
      { status: 500 }
    )
  }
}

// سڕینەوە — ?id= یەک فلیم | ?folderId= هەموو فلیمەکانی فۆڵدەر
export async function DELETE(req: NextRequest) {
  if (!(await isAdminRequest(req))) return forbidden()
  try {
    const id = req.nextUrl.searchParams.get('id')
    const folderId = req.nextUrl.searchParams.get('folderId')
    if (folderId) {
      await db.driveVideo.deleteMany({ where: { folderId } })
      backupDbFile('drive-folder-deleted')
      return NextResponse.json({ ok: true })
    }
    if (!id) return NextResponse.json({ error: 'ناسنامە نەنێردرا' }, { status: 400 })
    await db.driveVideo.delete({ where: { id } })
    backupDbFile('drive-video-deleted')
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'نەکرا بسڕدرێتەوە' }, { status: 500 })
  }
}
