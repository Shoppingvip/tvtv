'use client'
import { apiUrl } from '@/lib/api'

// پانێلی بەڕێوەبردنی لیستەکانی M3U — بەشی بەڕێوەبەر
// زیادکردنی لیست بە جیا بۆ بەشی کەناڵ و فلیم + ڕیزکردنەوە (پێش/دوا) + سڕینەوە
import { useCallback, useEffect, useState } from 'react'
import {
  ListVideo, Plus, Trash2, ArrowUp, ArrowDown, Loader2, Tv, Film, Layers, RefreshCw,
} from 'lucide-react'
import { cn } from '@/lib/utils'

export interface M3uSourceItem {
  id: string
  name: string
  url: string
  section: 'live' | 'movie' | 'both'
  sortOrder: number
}

type Section = M3uSourceItem['section']

const SECTION_META: Record<Section, { label: string; desc: string; icon: typeof Tv; color: string }> = {
  live: { label: 'کەناڵەکان', desc: 'تەنها لە شاشەی کەناڵەکان دەرکەوتن', icon: Tv, color: 'text-indigo-300' },
  movie: { label: 'فلیمەکان', desc: 'تەنها لە شاشەی فلیمەکان دەرکەوتن', icon: Film, color: 'text-fuchsia-300' },
  both: { label: 'هەردووکیان', desc: 'بەپێی ناوەڕۆکەکەی خۆکارانە دابەش دەبێت', icon: Layers, color: 'text-sky-300' },
}

// ڕیزبەندی بەشەکان لە ڕووکارەکەدا — هەردووکیان سەرەوە، پاشان کەناڵ و فلیم
const GROUP_ORDER: Section[] = ['both', 'live', 'movie']

export function M3uSourcesPanel({ mode, onChanged }: { mode?: 'xtream' | 'm3u' | null; onChanged?: () => void }) {
  const [items, setItems] = useState<M3uSourceItem[]>([])
  const [loading, setLoading] = useState(true)
  const [name, setName] = useState('')
  const [url, setUrl] = useState('')
  const [section, setSection] = useState<'live' | 'movie' | 'both'>('live')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [workingId, setWorkingId] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch(apiUrl('/api/m3u/sources'))
      const data = (await res.json()) as { items?: M3uSourceItem[]; error?: string }
      if (!res.ok) throw new Error(data.error ?? 'نەکرا لیستەکان بخوێنرێنەوە')
      setItems(data.items ?? [])
      setError(null)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'هەڵەیەک ڕوویدا')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { void load() }, [load])

  // زیادکردنی لیستی نوێ — بەشی هەڵبژێردراو (کەناڵ یان فلیم یان هەردووکیان)
  const add = async () => {
    if (!url.trim() || busy) return
    setBusy(true)
    setError(null)
    try {
      const res = await fetch(apiUrl('/api/m3u/sources'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: name.trim(), url: url.trim(), section }),
      })
      const data = (await res.json()) as { error?: string }
      if (!res.ok) throw new Error(data.error ?? 'نەکرا لیستەکە زیاد بکرێت')
      setName('')
      setUrl('')
      await load()
      onChanged?.()
    } catch (e) {
      setError(e instanceof Error ? e.message : 'نەکرا لیستەکە زیاد بکرێت')
    } finally {
      setBusy(false)
    }
  }

  // ڕیزکردنەوە — dir: -1 = پێشتر (سەرەوە)، 1 = دواتر (خوارەوە)
  const move = async (item: M3uSourceItem, dir: 1 | -1) => {
    if (workingId) return
    setWorkingId(item.id)
    try {
      await fetch(apiUrl('/api/m3u/sources'), {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: item.id, dir, section: item.section }),
      })
      await load()
    } catch { /* پشتگوێخستن — لیستەکە وەک خۆی دەمێنێت */ } finally {
      setWorkingId(null)
    }
  }

  const remove = async (item: M3uSourceItem) => {
    if (workingId) return
    if (!confirm(`دڵنیای لە سڕینەوەی «${item.name || SECTION_META[item.section].label}»؟`)) return
    setWorkingId(item.id)
    try {
      const res = await fetch(apiUrl(`/api/m3u/sources?id=${encodeURIComponent(item.id)}`), { method: 'DELETE' })
      if (!res.ok) {
        const d = (await res.json().catch(() => ({}))) as { error?: string }
        setError(d.error ?? 'نەکرا لیستەکە بسڕدرێتەوە')
      } else {
        setError(null)
      }
      await load()
      onChanged?.()
    } finally {
      setWorkingId(null)
    }
  }

  // گروپکردن بەپێی بەش — هەر گروپێک بە ڕیزبەندی خۆی
  const groups = GROUP_ORDER.map((s) => ({
    section: s,
    rows: items.filter((i) => i.section === s).sort((a, b) => a.sortOrder - b.sortOrder),
  }))

  return (
    <section className="glass rounded-2xl p-5 space-y-4">
      <div className="flex items-center gap-2">
        <ListVideo className="w-4 h-4 text-indigo-300" />
        <h3 className="font-bold">لیستەکانی M3U 📋</h3>
        <button
          onClick={() => void load()}
          aria-label="نوێکردنەوەی لیستەکان"
          title="نوێکردنەوە"
          className="tv-focus ms-auto w-9 h-9 rounded-xl glass hover:bg-white/10 flex items-center justify-center transition-colors"
        >
          <RefreshCw className={cn('w-4 h-4', loading && 'animate-spin')} />
        </button>
      </div>
      <p className="text-xs text-muted-foreground leading-relaxed">
        زیاتر لە یەک لیست دەتوانیت دابنێیت — هەر لیستێک بە جیا بۆ بەشی کەناڵ یان فلیم.
        بە دوگمەکانی ↑ ↓ شوێنی لیستەکان بگۆڕە (کە کام لیست پێشتر دەرکەوێت) و بە 🗑 بسڕەوە.
      </p>

      {mode === 'xtream' ? (
        <p className="text-xs text-amber-300/90 glass rounded-xl px-4 py-3 leading-relaxed">
          ئەم ئەپە بە Xtream Codes کاردەکات — لیستەکانی M3U لەم دۆخەدا بەکار نایەن. بۆ بەکارهێنانیان، جۆری سەرچاوە بگۆڕە بۆ لیستی M3U.
        </p>
      ) : null}

      {/* ---- فۆرمی زیادکردن ---- */}
      <div className="glass rounded-xl p-4 space-y-3 border border-white/5">
        <p className="text-xs font-bold text-indigo-200">زیادکردنی لیستی نوێ</p>
        <div className="grid grid-cols-3 gap-2 p-1.5 rounded-2xl bg-white/5 border border-white/10">
          {(['live', 'movie', 'both'] as const).map((s) => {
            const meta = SECTION_META[s]
            const Icon = meta.icon
            return (
              <button
                key={s}
                type="button"
                onClick={() => setSection(s)}
                aria-pressed={section === s}
                className={cn(
                  'tv-focus flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-xs font-semibold transition-all',
                  section === s ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/30' : 'text-muted-foreground hover:text-foreground'
                )}
              >
                <Icon className="w-4 h-4" />
                {meta.label}
              </button>
            )
          })}
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="ناوی لیست (ئارەزوومەندانە)"
            className="tv-focus glass rounded-xl px-4 py-2.5 text-sm outline-none focus:border-indigo-400/60"
          />
          <input
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            dir="ltr"
            inputMode="url"
            placeholder="http://... get.php?... type=m3u_plus"
            className="tv-focus glass rounded-xl px-4 py-2.5 text-sm outline-none focus:border-indigo-400/60 text-left font-mono text-xs"
          />
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <button
            onClick={add}
            disabled={busy || !url.trim()}
            className="tv-focus flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 hover:from-indigo-400 hover:to-violet-400 text-sm font-bold shadow-lg shadow-indigo-500/25 transition-all disabled:opacity-50"
          >
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
            {busy ? 'زیادکردن...' : 'زیادکردنی لیست'}
          </button>
          <span className="text-[11px] text-muted-foreground/70">
            {SECTION_META[section].label} — {SECTION_META[section].desc}
          </span>
        </div>
      </div>

      {error ? (
        <div className="rounded-xl bg-rose-500/15 border border-rose-400/30 px-4 py-3 text-sm text-rose-200">
          {error}
        </div>
      ) : null}

      {/* ---- لیستەکان بەپێی بەش ---- */}
      {loading && items.length === 0 ? (
        <p className="text-sm text-muted-foreground flex items-center gap-2 py-2">
          <Loader2 className="w-4 h-4 animate-spin" />
          بارکردنی لیستەکان...
        </p>
      ) : items.length === 0 ? (
        <p className="text-xs text-muted-foreground/70">
          هێشتا هیچ لیستێک دانەنراوە — یەکەم لیست زیاد بکە.
        </p>
      ) : (
        <div className="space-y-4">
          {groups.map(({ section: g, rows }) => {
            const meta = SECTION_META[g]
            const Icon = meta.icon
            return (
              <div key={g} className="space-y-2">
                <div className="flex items-center gap-2">
                  <Icon className={cn('w-4 h-4', meta.color)} />
                  <span className="text-xs font-bold">{meta.label}</span>
                  <span className="text-[11px] text-muted-foreground">
                    {rows.length > 0 ? `${rows.length} لیست` : 'بەتاڵە'}
                  </span>
                </div>
                {rows.length === 0 ? (
                  <p className="text-[11px] text-muted-foreground/60 ps-6">هیچ لیستێک لەم بەشەدا نییە.</p>
                ) : (
                  rows.map((item, i) => (
                    <SourceRow
                      key={item.id}
                      item={item}
                      index={i}
                      total={rows.length}
                      working={workingId === item.id}
                      onMove={move}
                      onRemove={remove}
                    />
                  ))
                )}
              </div>
            )
          })}
        </div>
      )}
    </section>
  )
}

// ---- یەک ڕیزی لیست — ناو + بەستەر + دوگمەکانی ڕیزکردن و سڕینەوە ----
function SourceRow({
  item,
  index,
  total,
  working,
  onMove,
  onRemove,
}: {
  item: M3uSourceItem
  index: number
  total: number
  working: boolean
  onMove: (item: M3uSourceItem, dir: 1 | -1) => void
  onRemove: (item: M3uSourceItem) => void
}) {
  return (
    <div
      className={cn(
        'glass rounded-xl px-3 py-2.5 flex items-center gap-2.5 transition-opacity',
        working && 'opacity-50'
      )}
    >
      <span className="w-7 h-7 rounded-lg bg-indigo-500/15 border border-indigo-400/25 text-indigo-200 text-xs font-bold flex items-center justify-center shrink-0 tabular-nums">
        {index + 1}
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-semibold truncate">{item.name || 'بێ ناو'}</p>
        <p className="text-[11px] text-muted-foreground font-mono truncate text-left" dir="ltr" title={item.url}>
          {item.url}
        </p>
      </div>
      <div className="flex items-center gap-1 shrink-0">
        <button
          onClick={() => onMove(item, -1)}
          disabled={index === 0 || working}
          aria-label="بجوێنە پێشتر (سەرەوە)"
          title="بجوێنە پێشتر"
          className="tv-focus w-9 h-9 rounded-lg glass hover:bg-white/10 flex items-center justify-center transition-colors disabled:opacity-30"
        >
          <ArrowUp className="w-4 h-4" />
        </button>
        <button
          onClick={() => onMove(item, 1)}
          disabled={index === total - 1 || working}
          aria-label="بجوێنە دواتر (خوارەوە)"
          title="بجوێنە دواتر"
          className="tv-focus w-9 h-9 rounded-lg glass hover:bg-white/10 flex items-center justify-center transition-colors disabled:opacity-30"
        >
          <ArrowDown className="w-4 h-4" />
        </button>
        <button
          onClick={() => onRemove(item)}
          disabled={working}
          aria-label="سڕینەوەی لیست"
          title="سڕینەوە"
          className="tv-focus w-9 h-9 rounded-lg glass hover:bg-rose-500/20 text-rose-200 flex items-center justify-center transition-colors disabled:opacity-30"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
    </div>
  )
}
