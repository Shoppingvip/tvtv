import { PrismaClient } from '@prisma/client'
const db = new PrismaClient()
async function main() {
  await db.settings.deleteMany({})
  await db.favorite.deleteMany({})
  await db.history.deleteMany({})
  console.log('OK - test data cleared, app ready for the user')
}
main().finally(() => db.$disconnect())
