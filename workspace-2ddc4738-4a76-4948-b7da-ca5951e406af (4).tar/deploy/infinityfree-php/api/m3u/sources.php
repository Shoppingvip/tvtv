<?php
// بەڕێوەبردنی سەرچاوەکانی M3U — تەنها بەڕێوەبەر
// وەشانێکی PHP ی src/app/api/m3u/sources/route.ts
require __DIR__ . '/../lib.php';
handle_preflight();

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// ---- GET — خوێندنەوەی هەموو لیستەکان ----
if ($method === 'GET') {
    try {
        if (!is_admin()) forbidden();
        json_out(['items' => list_sources()]);
    } catch (Throwable $e) {
        if ($e->getCode() === 403) forbidden();
        json_out(['error' => 'هەڵە لە خوێندنەوەی لیستەکان'], 500);
    }
}

// ---- POST — زیادکردنی لیستێکی نوێ ----
if ($method === 'POST') {
    try {
        if (!is_admin()) forbidden();
        $body = body_json();
        $url = trim_str($body['url'] ?? '');
        $section = trim_str($body['section'] ?? '');
        if (!in_array($section, ['live', 'movie', 'both'], true)) $section = 'both';
        if (!preg_match('/^https?:\/\/.+/i', $url)) {
            json_out(['error' => 'بەستەرەکە دەبێت بە http:// یان https:// دەست پێبکات'], 400);
        }

        $max = (int)(turso_scalar("SELECT MAX(\"sortOrder\") FROM \"M3uSource\"") ?? -1);
        $name = trim_str($body['name'] ?? '');
        if (mb_strlen($name) > 60) $name = mb_substr($name, 0, 60);

        $id = cuid();
        turso_exec(
            "INSERT INTO \"M3uSource\" (\"id\", \"name\", \"url\", \"section\", \"sortOrder\") VALUES (?, ?, ?, ?, ?)",
            [$id, $name, $url, $section, $max + 1]
        );
        json_out(['ok' => true, 'id' => $id]);
    } catch (Throwable $e) {
        json_out(['error' => 'نەکرا لیستەکە زیاد بکرێت'], 500);
    }
}

// ---- PUT — ڕیزکردنەوە ----
if ($method === 'PUT') {
    try {
        if (!is_admin()) forbidden();
        $body = body_json();
        $id = trim_str($body['id'] ?? '');
        $dir = isset($body['dir']) ? (int)$body['dir'] : 0;
        if ($id === '' || ($dir !== 1 && $dir !== -1)) {
            json_out(['error' => 'داواکارییەکە دروست نییە'], 400);
        }
        $section = trim_str($body['section'] ?? '');
        if (!in_array($section, ['live', 'movie', 'both'], true)) $section = '';

        $all = turso_rows("SELECT * FROM \"M3uSource\" ORDER BY \"sortOrder\" ASC, \"createdAt\" ASC");
        // فلتەری ورد — تەنها لیستەکانی هەمان بەش
        $scoped = [];
        if ($section !== '') {
            foreach ($all as $s) if ((string)$s['section'] === $section) $scoped[] = $s;
        } else {
            $scoped = $all;
        }
        $idx = -1;
        foreach ($scoped as $i => $s) {
            if ((string)$s['id'] === $id) { $idx = $i; break; }
        }
        if ($idx === -1) json_out(['error' => 'لیستەکە نەدۆزرایەوە'], 404);

        $j = $idx + $dir;
        if ($j < 0 || $j >= count($scoped)) {
            // لە لێوارەکەیە — هیچ مەکە بەڵام سەرکەوتوو بگەڕێنەوە
            json_out(['ok' => true]);
        }

        $a = $scoped[$idx];
        $b = $scoped[$j];
        if ((int)$a['sortOrder'] === (int)$b['sortOrder']) {
            // ئاڵوگۆڕ + ڕێکخستنەوەی تەواوی لیستەکە
            $reordered = $scoped;
            array_splice($reordered, $idx, 1);
            array_splice($reordered, $j, 0, [$a]);
            $stmts = [];
            foreach ($reordered as $i => $s) {
                $stmts[] = ['sql' => "UPDATE \"M3uSource\" SET \"sortOrder\" = ? WHERE \"id\" = ?", 'args' => [$i, (string)$s['id']]];
            }
            turso_pipeline($stmts);
        } else {
            turso_pipeline([
                ['sql' => "UPDATE \"M3uSource\" SET \"sortOrder\" = ? WHERE \"id\" = ?", 'args' => [(int)$b['sortOrder'], (string)$a['id']]],
                ['sql' => "UPDATE \"M3uSource\" SET \"sortOrder\" = ? WHERE \"id\" = ?", 'args' => [(int)$a['sortOrder'], (string)$b['id']]],
            ]);
        }
        json_out(['ok' => true]);
    } catch (Throwable $e) {
        json_out(['error' => 'نەکرا ڕیزەکە بگۆڕدرێت'], 500);
    }
}

// ---- DELETE — سڕینەوەی لیست — ?id= ----
if ($method === 'DELETE') {
    try {
        if (!is_admin()) forbidden();
        $id = isset($_GET['id']) ? (string)$_GET['id'] : '';
        if ($id === '') json_out(['error' => 'ناسنامەی لیست نەنێردرا'], 400);
        turso_exec("DELETE FROM \"M3uSource\" WHERE \"id\" = ?", [$id]);
        // ئەگەر دوایین لیستیش سڕدرایەوە — m3uUrl ی کۆن پاک بکەرەوە
        $remaining = (int)(turso_scalar("SELECT COUNT(*) FROM \"M3uSource\"") ?? 0);
        if ($remaining === 0) {
            turso_exec("UPDATE \"Settings\" SET \"m3uUrl\" = NULL WHERE \"id\" = 'main'");
        }
        json_out(['ok' => true]);
    } catch (Throwable $e) {
        json_out(['error' => 'نەکرا لیستەکە بسڕدرێتەوە'], 500);
    }
}

json_out(['error' => 'ڕێگەیەکی نەزانراو'], 405);
