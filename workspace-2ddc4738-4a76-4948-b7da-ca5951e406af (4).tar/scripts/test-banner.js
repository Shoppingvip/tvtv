// تاقیکردنەوەی API ی وێنە ڕیکلامییەکان
const B = 'http://localhost:3000'
const fs = require('fs')

async function main() {
  // 1) GET گشتی — بەتاڵ
  let r = await fetch(B + '/api/banner')
  let d = await r.json()
  console.log('1. public GET (empty):', r.status, 'items:', d.items.length)

  // 2) POST بێ دەسەڵات → 403
  r = await fetch(B + '/api/banner', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ data: 'data:image/jpeg;base64,AAAA' }),
  })
  console.log('2. POST no-admin:', r.status)

  // 3) چوونەژوورەوە وەک بەڕێوەبەر
  const { PrismaClient } = require('@prisma/client')
  const db = new PrismaClient()
  const st = await db.settings.findUnique({ where: { id: 'main' } })
  if (!st || !st.adminPin) throw new Error('adminPin نییە لە DB')
  r = await fetch(B + '/api/admin', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ pin: st.adminPin }),
  })
  const cookie = r.headers.get('set-cookie').split(';')[0]
  console.log('3. admin login:', r.status)

  // 4) POST دوو وێنە بە دەسەڵاتی بەڕێوەبەر
  const b1 = fs.readFileSync('/tmp/banner1.txt', 'utf8')
  const b2 = fs.readFileSync('/tmp/banner2.txt', 'utf8')
  r = await fetch(B + '/api/banner', { method: 'POST', headers: { 'Content-Type': 'application/json', cookie }, body: JSON.stringify({ data: b1, name: 'test-1' }) })
  console.log('4. POST banner1:', r.status)
  r = await fetch(B + '/api/banner', { method: 'POST', headers: { 'Content-Type': 'application/json', cookie }, body: JSON.stringify({ data: b2, name: 'test-2' }) })
  console.log('5. POST banner2:', r.status)

  // 6) GET دووبارە
  d = await (await fetch(B + '/api/banner')).json()
  console.log('6. public GET now:', d.items.length, 'items')

  // 7) DELETE بێ دەسەڵات → 403
  r = await fetch(B + '/api/banner?id=' + d.items[0].id, { method: 'DELETE' })
  console.log('7. DELETE no-admin:', r.status)

  // 8) DELETE دروست بە دەسەڵات (سڕینەوەی هەموو وێنە تاقیکارییەکان لە کۆتاییدا دەکەین — نا، بۆ ئێستا دەیبهێڵین بۆ تاقیکردنەوەی ڕوکار)
  await db.$disconnect()
  console.log('OK — banners in place for UI test')
}

main().catch((e) => {
  console.error('FAIL:', e.message)
  process.exit(1)
})
