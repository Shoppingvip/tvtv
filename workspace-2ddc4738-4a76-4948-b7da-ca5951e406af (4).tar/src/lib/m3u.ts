// کتێبخانەی M3U — سەرچاوەکان، گواستنەوەی لیستی کۆن و کۆکردنەوەی کەناڵەکان بەپێی بەش
import { db } from '@/lib/db'
import type { M3UChannel } from '@/lib/iptv'

export type M3uSection = 'live' | 'movie' | 'both'

export interface M3uSourceRow {
  id: string
  name: string
  url: string
  section: M3uSection
  sortOrder: number
}

// ---- گواستنەوەی لیستی کۆن ----
// ئەگەر لیستی تاکی کۆن (settings.m3uUrl) هەبێت و هیچ سەرچاوەیەک دانەنرابێت — دەکرێتە لیستێکی (هەردووکیان)
export async function ensureMigrated(): Promise<void> {
  try {
    const count = await db.m3uSource.count()
    if (count > 0) return
    const s = await db.settings.findUnique({ where: { id: 'main' } })
    if (!s?.m3uUrl) return
    await db.m3uSource.create({
      data: { name: 'لیستی سەرەکی', url: s.m3uUrl, section: 'both', sortOrder: 0 },
    })
  } catch { /* پشتگوێخستن — داتابەیس لەبەردەستە نییە */ }
}

// هەموو سەرچاوەکان بە ڕیز — بۆ بەشی بەڕێوەبەر
export async function listSources(): Promise<M3uSourceRow[]> {
  await ensureMigrated()
  const rows = await db.m3uSource.findMany({ orderBy: [{ sortOrder: 'asc' }, { createdAt: 'asc' }] })
  return rows.map((r) => ({
    id: r.id,
    name: r.name,
    url: r.url,
    section: (r.section as M3uSection) ?? 'both',
    sortOrder: r.sortOrder,
  }))
}

// سەرچاوەکانی یەک بەش — بەشەکە + ئەوانەی (هەردووکیان)ن
export async function sourcesForSection(section: 'live' | 'movie'): Promise<M3uSourceRow[]> {
  const all = await listSources()
  return all.filter((s) => s.section === section || s.section === 'both')
}

// ئایا هیچ سەرچاوەیەک هەیە؟ — بۆ دیاریکردنی دۆخی M3U
export async function hasAnySource(): Promise<boolean> {
  try {
    await ensureMigrated()
    return (await db.m3uSource.count()) > 0
  } catch {
    return false
  }
}

// ---- شیکەرەوەی M3U ----

export function parseM3U(text: string): M3UChannel[] {
  const lines = text.split('\n')
  const channels: M3UChannel[] = []
  let pending: Partial<M3UChannel> | null = null

  for (const raw of lines) {
    const line = raw.trim()
    if (!line) continue
    if (line.startsWith('#EXTINF')) {
      const name = line.slice(line.lastIndexOf(',') + 1).trim()
      const logo = /tvg-logo="([^"]*)"/.exec(line)?.[1] ?? ''
      const group = /group-title="([^"]*)"/.exec(line)?.[1] ?? 'گشتی'
      const tvgId = /tvg-id="([^"]*)"/.exec(line)?.[1] ?? ''
      pending = { name: name || 'بێ ناو', logo, group, tvgId }
    } else if (!line.startsWith('#') && pending) {
      const url = line
      let kind: M3UChannel['kind'] = 'live'
      if (/\/movie\//i.test(url)) kind = 'movie'
      else if (/\/series\//i.test(url)) kind = 'series'
      channels.push({
        name: pending.name || 'بێ ناو',
        logo: pending.logo || '',
        group: pending.group || 'گشتی',
        url,
        tvgId: pending.tvgId || '',
        kind,
      })
      pending = null
    }
  }
  return channels
}

// کەناڵ بە نیشانەی سەرچاوەکەی — بۆ فلتەری دروست لە POST
export interface M3uTaggedChannel extends M3UChannel {
  srcSection: M3uSection
}

interface AggCache {
  fingerprint: string
  fetchedAt: number
  bySection: { live: M3uTaggedChannel[]; movie: M3uTaggedChannel[]; all: M3uTaggedChannel[] }
}

interface AggResult {
  bySection: AggCache['bySection']
  error: string | null
}

const globalCache = globalThis as unknown as {
  __iptvM3uAgg?: AggCache
  __iptvM3uInflight?: Promise<AggResult | void>
}
const TTL = 5 * 60 * 1000 // ٥ خولەک

function netErrMsg(e: unknown): string {
  const m = e instanceof Error ? e.message : String(e)
  if (/fetch failed|ENOTFOUND|EAI_AGAIN|getaddrinfo/i.test(m)) {
    return 'نەکرا پەیوەندی بە سێرڤەرەکە بکرێت — بەستەری لیست پشکنین بکە'
  }
  if (/ECONNREFUSED/i.test(m)) return 'سێرڤەرەکە ڕەتی کردەوە'
  if (/abort|timeout|timed out/i.test(m)) return 'وەڵام نەگەڕایەوە — سێرڤەرەکە خاوە یان لیستەکە زۆر گەورەیە'
  return m
}

// کۆکردنەوەی هەموو سەرچاوەکان — هەر لیستێک بە جیا دەکێشرێت و یەکدەخرێن
// خێرایی: کاش + inflight dedup + stale-while-revalidate —
// داواکاری هاوشێوە یەکدەخرێن، و کاشی کۆن یەکسەر دەگەڕێتەوە لە کاتی نوێکردنەوەی پاشبنەمادا
export async function aggregateChannels(): Promise<AggResult> {
  const sources = await listSources()

  // ئەگەر هیچ سەرچاوەیەک نییە بەڵام Xtream هەیە — بەستەری get.php بەکاربهێنە ( behavior ی کۆن)
  if (sources.length === 0) {
    const s = await db.settings.findUnique({ where: { id: 'main' } })
    if (s?.xtreamHost && s.xtreamUsername && s.xtreamPassword) {
      const url = `${s.xtreamHost.replace(/\/+$/, '')}/get.php?username=${encodeURIComponent(
        s.xtreamUsername
      )}&password=${encodeURIComponent(s.xtreamPassword)}&type=m3u_plus&output=ts`
      sources.push({ id: 'xtream', name: 'Xtream', url, section: 'both', sortOrder: 0 })
    }
  }

  const fingerprint = sources.map((s) => `${s.id}|${s.url}|${s.section}`).join(';;')
  const cached = globalCache.__iptvM3uAgg
  if (cached && cached.fingerprint === fingerprint) {
    if (Date.now() - cached.fetchedAt < TTL) {
      return { bySection: cached.bySection, error: null }
    }
    // کاشی کۆن — هەر ئێستا وەڵام بدەرەوە (بەکارهێنەر چاوەڕوان نابێت) و پاشبنەمادا نوێی بکەرەوە
    refreshAggregate(fingerprint, sources)
    return { bySection: cached.bySection, error: null }
  }

  // کاش نییە — ئەگەر داواکاری هاوشێوە لە جێبەجێکردندایە (بۆ نموونە live + movie پێکەوە) چاوەڕوانی بە
  const inflight = globalCache.__iptvM3uInflight
  if (inflight) {
    try {
      const r = await inflight
      if (r) return r
    } catch {
      /* بەردەوام بە — دووبارە هەوڵ بدە */
    }
  }

  const p = fetchAllSources(sources).then((res) => {
    // تەنها کاشی بکە ئەگەر داتای دروست هەبوو — هەڵەی تۆڕ کاش نەکە
    if (!(res.error && res.bySection.all.length === 0)) {
      globalCache.__iptvM3uAgg = { fingerprint, fetchedAt: Date.now(), bySection: res.bySection }
    }
    return res
  })
  globalCache.__iptvM3uInflight = p
  try {
    return await p
  } finally {
    globalCache.__iptvM3uInflight = undefined
  }
}

// نوێکردنەوەی پاشبنەمای کاشی کۆن — داواکاری زۆر یەکدەخرێن، هەڵەش کاشی کۆن دەشێوێنێت نا
function refreshAggregate(fingerprint: string, sources: M3uSourceRow[]): void {
  if (globalCache.__iptvM3uInflight) return
  const p = fetchAllSources(sources)
    .then((res) => {
      if (!(res.error && res.bySection.all.length === 0)) {
        globalCache.__iptvM3uAgg = { fingerprint, fetchedAt: Date.now(), bySection: res.bySection }
      }
    })
    .catch(() => {
      /* کاشی کۆن دەمێنێتەوە */
    })
    .finally(() => {
      globalCache.__iptvM3uInflight = undefined
    })
  globalCache.__iptvM3uInflight = p
}

// هێنانی هەموو سەرچاوەکان و پۆلێنکردن — بێ کاش (کاش لە aggregateChannels دا بەڕێوە دەچێت)
async function fetchAllSources(sources: M3uSourceRow[]): Promise<AggResult> {
  const live: M3uTaggedChannel[] = []
  const movie: M3uTaggedChannel[] = []
  const all: M3uTaggedChannel[] = []
  let firstError: string | null = null

  for (const src of sources) {
    try {
      const res = await fetch(src.url, {
        signal: AbortSignal.timeout(60000),
        headers: { 'User-Agent': 'Mozilla/5.0 (IPTV Web Player)' },
      })
      if (!res.ok) {
        if (!firstError) firstError = 'لیستەکە وەڵام نەدایەوە'
        continue
      }
      const text = await res.text()
      if (!text.includes('#EXTM3U')) {
        if (!firstError) firstError = 'فایلەکە لیستی M3U نییە'
        continue
      }
      const channels = parseM3U(text)
      for (const ch of channels) {
        const tagged: M3uTaggedChannel = { ...ch, srcSection: src.section }
        all.push(tagged)
        // لیستی (هەردووکیان) — بەپێی جۆری خۆکارانە دابەش دەبێت (behavior ی کۆن)
        // لیستی جیاکراوەی کەناڵ/فلیم — هەموو تۆمارەکانی دەگرێتەوە بێ فلتەر
        if (src.section === 'both') {
          if (ch.kind === 'live') live.push(tagged)
          else if (ch.kind === 'movie' || ch.kind === 'series') movie.push(tagged)
        } else if (src.section === 'live') {
          live.push(tagged)
        } else {
          movie.push(tagged)
        }
      }
    } catch (e) {
      if (!firstError) firstError = netErrMsg(e)
    }
  }

  return { bySection: { live, movie, all }, error: firstError }
}
