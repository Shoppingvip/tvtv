// گەڕاندنەوەی داتا لە پاشکۆی snapshot ەوە بۆ داتابەیسی زیندوو
// Banner (7) + Product (5) + Settings (m3uUrl + adminPin ی ئەسڵی)
import { createClient } from '@libsql/client'

const SNAP = 'file:/tmp/my-project/db/custom.db'
const LIVE = process.env.DATABASE_URL ?? 'file:/home/z/my-project/db/custom.db'

const snap = createClient({ url: SNAP })
const live = createClient({ url: LIVE })

async function copyTable(table, cols) {
  const r = await snap.execute(`SELECT ${cols.join(', ')} FROM ${table}`)
  console.log(`${table}: ${r.rows.length} rows to restore`)
  if (r.rows.length === 0) return 0
  const ph = cols.map(() => '?').join(', ')
  const sql = `INSERT OR REPLACE INTO ${table} (${cols.join(', ')}) VALUES (${ph})`
  for (const row of r.rows) {
    await live.execute({
      sql,
      args: cols.map((c) => (row[c] === undefined ? null : row[c])),
    })
  }
  return r.rows.length
}

const b = await copyTable('Banner', ['id', 'name', 'data', 'sortOrder', 'createdAt'])
const p = await copyTable('Product', ['id', 'name', 'price', 'description', 'image', 'sortOrder', 'createdAt'])
const s = await copyTable('Settings', ['id', 'appName', 'adminPin', 'xtreamHost', 'xtreamUsername', 'xtreamPassword', 'm3uUrl', 'updatedAt'])

// پشکنین
const chk = async (t) => (await live.execute(`SELECT COUNT(*) AS n FROM ${t}`)).rows[0].n
console.log(`VERIFY live db -> Banner=${await chk('Banner')} Product=${await chk('Product')} Settings=${await chk('Settings')}`)
const st = await live.execute('SELECT m3uUrl IS NOT NULL AS has_m3u, adminPin IS NOT NULL AND adminPin != \'\' AS has_pin, xtreamHost FROM Settings WHERE id=\'main\'')
console.log(`VERIFY settings -> has_m3u=${st.rows[0].has_m3u} has_pin=${st.rows[0].has_pin} xtreamHost=${st.rows[0].xtreamHost ?? 'null'}`)
console.log(`DONE banners=${b} products=${p} settings=${s}`)
