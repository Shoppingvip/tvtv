<?php
// دەرچوون و سڕینەوەی زانیارییەکان — تەنها بەڕێوەبەر
// وەشانێکی PHP ی src/app/api/settings/logout/route.ts
require __DIR__ . '/../lib.php';
handle_preflight();

try {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        json_out(['error' => 'ڕێگەیەکی نەزانراو'], 405);
    }
    if (!is_admin()) forbidden();

    turso_exec("DELETE FROM \"Settings\"");
    turso_exec("DELETE FROM \"Favorite\"");
    turso_exec("DELETE FROM \"History\"");

    json_out(['ok' => true]);
} catch (Throwable $e) {
    json_out(['error' => 'هەڵەیەک ڕوویدا'], 500);
}
