import { NextRequest, NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'
export const maxDuration = 300

// پرۆکسی پەخش و وێنەکان — چارەسەری CORS و Mixed Content
function absolutize(base: string, uri: string): string {
  try {
    return new URL(uri, base).toString()
  } catch {
    return uri
  }
}

function proxied(url: string): string {
  return `/api/proxy?url=${encodeURIComponent(url)}`
}

function rewriteManifest(text: string, baseUrl: string): string {
  return text
    .split('\n')
    .map((line) => {
      const t = line.trim()
      if (!t) return line
      if (t.startsWith('#')) {
        return line
          .replace(/URI="([^"]+)"/g, (_m, u: string) => `URI="${proxied(absolutize(baseUrl, u))}"`)
          .replace(/URI='([^']+)'/g, (_m, u: string) => `URI='${proxied(absolutize(baseUrl, u))}'`)
      }
      return proxied(absolutize(baseUrl, t))
    })
    .join('\n')
}

export async function GET(req: NextRequest) {
  const target = req.nextUrl.searchParams.get('url')
  if (!target || !/^https?:\/\//i.test(target)) {
    return NextResponse.json({ error: 'بەستەری دروست نییە' }, { status: 400 })
  }

  try {
    const headers: Record<string, string> = {
      'User-Agent': 'Mozilla/5.0 (IPTV Web Player)',
      Accept: '*/*',
    }
    const range = req.headers.get('range')
    if (range) headers.Range = range

    const upstream = await fetch(target, { headers, redirect: 'follow' })

    const contentType = upstream.headers.get('content-type') ?? 'application/octet-stream'
    const isManifest =
      contentType.includes('mpegurl') ||
      contentType.includes('vnd.apple') ||
      /\.m3u8(\?|$)/i.test(target)
    // وێنەکان (لۆگۆ و پۆستەر) بە درێژی کاش دەکرێن — گەڕانەوە بۆ بەشەکان یەکسەر دەبێت
    // k=img لە imgProxy ـەوە دێت — وێنە بە شێوەی بنەڕەتی ناگۆڕێن، هەفتەیەک کاش باشە
    const isImage =
      req.nextUrl.searchParams.get('k') === 'img' ||
      /^image\//i.test(contentType)

    if (isManifest && upstream.ok) {
      const text = await upstream.text()
      return new NextResponse(rewriteManifest(text, upstream.url || target), {
        status: 200,
        headers: {
          'Content-Type': 'application/vnd.apple.mpegurl',
          'Cache-Control': 'no-store',
          'Access-Control-Allow-Origin': '*',
        },
      })
    }

    // ڕاپەکردنی ڕاستەوخۆی بایتەکان (سێگمێنت، وێنە، ڤیدیۆ)
    const out = new Headers()
    out.set('Content-Type', contentType)
    // وێنە: کاشی درێژ (لۆگۆ/پۆستەر ناگۆڕێن) — پەخش: هەرگیز کاش نەکە
    // تەنها وەڵامی سەرکەوتوو کاش دەکرێت — هەڵەکان (404/429...) کاش نەبن
    out.set('Cache-Control', isImage && upstream.ok ? 'public, max-age=604800, immutable' : 'no-store')
    out.set('Access-Control-Allow-Origin', '*')
    if (upstream.headers.get('accept-ranges')) out.set('Accept-Ranges', upstream.headers.get('accept-ranges')!)
    if (upstream.headers.get('content-range')) out.set('Content-Range', upstream.headers.get('content-range')!)
    const enc = upstream.headers.get('content-encoding')
    if (!enc && upstream.headers.get('content-length')) {
      out.set('Content-Length', upstream.headers.get('content-length')!)
    }

    return new NextResponse(upstream.body, { status: upstream.status, headers: out })
  } catch (e) {
    const msg = e instanceof Error ? e.message : 'پرۆکسی سەرکەوتوو نەبوو'
    return NextResponse.json({ error: msg }, { status: 502 })
  }
}
