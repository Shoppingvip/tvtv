#!/usr/bin/env bash
# Static export build for InfinityFree (or any static host).
# - Stashes src/app/api, src/middleware.ts, src/instrumentation.ts (server-only,
#   unsupported by `output: 'export'`), builds, then restores them.
# - Uses distDir=.next-static (set in next.config.ts when BUILD_STATIC=1) so the
#   RUNNING dev server's .next directory is never touched.
# - Output: .next-static/ (Next 16 Turbopack writes the export into distDir)
#   →  zip: download/iptv-infinityfree.zip (با .htaccess + PHP API لە deploy/infinityfree-php)
set -euo pipefail
cd /home/z/my-project

STASH=".static-stash"
restore() {
  if [ -d "$STASH/api" ]; then mv "$STASH/api" src/app/api; fi
  if [ -f "$STASH/middleware.ts" ]; then mv "$STASH/middleware.ts" src/middleware.ts; fi
  if [ -f "$STASH/instrumentation.ts" ]; then mv "$STASH/instrumentation.ts" src/instrumentation.ts; fi
  rmdir "$STASH" 2>/dev/null || true
}
trap restore EXIT

rm -rf "$STASH" .next-static
mkdir -p "$STASH"
mv src/app/api "$STASH/api"
[ -f src/middleware.ts ] && mv src/middleware.ts "$STASH/"
[ -f src/instrumentation.ts ] && mv src/instrumentation.ts "$STASH/"

echo ">>> Building static export (server files stashed)…"
BUILD_STATIC=1 npx next build

trap - EXIT
restore

echo ">>> Verifying .next-static/ …"
for f in .next-static/index.html .next-static/config.js .next-static/sw.js .next-static/manifest.webmanifest .next-static/icon-192.png; do
  [ -f "$f" ] || { echo "MISSING: $f"; exit 1; }
done
echo ">>> .next-static OK"

# package zip (contents at zip root → extract directly into htdocs)
echo ">>> Creating download/iptv-infinityfree.zip …"
rm -f download/iptv-infinityfree.zip

# PHP API + .htaccess + README لە deploy/infinityfree-php ەوە زیاد دەکرێن
cp -r deploy/infinityfree-php/api .next-static/api
cp deploy/infinityfree-php/.htaccess .next-static/.htaccess
cp deploy/infinityfree-php/README-KURDISH.txt .next-static/README-KURDISH.txt

# ناوەڕۆکی zip بە خۆی لە htdocs دادەبەزێت (فایلە شاراوەکانیش — .htaccess)
cd .next-static && zip -qr ../download/iptv-infinityfree.zip . && cd ..
echo ">>> Done: download/iptv-infinityfree.zip"
unzip -l download/iptv-infinityfree.zip | head -8
unzip -l download/iptv-infinityfree.zip | rg -c "\.php$" || true
