// سیستەمی دەسەڵاتی بەڕێوەبەر — تەنها خاوەن ئەپەکە دەتوانێت زانیارییەکان بگۆڕێت
import { createHash } from 'crypto'
import { db } from '@/lib/db'
import type { NextRequest } from 'next/server'

export const ADMIN_COOKIE = 'iptv_admin'

// نیشانەی نهێنی بۆ cookie — لە کۆدی بەڕێوەبەرەوە دروست دەکرێت
// کاتێک کۆدەکە دەگۆڕدرێت، هەموو دانیشتنە کۆنەکان بەتاڵ دەبنەوە
export function adminToken(pin: string): string {
  return createHash('sha256').update(`iptv-admin-v1:${pin}`).digest('hex')
}

export function adminCookieOptions() {
  return {
    httpOnly: true,
    sameSite: 'lax' as const,
    path: '/',
    maxAge: 60 * 60 * 12, // ١٢ کاتژمێر
  }
}

// ئایا ئەم داواکارییە لە بەڕێوەبەرەوە هاتووە؟
export async function isAdminRequest(req: NextRequest): Promise<boolean> {
  const s = await db.settings.findUnique({ where: { id: 'main' } })
  if (!s || !s.adminPin) return false
  const token = req.cookies.get(ADMIN_COOKIE)?.value
  return !!token && token === adminToken(s.adminPin)
}

// وەڵامی ڕەتکردنەوە بۆ ئەوانەی بەڕێوەبەر نین
export function forbidden() {
  return Response.json(
    { error: 'تەنها بەڕێوەبەر دەتوانێت ئەم کردارە بکات — تکایە کۆدی بەڕێوەبەر دابنێ' },
    { status: 403 }
  )
}
