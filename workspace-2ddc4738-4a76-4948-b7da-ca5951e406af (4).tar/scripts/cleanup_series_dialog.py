# پاککردنەوەی SeriesDialog لە details.tsx — چیتر بەکارنەهاتووە دوای لابردنی بەشی زنجیرە
import io

p = '/home/z/my-project/src/components/iptv/details.tsx'
s = io.open(p, encoding='utf-8').read()

# 1) لابردنی بەشی زنجیرە (SeriesDialog) — لە سەرەتای نیشانەکە بۆ سەرەتای بەشی فلیم
start = s.index('// ---------- زنجیرە ----------')
end = s.index('// ---------- فلیم ----------')
s = s[:start] + s[end:]

# 2) لابردنی interface ی SeriesInfo
start = s.index('interface SeriesInfo {')
end = s.index('async function xtreamApi')
s = s[:start] + s[end:]

# 3) ڕاستکردنەوەی سەردێڕ و ئیمپۆرت
s = s.replace(
    '// دیالۆگی زانیاری — فلیم و زنجیرەکان',
    '// دیالۆگی زانیاری فلیم',
)
s = s.replace(
    "import { Play, Loader2, Calendar, Star, Users } from 'lucide-react'",
    "import { Play, Loader2, Calendar, Star } from 'lucide-react'",
)

io.open(p, 'w', encoding='utf-8').write(s)
print('SeriesDialog removed OK')
print('SeriesDialog still present?' , 'SeriesDialog' in s)
print('SeriesInfo still present?', 'SeriesInfo' in s)
print('Users still imported?', 'Users' in s)
