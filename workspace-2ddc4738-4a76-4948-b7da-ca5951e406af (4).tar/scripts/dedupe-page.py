#!/usr/bin/env python3
# دەستپێکی پاککردنەوە: لابردنی کۆدی دووبارەی M3uSourcesManager لە page.tsx
# (پانێلی M3uSourcesPanel لە فایلی sources.tsx ماوەتەوە وەک یەکا تەنها)
import io, sys

p = '/home/z/my-project/src/app/page.tsx'
text = io.open(p, encoding='utf-8').read()
lines = text.split('\n')

# ١) دۆزینەوەی بڵۆکی فەنکشنەکان — لە کۆمێنتەوە تا function InfoRow
start = end = None
for i, l in enumerate(lines):
    if l.startswith('// ---- لیستەکانی M3U — زیادکردن، ڕیزکردنەوە (پێش/دوا) و سڕینەوە بە جیا بۆ کەناڵ و فلیم ----'):
        start = i
    if l.startswith('function InfoRow'):
        end = i
        break
if start is None or end is None or start >= end:
    print('BLOCK NOT FOUND — start:', start, 'end:', end)
    sys.exit(1)

# بڵۆک + دێڕی بەتاڵی پێش خۆی بسڕەوە (بۆ خلوژانی دوو دێڕی بەتاڵ)
del lines[max(0, start - 1):end]

text = '\n'.join(lines)

# ٢) لابردنی دوگمەی بەکارهێنانی M3uSourcesManager لە SettingsScreen
usage = (
    "\n"
    "      {/* لیستەکانی M3U — بە جیا بۆ کەناڵ و فلیم — تەنها لە دۆخی M3U */}\n"
    "      {status.mode !== 'xtream' ? <M3uSourcesManager onChanged={onRefreshStatus} /> : null}\n"
)
if usage not in text:
    print('USAGE BLOCK NOT FOUND')
    sys.exit(1)
text = text.replace(usage, '\n')

# ٣) پاککردنەوەی import ـە بێ بەکارهاتنەکان (ListVideo, ArrowUp, ArrowDown)
old_imp = 'CalendarClock, ListVideo, ArrowUp, ArrowDown }'
new_imp = 'CalendarClock }'
if old_imp in text:
    text = text.replace(old_imp, new_imp)

io.open(p, 'w', encoding='utf-8').write(text)
print('OK — removed block lines:', end - start, '| usage removed | imports cleaned')
