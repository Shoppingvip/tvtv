'use client'

// دۆخی تیڤی — دۆزینەوەی ئۆتۆماتیکی تیڤی + پڕەکی (لابردنی ناونیشانی وێبگەڕ)
import { useCallback, useEffect, useState } from 'react'

const STORAGE_KEY = 'iptv-tv-mode'

// یوئەی تیڤییەکان — Smart TV، Android TV، Fire TV، webOS، Tizen ...
const TV_UA =
  /SMART[- ]?TV|SmartTV|AppleTV|GoogleTV|HbbTV|NetCast|WEBOS|Web0S|Tizen|Viera|BRAVIA|AFT[A-Z]|FireTV|CrKey|Android TV|GoogleTV|Crunchfish|PhilipsTV/i

function detectTv(): boolean {
  if (typeof window === 'undefined') return false
  try {
    if (localStorage.getItem(STORAGE_KEY) === '1') return true
    if (localStorage.getItem(STORAGE_KEY) === '0') return false
  } catch { /* localStorage بەردەست نییە */ }
  // دۆزینەوەی خۆکارانە لە یوئەی
  if (TV_UA.test(navigator.userAgent)) return true
  // تیڤییەکانی بێ یوئەی تایبەت — شاشەی گەورە (≥1600px) بەبێ دەس = تیڤی
  // هەردوو screen.width و innerWidth دەپشکنین — هەندێک وێبگەڕی تیڤی screen بە هەڵە ڕاپۆرت دەکەن
  // موبایل و تابلێت هەرگیز ئەم قەبارەیە نایگەن، بۆیە هەڵە ناکات
  try {
    const w = Math.max(window.screen.width || 0, window.innerWidth || 0)
    if (w >= 1600 && !('ontouchstart' in window)) return true
  } catch { /* پشتگوێخستن */ }
  // زۆربەی وێبگەڕەکانی تیڤی شاشەکەیان 1280×720 ڕاپۆرت دەکەن — ئەگەر بێ دەس (تەچ)
  // و بێ ماوس (pointer: fine) بێت، بێگومان تیڤییە نەک کۆمپیوتەری سەردەمی
  try {
    const noTouch = !('ontouchstart' in window) && (navigator.maxTouchPoints ?? 0) === 0
    const noMouse = !(window.matchMedia && window.matchMedia('(pointer: fine)').matches)
    const w2 = Math.max(window.screen.width || 0, window.innerWidth || 0)
    if (noTouch && noMouse && w2 >= 1200) return true
  } catch { /* پشتگوێخستن */ }
  return false
}

export function useTvMode() {
  const [tvMode, setTvMode] = useState(false)
  const [ready, setReady] = useState(false)

  // خوێندنەوەی دۆخی سەرەتایی — تەنها لە کڵایەنت، بۆ ڕێگرتن لە جیاوازی hydration
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- دۆزینەوەی یەکجارەکی لە localStorage/UA (دەرەکی، بۆ شێوازی SSR)
    setTvMode(detectTv())
    setReady(true)
  }, [])

  // کردنەوە/داخستنی پڕەکی — لابردنی ناونیشانی وێبگەڕ لەسەر تیڤی
  // پشتگیری وێبکیت ی کۆنیش — زۆربەی وێبگەڕە کۆنەکانی تیڤی تەنها webkitRequestFullscreen هەیە
  const enterFullscreen = useCallback(async () => {
    try {
      const doc = document as Document & { webkitFullscreenElement?: Element | null }
      const el = document.documentElement as HTMLElement & {
        webkitRequestFullscreen?: () => Promise<void> | void
      }
      if (!document.fullscreenElement && !doc.webkitFullscreenElement) {
        if (el.requestFullscreen) await el.requestFullscreen({ navigationUI: 'hide' })
        else if (el.webkitRequestFullscreen) await el.webkitRequestFullscreen()
      }
    } catch { /* هەندێک وێبگەڕی تیڤی ڕێگە نادەن — دۆخەکە بەردەوام دەبێت */ }
  }, [])

  const exitFullscreen = useCallback(async () => {
    try {
      const doc = document as Document & {
        webkitFullscreenElement?: Element | null
        webkitExitFullscreen?: () => Promise<void> | void
      }
      if (document.fullscreenElement) await document.exitFullscreen()
      else if (doc.webkitFullscreenElement && doc.webkitExitFullscreen) await doc.webkitExitFullscreen()
    } catch { /* پشتگوێخستن */ }
  }, [])

  const setTv = useCallback(
    (on: boolean) => {
      setTvMode(on)
      try {
        localStorage.setItem(STORAGE_KEY, on ? '1' : '0')
      } catch { /* پشتگوێخستن */ }
      if (on) void enterFullscreen()
      else void exitFullscreen()
    },
    [enterFullscreen, exitFullscreen]
  )

  const toggleTv = useCallback(() => {
    // ئەگەر دۆخی تیڤی چالاکە بەڵام پڕەکی کۆتایی هاتووە (Esc ی وێبگەڕ) — تەنها پڕەکی بگەڕێنەوە
    const doc = document as Document & { webkitFullscreenElement?: Element | null }
    if (tvMode && typeof document !== 'undefined' && !document.fullscreenElement && !doc.webkitFullscreenElement) {
      void enterFullscreen()
      return
    }
    setTv(!tvMode)
  }, [tvMode, setTv, enterFullscreen])

  // پڕەکی خۆکار — لە یەکەم لێدانی ڕیمۆت یان دەس، ناونیشانی وێبگەڕ دەشاردرێتەوە
  // وێبگەڕەکان پێویستیان بە جوڵەی یەکەمە بۆ requestFullscreen — بۆیە گوێگرێک دادەنێین
  useEffect(() => {
    if (!ready || !tvMode) return
    // هەوڵی ڕاستەوخۆ — هەندێک وێبگەڕی تیڤی پێویستیان بە جوڵە نییە
    void enterFullscreen()

    const fire = () => void enterFullscreen()
    window.addEventListener('keydown', fire, { once: true, passive: true })
    window.addEventListener('pointerdown', fire, { once: true, passive: true })
    window.addEventListener('touchend', fire, { once: true, passive: true })
    return () => {
      window.removeEventListener('keydown', fire)
      window.removeEventListener('pointerdown', fire)
      window.removeEventListener('touchend', fire)
    }
  }, [ready, tvMode, enterFullscreen])

  // ئەگەر پڕەکی کۆتایی هات (Esc ی وێبگەڕ) — لە یەکەم جوڵەی داهاتوو بیگەڕێنەوە
  useEffect(() => {
    if (!ready || !tvMode) return
    const onFsChange = () => {
      if (document.fullscreenElement) return
      const fire = () => void enterFullscreen()
      window.addEventListener('keydown', fire, { once: true, passive: true })
      window.addEventListener('pointerdown', fire, { once: true, passive: true })
      window.addEventListener('touchend', fire, { once: true, passive: true })
      setTimeout(() => {
        window.removeEventListener('keydown', fire)
        window.removeEventListener('pointerdown', fire)
        window.removeEventListener('touchend', fire)
      }, 30_000)
    }
    document.addEventListener('fullscreenchange', onFsChange)
    return () => document.removeEventListener('fullscreenchange', onFsChange)
  }, [ready, tvMode, enterFullscreen])

  // کلاسی tv-mode لەسەر html دادەنێت — CSS ی گەورەکردنی ڕووکار چالاک دەکات
  useEffect(() => {
    if (!ready) return
    document.documentElement.classList.toggle('tv-mode', tvMode)
    return () => document.documentElement.classList.remove('tv-mode')
  }, [tvMode, ready])

  // ============ ناڤیگەیشنی ئاسایی (Spatial Navigation) بۆ ڕیمۆتی تیڤی ============
  // ئاراستەکان بۆ نزیکترین توخمی فۆکەسکردن دەبەن — وەک ئەپی تیڤی ڕاستەقینە
  useEffect(() => {
    if (!ready || !tvMode) return

    const isFocusable = (el: Element): el is HTMLElement =>
      (el instanceof HTMLElement &&
        !el.hasAttribute('disabled') &&
        el.getAttribute('tabindex') !== '-1' &&
        (el.tagName === 'BUTTON' ||
          el.tagName === 'A' ||
          el.tagName === 'INPUT' ||
          el.tagName === 'SELECT' ||
          el.tagName === 'TEXTAREA' ||
          el.tabIndex >= 0))

    const handler = (e: KeyboardEvent) => {
      const key = e.key
      if (key !== 'ArrowUp' && key !== 'ArrowDown' && key !== 'ArrowLeft' && key !== 'ArrowRight') return

      const active = document.activeElement as HTMLElement | null
      // لە ناو پلەیەردا یان کاتێک پلەیەر کراوەیە — پلەیەر خۆی هەموو دوگمەیەک بەڕێوە دەبات
      // (گۆڕینی کەناڵ بە سەرەوە/خوارەوە + دەنگ) — ئەگینا فۆکەس بێدەنگ دەچێتە سەر توخمە شاراوەکانی پشتەوە
      if (document.querySelector('[data-player-root]')) return
      if (active?.closest('[data-player-root]')) return

      // لە ناو خانەی نووسیندا — تەنها سەرەوە/خوارەوە فۆکەس دەگوازنەوە
      const inField = !!(active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA' || active.isContentEditable))
      if (inField && (key === 'ArrowLeft' || key === 'ArrowRight')) return

      // ئەگەر دیالۆگ کراوەیە — فۆکەس تەنها لە ناودا بجوڵێت
      const dialog = active?.closest('[role="dialog"]')
      const anyDialog = document.querySelector('[role="dialog"]')
      if (anyDialog && !dialog) return
      const scope: ParentNode = dialog ?? document

      const candidates = Array.from(scope.querySelectorAll<HTMLElement>(
        'button, a[href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
      )).filter((el) => isFocusable(el) && el.offsetParent !== null)

      if (candidates.length === 0) return
      if (!active) {
        candidates[0]?.focus()
        e.preventDefault()
        return
      }

      const rect = active.getBoundingClientRect()
      const cx = rect.left + rect.width / 2
      const cy = rect.top + rect.height / 2

      let best: HTMLElement | null = null
      let bestScore = Infinity

      for (const el of candidates) {
        if (el === active) continue
        const r = el.getBoundingClientRect()
        const dx = r.left + r.width / 2 - cx
        const dy = r.top + r.height / 2 - cy

        // فلتەری ئاراستە — بە ئاراستەی فیزیکی شاشە (بۆ ڕیمۆت)
        if (key === 'ArrowRight' && dx <= 4) continue
        if (key === 'ArrowLeft' && dx >= -4) continue
        if (key === 'ArrowDown' && dy <= 4) continue
        if (key === 'ArrowUp' && dy >= -4) continue

        const dist = dx * dx + dy * dy
        // سزادانی لادانی زۆر — بۆ ئەوەی ستوونی نزیک پێش ئەوەی دوور بێت بێت
        const ortho = key === 'ArrowUp' || key === 'ArrowDown' ? Math.abs(dx) : Math.abs(dy)
        const score = dist + ortho * ortho * 2.5
        if (score < bestScore) {
          bestScore = score
          best = el
        }
      }

      if (best) {
        e.preventDefault()
        best.focus()
        best.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'smooth' })
      } else {
        e.preventDefault() // لە لێوارەکەدا — هیچ نەکات، ڕێگە مەدە پەڕە بجولێت
      }
    }

    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [ready, tvMode])

  return { tvMode, setTv, toggleTv, ready, enterFullscreen }
}
