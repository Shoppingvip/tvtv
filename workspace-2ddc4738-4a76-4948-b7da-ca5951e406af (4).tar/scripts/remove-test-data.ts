// سڕینەوەی زانیاری تاقیکردنەوە لە داتابەیس — تەنها نرخی نموونەیی لادەبات، PIN دەمێنێتەوە
import { createClient } from '@libsql/client'

const DATABASE_URL = process.env.DATABASE_URL ?? 'file:/home/z/my-project/db/custom.db'
const dbPath = DATABASE_URL.replace(/^file:/, '')
const db = createClient({ url: `file:${dbPath}` })

const r = await db.execute(`SELECT "m3uUrl","xtreamHost","adminPin" FROM "Settings" WHERE "id"='main'`)
const row = r.rows[0]
console.log('before:', JSON.stringify(row))

const m3u = row?.m3uUrl ? String(row.m3uUrl) : ''
// تەنها ئەگەر نرخی تاقیکردنەوەیە — لابەرە
if (/example-test|test\.com|localhost|127\.0\.0\.1/i.test(m3u)) {
  await db.execute(`UPDATE "Settings" SET "m3uUrl"=NULL WHERE "id"='main'`)
  console.log('test M3U URL removed')
} else {
  console.log('no test URL found — nothing changed')
}

const r2 = await db.execute(`SELECT "m3uUrl","xtreamHost","adminPin" FROM "Settings" WHERE "id"='main'`)
console.log('after:', JSON.stringify(r2.rows[0]))
db.close()
