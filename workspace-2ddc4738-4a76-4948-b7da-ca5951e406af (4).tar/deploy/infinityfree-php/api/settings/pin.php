<?php
// نوێکردنەوەی کۆدی بەڕێوەبەر — تەنها بەڕێوەبەر
// وەشانێکی PHP ی src/app/api/settings/pin/route.ts
require __DIR__ . '/../lib.php';
handle_preflight();

try {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        json_out(['error' => 'ڕێگەیەکی نەزانراو'], 405);
    }
    if (!is_admin()) forbidden();

    $body = body_json();
    $has = array_key_exists('adminPin', $body);
    $pin = trim_str($body['adminPin'] ?? null);

    if ($has && $pin !== '' && !preg_match('/^\d{3,6}$/', $pin)) {
        json_out(['error' => 'کۆدی بەڕێوەبەر دەبێت ٣ بۆ ٦ ژمارە بێت'], 400);
    }

    if ($has) {
        turso_exec(
            "INSERT INTO \"Settings\" (\"id\", \"adminPin\", \"updatedAt\") VALUES ('main', ?, " . sql_now() . ") " .
            "ON CONFLICT(\"id\") DO UPDATE SET \"adminPin\" = excluded.\"adminPin\", \"updatedAt\" = " . sql_now(),
            [$pin !== '' ? $pin : null]
        );
        // cookie نوێ دابنێ بۆ بەردەوامی دانیشتنەکە — یان بسڕەوە ئەگەر کۆدەکە لابرا
        set_admin_cookie($pin);
    }

    json_out(['ok' => true]);
} catch (Throwable $e) {
    json_out(['error' => 'هەڵەیەک ڕوویدا'], 500);
}
