#!/bin/bash
# دەستپێکردنی ئەپەکە لەسەر سێرڤەر (Tencent Cloud VPS)
# پێش دەستپێک: داتابەیس پارێزراو دەکات (دروستکردنی خشتەکان + چاککردنەوەی خۆکار)
cd "$(dirname "$0")/.."

export NODE_ENV=production
export PORT=3000
export HOSTNAME=127.0.0.1
# داتابەیسی ناوخۆیی — لەسەر VPS پێویست بە Turso نییە، هەموو داتاکان لەسەر سێرڤەرەکەت دەمێنن
export DATABASE_URL="${DATABASE_URL:-file:$(pwd)/db/custom.db}"

mkdir -p db
echo "[start-prod] پارێزەری داتابەیس..."
bun scripts/ensure-db.ts

echo "[start-prod] دەستپێکردنی سێرڤەر لەسەر پۆرتی 3000..."
exec bun .next/standalone/server.js
