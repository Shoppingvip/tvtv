import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { isAdminRequest, forbidden } from '@/lib/admin'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  try {
    if (!(await isAdminRequest(req))) return forbidden()
    const items = await db.history.findMany({ orderBy: { watchedAt: 'desc' }, take: 24 })
    return NextResponse.json({ items })
  } catch {
    return NextResponse.json({ error: 'هەڵە لە خوێندنەوەی مێژوو' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    if (!(await isAdminRequest(req))) return forbidden()
    const body = (await req.json()) as {
      itemType: string
      itemId: string
      name: string
      logo?: string | null
      extra?: string | null
    }
    if (!body.itemType || !body.itemId || !body.name) {
      return NextResponse.json({ error: 'زانیاری ناتەواو' }, { status: 400 })
    }
    await db.history.upsert({
      where: { itemType_itemId: { itemType: body.itemType, itemId: body.itemId } },
      update: {
        name: body.name,
        logo: body.logo ?? null,
        extra: body.extra ?? null,
        watchedAt: new Date(),
      },
      create: {
        itemType: body.itemType,
        itemId: body.itemId,
        name: body.name,
        logo: body.logo ?? null,
        extra: body.extra ?? null,
      },
    })
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'هەڵە لە تۆمارکردن' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest) {
  try {
    if (!(await isAdminRequest(req))) return forbidden()
    const itemId = req.nextUrl.searchParams.get('itemId')
    if (itemId === 'ALL') {
      await db.history.deleteMany({})
      return NextResponse.json({ ok: true })
    }
    if (itemId) {
      await db.history.deleteMany({ where: { itemId } })
    }
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'هەڵە لە سڕینەوە' }, { status: 500 })
  }
}
