'use client'
import { apiUrl } from '@/lib/api'

// پانێلی بەڕێوەبردنی فلیمەکانی Google Drive — بەشی بەڕێوەبەر
// زیادکردنی فلیم بە بەستەری هاوبەش (فایل یان فۆڵدەر — خۆکارانە دەناسرێتەوە) + سڕینەوە
import { useCallback, useEffect, useState } from 'react'
import {
  HardDrive, Plus, Trash2, Loader2, RefreshCw, KeyRound, FolderOpen, Film, Info, ChevronDown, ChevronUp,
} from 'lucide-react'
import { cn } from '@/lib/utils'

export interface DriveVideoItem {
  id: string
  fileId: string
  name: string
  folderId: string | null
  folderName: string | null
  thumbnail: string | null
  size: string | null
  sortOrder: number
}

export function DrivePanel() {
  const [items, setItems] = useState<DriveVideoItem[]>([])
  const [hasKey, setHasKey] = useState(false)
  const [apiKey, setApiKey] = useState('')
  const [keyBusy, setKeyBusy] = useState(false)
  const [showSteps, setShowSteps] = useState(false)
  const [loading, setLoading] = useState(true)
  const [link, setLink] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [notice, setNotice] = useState<string | null>(null)
  const [workingId, setWorkingId] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch(apiUrl('/api/drive'))
      const data = (await res.json()) as { items?: DriveVideoItem[]; hasKey?: boolean; error?: string }
      if (!res.ok) throw new Error(data.error ?? 'نەکرا لیستەکە بخوێنرێتەوە')
      setItems(data.items ?? [])
      setHasKey(!!data.hasKey)
      setError(null)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'هەڵەیەک ڕوویدا')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { void load() }, [load])

  // زیادکردنی فلیم یان فۆڵدەر — بەستەرەکە لە سێرڤەرەوە دەناسرێتەوە
  const add = async () => {
    if (!link.trim() || busy) return
    setBusy(true)
    setError(null)
    setNotice(null)
    try {
      const res = await fetch(apiUrl('/api/drive'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ link: link.trim() }),
      })
      const data = (await res.json()) as { kind?: string; imported?: number; folderName?: string; name?: string; error?: string }
      if (!res.ok) throw new Error(data.error ?? 'نەکرا زیاد بکرێت')
      if (data.kind === 'folder') {
        setNotice(`${data.imported ?? 0} فلیم لە فۆڵدەری «${data.folderName ?? 'Drive'}» هێنران ✅`)
      } else {
        setNotice(`«${data.name ?? 'فلیمەکە'}» زیادکرا ✅ — لە بەشی فلیمەکان دەردەکەوێت`)
      }
      setLink('')
      await load()
    } catch (e) {
      setError(e instanceof Error ? e.message : 'نەکرا زیاد بکرێت')
    } finally {
      setBusy(false)
    }
  }

  // پاشەکەوت یان سڕینەوەی کلیلی API — ئارەزوومەندانە (بۆ فۆڵدەری گەورە وردترە)
  const saveKey = async (clear = false) => {
    if (keyBusy) return
    setKeyBusy(true)
    setError(null)
    setNotice(null)
    try {
      const res = await fetch(apiUrl('/api/drive'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'save-key', apiKey: clear ? '' : apiKey.trim() }),
      })
      const data = (await res.json()) as { hasKey?: boolean; error?: string }
      if (!res.ok) throw new Error(data.error ?? 'نەکرا کلیلەکە پاشەکەوت بکرێت')
      setHasKey(!!data.hasKey)
      if (clear) setApiKey('')
      setNotice(clear ? 'کلیلەکە سڕدرایەوە' : 'کلیلی API پاشەکەوتکرا ✅')
    } catch (e) {
      setError(e instanceof Error ? e.message : 'نەکرا کلیلەکە پاشەکەوت بکرێت')
    } finally {
      setKeyBusy(false)
    }
  }

  const removeOne = async (item: DriveVideoItem) => {
    if (workingId) return
    if (!confirm(`دڵنیای لە سڕینەوەی «${item.name}»؟`)) return
    setWorkingId(item.id)
    try {
      const res = await fetch(apiUrl(`/api/drive?id=${encodeURIComponent(item.id)}`), { method: 'DELETE' })
      if (!res.ok) {
        const d = (await res.json().catch(() => ({}))) as { error?: string }
        setError(d.error ?? 'نەکرا بسڕدرێتەوە')
      }
      await load()
    } finally {
      setWorkingId(null)
    }
  }

  const removeFolder = async (folderId: string, folderName: string) => {
    if (workingId) return
    if (!confirm(`دڵنیای لە سڕینەوەی هەموو فلیمەکانی «${folderName}»؟`)) return
    setWorkingId(folderId)
    try {
      const res = await fetch(apiUrl(`/api/drive?folderId=${encodeURIComponent(folderId)}`), { method: 'DELETE' })
      if (!res.ok) {
        const d = (await res.json().catch(() => ({}))) as { error?: string }
        setError(d.error ?? 'نەکرا بسڕدرێتەوە')
      }
      await load()
    } finally {
      setWorkingId(null)
    }
  }

  // گروپکردن — فۆڵدەرەکان و فلیمەکانی تاک
  const folderMap = new Map<string, { name: string; rows: DriveVideoItem[] }>()
  for (const it of items) {
    if (it.folderId) {
      const g = folderMap.get(it.folderId) ?? { name: it.folderName ?? 'فۆڵدەر', rows: [] }
      g.rows.push(it)
      folderMap.set(it.folderId, g)
    }
  }
  const singles = items.filter((i) => !i.folderId)

  return (
    <section className="glass rounded-2xl p-5 space-y-4">
      <div className="flex items-center gap-2">
        <HardDrive className="w-4 h-4 text-amber-300" />
        <h3 className="font-bold">Google Drive 🎬</h3>
        <button
          onClick={() => void load()}
          aria-label="نوێکردنەوەی لیستی Drive"
          title="نوێکردنەوە"
          className="tv-focus ms-auto w-9 h-9 rounded-xl glass hover:bg-white/10 flex items-center justify-center transition-colors"
        >
          <RefreshCw className={cn('w-4 h-4', loading && 'animate-spin')} />
        </button>
      </div>
      <p className="text-xs text-muted-foreground leading-relaxed">
        فلیمەکان لە Google Drive ەوە بۆ بەشی «فلیمەکان» زیاد بکە.
        فایل یان فۆڵدەرەکە لە Drive بکە بە <span className="text-foreground font-semibold">Share → Anyone with the link</span>،
        پاشان لینکەکە لێرە دابنێ — خۆکارانە دەناسرێتەوە و پێویستی بە هیچ ڕێکخستنێک نییە.
      </p>

      {/* ---- کلیلی API — ئارەزوومەندانە، بۆ فۆڵدەری گەورە ---- */}
      <div className="glass rounded-xl p-4 space-y-2.5 border border-white/5">
        <div className="flex items-center gap-2">
          <KeyRound className="w-4 h-4 text-amber-300" />
          <p className="text-xs font-bold text-amber-200">کلیلی API — ئارەزوومەندانە</p>
          <button
            type="button"
            onClick={() => setShowSteps((v) => !v)}
            className="tv-focus ms-auto flex items-center gap-1 text-[11px] text-muted-foreground hover:text-foreground transition-colors"
          >
            {showSteps ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            چۆن دروستی بکەم؟
          </button>
        </div>
        <p className="text-[11px] text-muted-foreground/80 leading-relaxed">
          بەبێ کلیل هەموو شتێک کار دەکات — کلیل تەنها بۆ فۆڵدەری گەورە باشترە (ناوی فۆڵدەر و قەبارەی فلیمەکان دەهێنێت).
        </p>
        {showSteps ? (
          <ol className="text-[11px] text-muted-foreground leading-relaxed space-y-1 list-decimal ps-5">
            <li>بڕۆ بۆ <span dir="ltr" className="font-mono text-indigo-200">console.cloud.google.com</span> و بە ئەکاونتی گووگڵ بچۆ ژوورەوە</li>
            <li>پرۆژەیەکی نوێ دروست بکە (New Project) — ناوی هەرچی بێت</li>
            <li>لە گەڕان بنووسە <span className="text-foreground">Google Drive API</span> و کلیک لە <span className="text-foreground">Enable</span> بکە</li>
            <li>بڕۆ بۆ <span className="text-foreground">Credentials → Create Credentials → API key</span></li>
            <li>کلیلەکە کۆپی بکە و لە خانەی خوارەوە دایبنێ و پاشەکەوتی بکە</li>
          </ol>
        ) : null}
        <div className="flex gap-2">
          <input
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            dir="ltr"
            placeholder="AIza..."
            className="tv-focus glass rounded-xl px-4 py-2.5 text-sm outline-none focus:border-amber-400/60 flex-1 text-left font-mono text-xs"
          />
          <button
            onClick={() => void saveKey(false)}
            disabled={keyBusy || !apiKey.trim()}
            className="tv-focus px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black text-sm font-bold transition-colors disabled:opacity-50 whitespace-nowrap"
          >
            {keyBusy ? '...' : 'پاشەکەوت'}
          </button>
          {hasKey ? (
            <button
              onClick={() => void saveKey(true)}
              disabled={keyBusy}
              aria-label="سڕینەوەی کلیل"
              title="سڕینەوەی کلیل"
              className="tv-focus w-10 h-10 rounded-xl glass hover:bg-rose-500/20 text-rose-200 flex items-center justify-center transition-colors disabled:opacity-50"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          ) : null}
        </div>
        {hasKey ? <p className="text-[11px] text-emerald-300">کلیلی API دانراوە ✅</p> : null}
      </div>

      {/* ---- فۆرمی زیادکردن ---- */}
      <div className="glass rounded-xl p-4 space-y-3 border border-white/5">
        <p className="text-xs font-bold text-indigo-200">زیادکردنی فلیم یان فۆڵدەری تەواو</p>
        <input
          value={link}
          onChange={(e) => setLink(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') void add() }}
          dir="ltr"
          inputMode="url"
          placeholder="https://drive.google.com/file/d/... یان https://drive.google.com/drive/folders/..."
          className="tv-focus glass rounded-xl px-4 py-2.5 text-sm outline-none focus:border-indigo-400/60 w-full text-left font-mono text-xs"
        />
        <div className="flex items-center gap-3 flex-wrap">
          <button
            onClick={add}
            disabled={busy || !link.trim()}
            className="tv-focus flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 hover:from-indigo-400 hover:to-violet-400 text-sm font-bold shadow-lg shadow-indigo-500/25 transition-all disabled:opacity-50"
          >
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
            {busy ? 'پشکنین...' : 'زیادکردن'}
          </button>
          <span className="text-[11px] text-muted-foreground/70 flex items-center gap-1">
            <Info className="w-3 h-3" />
            فایل یان فۆڵدەر خۆکارانە دەناسرێتەوە
          </span>
        </div>
      </div>

      {error ? (
        <div className="rounded-xl bg-rose-500/15 border border-rose-400/30 px-4 py-3 text-sm text-rose-200">
          {error}
        </div>
      ) : null}
      {notice ? (
        <div className="rounded-xl bg-emerald-500/15 border border-emerald-400/30 px-4 py-3 text-sm text-emerald-200">
          {notice}
        </div>
      ) : null}

      {/* ---- لیستەکە ---- */}
      {loading && items.length === 0 ? (
        <p className="text-sm text-muted-foreground flex items-center gap-2 py-2">
          <Loader2 className="w-4 h-4 animate-spin" />
          بارکردنی فلیمەکان...
        </p>
      ) : items.length === 0 ? (
        <p className="text-xs text-muted-foreground/70">
          هێشتا هیچ فلیمێک لە Drive دانەنراوە — یەکەم فلیم زیاد بکە.
        </p>
      ) : (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Film className="w-4 h-4 text-indigo-300" />
            <span className="text-xs font-bold">فلیمەکانی Drive</span>
            <span className="text-[11px] text-muted-foreground">{items.length} فلیم</span>
          </div>

          {/* فۆڵدەرەکان */}
          {[...folderMap.entries()].map(([fid, g]) => (
            <div key={fid} className="space-y-1.5">
              <div className="flex items-center gap-2 ps-1">
                <FolderOpen className="w-4 h-4 text-amber-300" />
                <span className="text-xs font-semibold text-amber-200">{g.name}</span>
                <span className="text-[11px] text-muted-foreground">{g.rows.length} فلیم</span>
                <button
                  onClick={() => void removeFolder(fid, g.name)}
                  disabled={workingId === fid}
                  aria-label={`سڕینەوەی هەموو فلیمەکانی ${g.name}`}
                  title="سڕینەوەی هەموو فلیمەکانی فۆڵدەرەکە"
                  className="tv-focus ms-auto w-8 h-8 rounded-lg glass hover:bg-rose-500/20 text-rose-200 flex items-center justify-center transition-colors disabled:opacity-30"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
              {g.rows.map((item, i) => (
                <DriveRow
                  key={item.id}
                  item={item}
                  index={i + 1}
                  working={workingId === item.id}
                  onRemove={removeOne}
                />
              ))}
            </div>
          ))}

          {/* فلیمەکانی تاک */}
          {singles.length > 0 ? (
            <div className="space-y-1.5">
              <p className="text-[11px] text-muted-foreground ps-1">فلیمەکانی جیا</p>
              {singles.map((item, i) => (
                <DriveRow
                  key={item.id}
                  item={item}
                  index={i + 1}
                  working={workingId === item.id}
                  onRemove={removeOne}
                />
              ))}
            </div>
          ) : null}
        </div>
      )}
    </section>
  )
}

// ---- یەک ڕیزی فلیم — ناو + قەبارە + سڕینەوە ----
function DriveRow({
  item,
  index,
  working,
  onRemove,
}: {
  item: DriveVideoItem
  index: number
  working: boolean
  onRemove: (item: DriveVideoItem) => void
}) {
  return (
    <div
      className={cn(
        'glass rounded-xl px-3 py-2.5 flex items-center gap-2.5 transition-opacity',
        working && 'opacity-50'
      )}
    >
      <span className="w-7 h-7 rounded-lg bg-indigo-500/15 border border-indigo-400/25 text-indigo-200 text-xs font-bold flex items-center justify-center shrink-0 tabular-nums">
        {index}
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-semibold truncate" title={item.name}>{item.name}</p>
        <p className="text-[11px] text-muted-foreground truncate">
          {item.folderName ? item.folderName : 'Drive'}
        </p>
      </div>
      <button
        onClick={() => onRemove(item)}
        disabled={working}
        aria-label="سڕینەوەی فلیم"
        title="سڕینەوە"
        className="tv-focus w-9 h-9 rounded-lg glass hover:bg-rose-500/20 text-rose-200 flex items-center justify-center transition-colors disabled:opacity-30 shrink-0"
      >
        <Trash2 className="w-4 h-4" />
      </button>
    </div>
  )
}
