<?php
// دروستکردنی بەستەری پەخش — وشەی نهێنی لە سێرڤەردا دەمێنێتەوە
// وەشانێکی PHP ی src/app/api/stream-url/route.ts
require __DIR__ . '/lib.php';
handle_preflight();

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    json_out(['error' => 'ڕێگەیەکی نەزانراو'], 405);
}

try {
    $s = settings_row();
    if (empty($s['xtreamHost']) || empty($s['xtreamUsername']) || empty($s['xtreamPassword'])) {
        json_out(['error' => 'زانیارییەکان دانەنراون'], 400);
    }

    $type = isset($_GET['type']) ? (string)$_GET['type'] : '';
    $id = isset($_GET['id']) ? (string)$_GET['id'] : '';
    $ext = isset($_GET['ext']) && $_GET['ext'] !== '' ? (string)$_GET['ext'] : 'mp4';

    if ($id === '' || $type === '') {
        json_out(['error' => 'زانیاری ناتەواو'], 400);
    }

    $base = rtrim((string)$s['xtreamHost'], '/');
    $user = rawurlencode((string)$s['xtreamUsername']);
    $pass = rawurlencode((string)$s['xtreamPassword']);

    switch ($type) {
        case 'live':
            $url = $base . '/live/' . $user . '/' . $pass . '/' . rawurlencode($id) . '.m3u8';
            break;
        case 'movie':
            $url = $base . '/movie/' . $user . '/' . $pass . '/' . rawurlencode($id) . '.' . rawurlencode($ext);
            break;
        case 'series':
            $url = $base . '/series/' . $user . '/' . $pass . '/' . rawurlencode($id) . '.' . rawurlencode($ext);
            break;
        default:
            json_out(['error' => 'جۆری نەزانراو'], 400);
    }

    json_out(['url' => $url]);
} catch (Throwable $e) {
    json_out(['error' => 'هەڵەیەک ڕوویدا'], 500);
}
