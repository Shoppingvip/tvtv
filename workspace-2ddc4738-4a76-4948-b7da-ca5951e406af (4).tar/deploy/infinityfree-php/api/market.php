<?php
// مارکێت — کاڵاکانی فرۆشتن — وەشانێکی PHP ی src/app/api/market/route.ts
require __DIR__ . '/lib.php';
handle_preflight();

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// ---- GET — بۆ هەمووان ----
if ($method === 'GET') {
    try {
        $items = turso_rows("SELECT \"id\", \"name\", \"price\", \"description\", \"image\" FROM \"Product\" ORDER BY \"sortOrder\" ASC, \"createdAt\" DESC");
        json_out(['items' => $items]);
    } catch (Throwable $e) {
        json_out(['items' => []]);
    }
}

// ---- POST — زیادکردنی کاڵا (تەنها بەڕێوەبەر) ----
if ($method === 'POST') {
    try {
        if (!is_admin()) forbidden();
        $body = body_json();
        $name = trim_str($body['name'] ?? '');
        $price = trim_str($body['price'] ?? '');
        $description = trim_str($body['description'] ?? '');
        $image = trim_null($body['image'] ?? null);

        if ($name === '') json_out(['error' => 'ناوی کاڵا پێویستە'], 400);
        if (mb_strlen($name) > 120) json_out(['error' => 'ناوی کاڵا زۆر درێژە'], 400);
        if (mb_strlen($description) > 2000) json_out(['error' => 'وردەکارییەکە زۆر درێژە'], 400);
        if (mb_strlen($price) > 60) json_out(['error' => 'نرخەکە زۆر درێژە'], 400);

        // وێنە — دەبێت data URL بێت
        if ($image !== null) {
            if (!preg_match('/^data:image\/(png|jpe?g|webp|gif);base64,[A-Za-z0-9+\/=]+$/', $image)) {
                json_out(['error' => 'فایلەکە وێنە نییە (PNG، JPG، WEBP یان GIF)'], 400);
            }
            if (strlen($image) > 2500000) {
                json_out(['error' => 'قەبارەی وێنەکە زۆر گەورەیە — وێنەی بچووکتر هەڵبژێرە'], 400);
            }
        }

        $count = (int)(turso_scalar("SELECT COUNT(*) FROM \"Product\"") ?? 0);
        if ($count >= 500) {
            json_out(['error' => 'ژمارەی کاڵا گەیشتووەتە سنوور — تکایە کاڵای کۆن بسڕەوە'], 400);
        }

        $id = cuid();
        turso_exec(
            "INSERT INTO \"Product\" (\"id\", \"name\", \"price\", \"description\", \"image\", \"sortOrder\") VALUES (?, ?, ?, ?, ?, ?)",
            [$id, mb_substr($name, 0, 120), mb_substr($price, 0, 60), mb_substr($description, 0, 2000), $image, $count]
        );
        json_out(['ok' => true, 'id' => $id]);
    } catch (Throwable $e) {
        json_out(['error' => 'هەڵەیەک ڕوویدا لە زیادکردنی کاڵا'], 500);
    }
}

// ---- DELETE — سڕینەوەی کاڵا (تەنها بەڕێوەبەر) ----
if ($method === 'DELETE') {
    try {
        if (!is_admin()) forbidden();
        $id = isset($_GET['id']) ? (string)$_GET['id'] : '';
        if ($id === 'ALL') {
            turso_exec("DELETE FROM \"Product\"");
            json_out(['ok' => true]);
        }
        if ($id === '') json_out(['error' => 'ناسنامەی کاڵا نەنێردرا'], 400);
        turso_exec("DELETE FROM \"Product\" WHERE \"id\" = ?", [$id]);
        json_out(['ok' => true]);
    } catch (Throwable $e) {
        json_out(['error' => 'هەڵەیەک ڕوویدا لە سڕینەوەی کاڵا'], 500);
    }
}

json_out(['error' => 'ڕێگەیەکی نەزانراو'], 405);
