import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { isAdminRequest, forbidden } from '@/lib/admin'
import { NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'

// دەرچوون و سڕینەوەی هەموو زانیارییەکان — تەنها بەڕێوەبەر
export async function POST(req: NextRequest) {
  try {
    if (!(await isAdminRequest(req))) return forbidden()
    await db.settings.deleteMany({})
    await db.favorite.deleteMany({})
    await db.history.deleteMany({})
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'هەڵەیەک ڕوویدا' }, { status: 500 })
  }
}
