# تاقیکردنەوەی API ی سەرچاوەکانی M3U — کۆدی بەڕێوەبەر کاتی دەگۆڕدرێت و دەگەڕێتەوە
# NEVER prints the original pin. Restores it at the end.
set -e
cd /home/z/my-project

bun -e '
import { PrismaClient } from "@prisma/client"
const db = new PrismaClient()
const orig = await db.settings.findUnique({ where: { id: "main" } })
// پاشەکەوتکردنی کۆدی ڕەسەن لە فایلێکی نهێنی — بۆ گەڕاندنەوە
import { writeFileSync } from "fs"
writeFileSync("/tmp/orig-pin.txt", orig?.adminPin ?? "")
await db.settings.update({ where: { id: "main" }, data: { adminPin: "246810" } })
await db.$disconnect()
console.log("pin-swapped")
'

# کردنەوەی دەسەڵاتی بەڕێوەبەر
COOKIE=/tmp/admin-cookie.txt
curl -s -c $COOKIE -X POST http://localhost:3000/api/admin -H 'Content-Type: application/json' -d '{"pin":"246810"}' | head -c 100; echo " <- login"

echo "--- GET sources (migration from legacy m3uUrl) ---"
curl -s -b $COOKIE http://localhost:3000/api/m3u/sources | head -c 600; echo

echo "--- POST add live source (fake but valid http url) ---"
curl -s -b $COOKIE -X POST http://localhost:3000/api/m3u/sources -H 'Content-Type: application/json' -d '{"name":"تاقیکردنەوە کەناڵ","url":"http://example.com/live-list.m3u","section":"live"}'; echo
echo "--- POST add movie source ---"
curl -s -b $COOKIE -X POST http://localhost:3000/api/m3u/sources -H 'Content-Type: application/json' -d '{"name":"تاقیکردنەوە فلیم","url":"http://example.com/movie-list.m3u","section":"movie"}'; echo

echo "--- GET again (order check) ---"
curl -s -b $COOKIE http://localhost:3000/api/m3u/sources; echo
