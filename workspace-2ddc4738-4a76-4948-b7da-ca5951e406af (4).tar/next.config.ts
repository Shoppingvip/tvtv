import type { NextConfig } from "next";

// مۆدەکانی بنیاتنان:
//   BUILD_STATIC=1 → بنیاتنانی جێگیر (static export) بۆ هۆستی وەک InfinityFree
//   NETLIFY=true   → لەسەر Netlify (پلاگینی فەرمی خۆی پاکێج دەکات — standalone پێویست نییە)
//   ئاسایی        → standalone بۆ Vercel / سێرڤەری تایبەت
// BUILD_DIST_OVERRIDE → تەنها بۆ تاقیکردنەوەی ناوخۆیی — فۆڵدەری dist دەگۆڕێت بۆ ئەوەی
//   بنیاتنانەکە پێ .next ی سێرڤەری dev نەلێوێت
const isStatic = process.env.BUILD_STATIC === "1";
const isNetlify = process.env.NETLIFY === "true";
const distOverride = process.env.BUILD_DIST_OVERRIDE;

// CORS — ڕێگە بە فرۆنتی دوو دۆمەین (InfinityFree یان static ی Netlify)
// دەدات API ی سێرڤەر لە دۆمەینێکی تر بانگ بکات
const corsHeaders = async () => [
  {
    source: "/api/:path*",
    headers: [
      { key: "Access-Control-Allow-Origin", value: "*" },
      {
        key: "Access-Control-Allow-Methods",
        value: "GET,POST,PUT,PATCH,DELETE,OPTIONS",
      },
      {
        key: "Access-Control-Allow-Headers",
        value: "Content-Type, Authorization, X-Admin-Token",
      },
      { key: "Access-Control-Max-Age", value: "86400" },
    ],
  },
];

const base = {
  typescript: { ignoreBuildErrors: true },
  reactStrictMode: false,
};

const nextConfig: NextConfig = isStatic
  ? {
      ...base,
      output: "export",
      trailingSlash: true,
      images: { unoptimized: true },
      distDir: distOverride ?? ".next-static",
    }
  : isNetlify
    ? { ...base, distDir: distOverride ?? ".next", headers: corsHeaders }
    : {
        ...base,
        output: "standalone",
        distDir: distOverride ?? ".next",
        headers: corsHeaders,
      };

export default nextConfig;
