// بەڕێوەبردنی سەرچاوەکانی M3U — تەنها بەڕێوەبەر
// زیادکردن، ڕیزکردنەوە (پێش/دوا) و سڕینەوەی لیستەکان بە جیا بۆ کەناڵ و فلیم
import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { isAdminRequest, forbidden } from '@/lib/admin'
import { listSources } from '@/lib/m3u'
import { backupDbFile } from '@/lib/backup'

export const dynamic = 'force-dynamic'

// خوێندنەوەی هەموو لیستەکان
export async function GET(req: NextRequest) {
  if (!(await isAdminRequest(req))) return forbidden()
  try {
    return NextResponse.json({ items: await listSources() })
  } catch {
    return NextResponse.json({ error: 'هەڵە لە خوێندنەوەی لیستەکان' }, { status: 500 })
  }
}

// زیادکردنی لیستێکی نوێ — { name?, url, section: live | movie | both }
export async function POST(req: NextRequest) {
  if (!(await isAdminRequest(req))) return forbidden()
  try {
    const body = (await req.json()) as { name?: string; url?: string; section?: string }
    const url = (body.url ?? '').trim()
    const section = ['live', 'movie', 'both'].includes(body.section ?? '') ? body.section! : 'both'
    if (!/^https?:\/\/.+/i.test(url)) {
      return NextResponse.json({ error: 'بەستەرەکە دەبێت بە http:// یان https:// دەست پێبکات' }, { status: 400 })
    }

    const max = await db.m3uSource.aggregate({ _max: { sortOrder: true } })
    const src = await db.m3uSource.create({
      data: {
        name: (body.name ?? '').trim().slice(0, 60),
        url,
        section,
        sortOrder: (max._max.sortOrder ?? -1) + 1,
      },
    })

    backupDbFile('m3u-source-added')
    return NextResponse.json({ ok: true, id: src.id })
  } catch {
    return NextResponse.json({ error: 'نەکرا لیستەکە زیاد بکرێت' }, { status: 500 })
  }
}

// ڕیزکردنەوە — { id, dir: 1 (دواتر) | -1 (پێشتر), section }
// ئاڵوگۆڕی ڕیزەکە تەنها لەگەڵ هاوڕێکەی لە هەمان بەشد — لیستی (هەردووکیان) بە جیا ڕیز دەکرێت
export async function PUT(req: NextRequest) {
  if (!(await isAdminRequest(req))) return forbidden()
  try {
    const body = (await req.json()) as { id?: string; dir?: number; section?: string }
    if (!body.id || (body.dir !== 1 && body.dir !== -1)) {
      return NextResponse.json({ error: 'داواکارییەکە دروست نییە' }, { status: 400 })
    }
    const section = body.section === 'live' || body.section === 'movie' || body.section === 'both' ? body.section : null

    const all = await db.m3uSource.findMany({ orderBy: [{ sortOrder: 'asc' }, { createdAt: 'asc' }] })
    // فلتەری ورد — تەنها لیستەکانی هەمان بەش (بۆ ئەوەی ڕیزەکە لە ڕووکارەکەشدا وەک خۆی دەرکەوێت)
    const scoped = section ? all.filter((s) => s.section === section) : all
    const idx = scoped.findIndex((s) => s.id === body.id)
    if (idx === -1) return NextResponse.json({ error: 'لیستەکە نەدۆزرایەوە' }, { status: 404 })

    const j = idx + body.dir
    if (j < 0 || j >= scoped.length) {
      // لە لێوارەکەیە — هیچ مەکە بەڵام سەرکەوتوو بگەڕێنەوە
      return NextResponse.json({ ok: true })
    }

    const a = scoped[idx]
    const b = scoped[j]
    // ئاڵوگۆڕی sortOrder — ئەگەر یەکسان بوون، تەواوی لیستەکە ڕێک بخەرەوە
    if (a.sortOrder === b.sortOrder) {
      const reordered = [...scoped]
      reordered.splice(idx, 1)
      reordered.splice(j, 0, a)
      await db.$transaction(
        reordered.map((s, i) => db.m3uSource.update({ where: { id: s.id }, data: { sortOrder: i } }))
      )
    } else {
      await db.$transaction([
        db.m3uSource.update({ where: { id: a.id }, data: { sortOrder: b.sortOrder } }),
        db.m3uSource.update({ where: { id: b.id }, data: { sortOrder: a.sortOrder } }),
      ])
    }

    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'نەکرا ڕیزەکە بگۆڕدرێت' }, { status: 500 })
  }
}

// سڕینەوەی لیست — ?id=
export async function DELETE(req: NextRequest) {
  if (!(await isAdminRequest(req))) return forbidden()
  try {
    const id = req.nextUrl.searchParams.get('id')
    if (!id) return NextResponse.json({ error: 'ناسنامەی لیست نەنێردرا' }, { status: 400 })
    await db.m3uSource.delete({ where: { id } })
    // ئەگەر دوایین لیستیش سڕدرایەوە — m3uUrl ی کۆن پاک بکەرەوە بۆ ئەوەی لیستەکە خۆکارانە دووبارە دروست نەبێتەوە
    const remaining = await db.m3uSource.count()
    if (remaining === 0) {
      await db.settings.updateMany({ where: { id: 'main' }, data: { m3uUrl: null } })
    }
    backupDbFile('m3u-source-deleted')
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'نەکرا لیستەکە بسڕدرێتەوە' }, { status: 500 })
  }
}
