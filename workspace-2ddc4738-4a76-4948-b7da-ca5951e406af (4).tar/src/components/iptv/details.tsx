'use client'
import { apiUrl } from '@/lib/api'

// دیالۆگی زانیاری فلیم
import { useEffect, useState } from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Play, Loader2, Calendar, Star } from 'lucide-react'
import { LogoImg, Spinner, ErrorBox } from './ui-bits'
import type { XtreamEpgEntry } from '@/lib/iptv'

async function xtreamApi(action: string, extra: Record<string, string> = {}) {
  const res = await fetch(apiUrl('/api/xtream'), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action, ...extra }),
  })
  if (!res.ok) throw new Error('هەڵە لە پەیوەندی')
  return res.json()
}

// ---------- فلیم ----------

export function MovieDialog({
  vodId,
  name,
  cover,
  onClose,
  onPlay,
}: {
  vodId: string
  name: string
  cover: string | null
  onClose: () => void
  onPlay: () => void
}) {
  const [info, setInfo] = useState<{
    info?: { plot?: string; genre?: string; releaseDate?: string; rating?: string; duration?: string; cast?: string; backdrop_path?: string[] }
    movie_data?: { name?: string }
  } | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false
    async function load() {
      setLoading(true)
      setError(null)
      try {
        const d = (await xtreamApi('get_vod_info', { id: vodId })) as {
          info?: { plot?: string; genre?: string; releaseDate?: string; rating?: string; duration?: string; cast?: string; backdrop_path?: string[] }
          movie_data?: { name?: string }
        }
        if (!cancelled) setInfo(d)
      } catch {
        if (!cancelled) setError('نەکرا زانیارییەکان بهێنرێن')
      } finally {
        if (!cancelled) setLoading(false)
      }
    }
    load()
    return () => { cancelled = true }
  }, [vodId])

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="glass-strong border-white/10 max-w-2xl max-h-[85vh] overflow-y-auto nice-scroll">
        <DialogHeader>
          <DialogTitle className="text-xl font-extrabold">{name}</DialogTitle>
        </DialogHeader>
        {loading ? (
          <Spinner label="بارکردنی زانیارییەکان..." />
        ) : error ? (
          <ErrorBox message={error} onRetry={() => setLoading(true)} />
        ) : (
          <div className="space-y-5">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="w-32 shrink-0 aspect-[2/3] rounded-xl overflow-hidden bg-black/30">
                <LogoImg src={cover} alt={name} className="w-full h-full" fallbackIcon="movie" />
              </div>
              <div className="space-y-2.5 text-sm min-w-0">
                {info?.info?.plot ? <p className="text-muted-foreground leading-relaxed">{info.info.plot}</p> : null}
                <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
                  {info?.info?.genre ? (
                    <span className="flex items-center gap-1"><Star className="w-3.5 h-3.5 text-amber-400" />{info.info.genre}</span>
                  ) : null}
                  {info?.info?.releaseDate ? (
                    <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" />{info.info.releaseDate.slice(0, 4)}</span>
                  ) : null}
                  {info?.info?.duration ? <span>{info.info.duration}</span> : null}
                </div>
              </div>
            </div>
            <button
              onClick={onPlay}
              className="tv-focus w-full py-4 rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 hover:from-indigo-400 hover:to-violet-400 font-bold shadow-xl shadow-indigo-500/25 transition-all flex items-center justify-center gap-2"
            >
              <Play className="w-5 h-5 fill-white" />
              لێدانی فلیم
            </button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}

// ---------- وەرگرتنی ئیپیدی کەناڵی زیندوو ----------

export async function fetchShortEpg(streamId: string): Promise<{ now: string; next: string } | null> {
  try {
    const d = (await xtreamApi('get_short_epg', { id: streamId, limit: '2' })) as {
      epg_listings?: XtreamEpgEntry[]
    }
    const list = d.epg_listings ?? []
    const decode = (t?: string) => {
      if (!t) return ''
      try { return decodeURIComponent(escape(atob(t))) } catch { return t }
    }
    const now = list[0] ? decode(list[0].title) : ''
    const next = list[1] ? decode(list[1].title) : ''
    return { now, next }
  } catch {
    return null
  }
}

export function EpgLoader() {
  return <Loader2 className="w-4 h-4 animate-spin text-indigo-300" />
}
