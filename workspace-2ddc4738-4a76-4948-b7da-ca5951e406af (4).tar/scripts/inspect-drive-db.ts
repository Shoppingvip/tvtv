import { PrismaClient } from '@prisma/client'
const db = new PrismaClient()
async function main() {
  const rows = await db.driveVideo.findMany()
  console.log('driveVideo rows:', rows.length)
  for (const r of rows) console.log(' -', r.id, r.name, r.fileId.slice(0, 14))
  const s = await db.settings.findUnique({ where: { id: 'main' } })
  console.log('settings id:', s?.id, '| hasKey:', !!s?.driveApiKey, '| appName:', s?.appName)
  process.exit(0)
}
main().catch((e) => { console.error('ERR', e.message); process.exit(1) })
