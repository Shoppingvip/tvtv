<?php
// پاشکۆی دەستکرد — دەرهێنان و هێنانەوەی هەموو زانیارییەکان بە جۆری JSON
// وەشانێکی PHP ی src/app/api/backup/route.ts
require __DIR__ . '/lib.php';
handle_preflight();

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

function str_or_null($v): ?string
{
    if ($v === null) return null;
    return (string)$v;
}

// ---- GET — دەرهێنان (تەنها بەڕێوەبەر) ----
if ($method === 'GET') {
    try {
        if (!is_admin()) forbidden();
        ensure_schema();
        $payload = [
            'app'        => 'iptv-web',
            'version'    => 1,
            'exportedAt' => gmdate('Y-m-d\TH:i:s.v\Z'),
            'settings'   => turso_rows("SELECT * FROM \"Settings\""),
            'banners'    => turso_rows("SELECT * FROM \"Banner\" ORDER BY \"sortOrder\" ASC"),
            'products'   => turso_rows("SELECT * FROM \"Product\" ORDER BY \"sortOrder\" ASC"),
            'favorites'  => turso_rows("SELECT * FROM \"Favorite\" ORDER BY \"createdAt\" ASC"),
            'history'    => turso_rows("SELECT * FROM \"History\" ORDER BY \"watchedAt\" DESC"),
            'm3uSources' => turso_rows("SELECT * FROM \"M3uSource\" ORDER BY \"sortOrder\" ASC"),
        ];
        $stamp = gmdate('Y-m-d');
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="iptv-backup-' . $stamp . '.json"');
        send_cors();
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit;
    } catch (Throwable $e) {
        json_out(['error' => 'هەڵە لە دەرهێنانی زانیارییەکان'], 500);
    }
}

// ---- POST — هێنانەوە (تەنها بەڕێوەبەر) ----
if ($method === 'POST') {
    try {
        if (!is_admin()) forbidden();
        ensure_schema();
        $body = body_json();

        if (!isset($body['settings']) || !is_array($body['settings']) || count($body['settings']) === 0) {
            json_out(['error' => 'فایلەکە پاشکۆیەکی دروست نییە — زانیاری ڕێکخستنی تێدا نییە'], 400);
        }

        $s0 = $body['settings'][0];

        // ڕێکخستنەکان — بەسەر تۆماری main دەنووسرێتەوە (driveApiKey دەمێنێتەوە)
        turso_exec(
            "INSERT INTO \"Settings\" (\"id\", \"appName\", \"adminPin\", \"xtreamHost\", \"xtreamUsername\", \"xtreamPassword\", \"m3uUrl\", \"updatedAt\") " .
            "VALUES ('main', ?, ?, ?, ?, ?, ?, " . sql_now() . ") " .
            "ON CONFLICT(\"id\") DO UPDATE SET " .
            "\"appName\" = excluded.\"appName\", \"adminPin\" = excluded.\"adminPin\", " .
            "\"xtreamHost\" = excluded.\"xtreamHost\", \"xtreamUsername\" = excluded.\"xtreamUsername\", " .
            "\"xtreamPassword\" = excluded.\"xtreamPassword\", \"m3uUrl\" = excluded.\"m3uUrl\", \"updatedAt\" = " . sql_now(),
            [
                str_or_null($s0['appName'] ?? null) ?? 'تیڤی ئەپی من',
                str_or_null($s0['adminPin'] ?? null),
                str_or_null($s0['xtreamHost'] ?? null),
                str_or_null($s0['xtreamUsername'] ?? null),
                str_or_null($s0['xtreamPassword'] ?? null),
                str_or_null($s0['m3uUrl'] ?? null),
            ]
        );

        // خشتەکانی تر — پاک دەکرێنەوە و لە فایلەکەوە دادەنرێن
        turso_pipeline([
            ['sql' => "DELETE FROM \"Banner\"", 'args' => []],
            ['sql' => "DELETE FROM \"Product\"", 'args' => []],
            ['sql' => "DELETE FROM \"Favorite\"", 'args' => []],
            ['sql' => "DELETE FROM \"History\"", 'args' => []],
            ['sql' => "DELETE FROM \"M3uSource\"", 'args' => []],
        ]);

        // زانیارییەکان یەک بە یەک زیاد دەکرێن — هەڵەکان پشتگوێ دەخرێن (دووبارەیی)
        $ok = function (callable $fn) {
            try { $fn(); } catch (Throwable $e) { /* پشتگوێخستن */ }
        };

        foreach (($body['banners'] ?? []) as $b) {
            if (str_or_null($b['data'] ?? null) === null) continue;
            $ok(function () use ($b) {
                turso_exec(
                    "INSERT INTO \"Banner\" (\"id\", \"name\", \"data\", \"sortOrder\") VALUES (?, ?, ?, ?)",
                    [str_or_null($b['id'] ?? null) ?? cuid(), str_or_null($b['name'] ?? null) ?? '', (string)$b['data'], (int)($b['sortOrder'] ?? 0)]
                );
            });
        }
        foreach (($body['products'] ?? []) as $p) {
            if (str_or_null($p['name'] ?? null) === null) continue;
            $ok(function () use ($p) {
                turso_exec(
                    "INSERT INTO \"Product\" (\"id\", \"name\", \"price\", \"description\", \"image\", \"sortOrder\") VALUES (?, ?, ?, ?, ?, ?)",
                    [str_or_null($p['id'] ?? null) ?? cuid(), (string)$p['name'], str_or_null($p['price'] ?? null) ?? '', str_or_null($p['description'] ?? null) ?? '', str_or_null($p['image'] ?? null), (int)($p['sortOrder'] ?? 0)]
                );
            });
        }
        foreach (($body['favorites'] ?? []) as $f) {
            if (str_or_null($f['itemId'] ?? null) === null) continue;
            $ok(function () use ($f) {
                turso_exec(
                    "INSERT INTO \"Favorite\" (\"id\", \"itemType\", \"itemId\", \"name\", \"logo\", \"extra\", \"createdAt\") VALUES (?, ?, ?, ?, ?, ?, " . sql_now() . ")",
                    [str_or_null($f['id'] ?? null) ?? cuid(), str_or_null($f['itemType'] ?? null) ?? 'live', (string)$f['itemId'], str_or_null($f['name'] ?? null) ?? '', str_or_null($f['logo'] ?? null), str_or_null($f['extra'] ?? null)]
                );
            });
        }
        foreach (($body['history'] ?? []) as $h) {
            if (str_or_null($h['itemId'] ?? null) === null) continue;
            $ok(function () use ($h) {
                turso_exec(
                    "INSERT INTO \"History\" (\"id\", \"itemType\", \"itemId\", \"name\", \"logo\", \"extra\", \"watchedAt\") VALUES (?, ?, ?, ?, ?, ?, " . sql_now() . ")",
                    [str_or_null($h['id'] ?? null) ?? cuid(), str_or_null($h['itemType'] ?? null) ?? 'live', (string)$h['itemId'], str_or_null($h['name'] ?? null) ?? '', str_or_null($h['logo'] ?? null), str_or_null($h['extra'] ?? null)]
                );
            });
        }
        foreach (($body['m3uSources'] ?? []) as $m) {
            if (str_or_null($m['url'] ?? null) === null) continue;
            $ok(function () use ($m) {
                turso_exec(
                    "INSERT INTO \"M3uSource\" (\"id\", \"name\", \"url\", \"section\", \"sortOrder\", \"createdAt\") VALUES (?, ?, ?, ?, ?, " . sql_now() . ")",
                    [str_or_null($m['id'] ?? null) ?? cuid(), str_or_null($m['name'] ?? null) ?? '', (string)$m['url'], str_or_null($m['section'] ?? null) ?? 'both', (int)($m['sortOrder'] ?? 0)]
                );
            });
        }

        json_out(['ok' => true]);
    } catch (Throwable $e) {
        json_out(['error' => 'نەکرا فایلەکە بهێنرێتەوە — دڵنیابە فایلی پاشکۆی دروستە'], 400);
    }
}

json_out(['error' => 'ڕێگەیەکی نەزانراو'], 405);
