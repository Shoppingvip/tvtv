<?php
// پشکنینی دامەزراندن — خشتەکانی داتابەیس دروست دەکات و بارودۆخ نیشان دەدات
// لە دوای بارکردنی فایلەکان، یەک جار ئەم ناونیشانە بکەرەوە:
//   https://دۆمەینەکەت/api/init
require __DIR__ . '/lib.php';
handle_preflight();

try {
    ensure_schema();
    $rows = turso_rows("SELECT name FROM sqlite_master WHERE type = 'table' ORDER BY name");
    $tables = [];
    foreach ($rows as $r) $tables[] = (string)$r['name'];

    // تاقیکردنەوەی خوێندنەوە
    $n = (int)(turso_scalar("SELECT COUNT(*) FROM \"Settings\"") ?? 0);

    json_out([
        'ok'      => true,
        'message' => 'بەستەری داتابەیس سەرکەوتوو بوو و خشتەکان ئامادەن ✅',
        'tables'  => $tables,
        'settingsRows' => $n,
    ]);
} catch (Throwable $e) {
    json_out([
        'ok'      => false,
        'message' => 'پەیوەندی بە داتابەیس نەکرا: ' . $e->getMessage(),
        'hint'    => 'فایلی api/config.php بکەرەوە و ناونیشانی Turso و توکنەکە بە دروستی دابنێ',
    ], 500);
}
