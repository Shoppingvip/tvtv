// گواستنەوەی هەموو زانیارییەکان لە SQLite ی ناوخۆیی بۆ Turso
// بەکارهێنان: TURSO_DATABASE_URL=... TURSO_AUTH_TOKEN=... bun scripts/copy-data-to-turso.ts
import { PrismaClient } from '@prisma/client'
import { PrismaLibSQL } from '@prisma/adapter-libsql'

const DDL = `
      CREATE TABLE IF NOT EXISTS "Settings" (
          "id" TEXT NOT NULL PRIMARY KEY DEFAULT 'main',
          "appName" TEXT NOT NULL DEFAULT 'تیڤی ئەپی من',
          "pin" TEXT,
          "adminPin" TEXT,
          "xtreamHost" TEXT,
          "xtreamUsername" TEXT,
          "xtreamPassword" TEXT,
          "m3uUrl" TEXT,
          "updatedAt" DATETIME NOT NULL
      );
      CREATE TABLE IF NOT EXISTS "Favorite" (
          "id" TEXT NOT NULL PRIMARY KEY,
          "itemType" TEXT NOT NULL,
          "itemId" TEXT NOT NULL,
          "name" TEXT NOT NULL,
          "logo" TEXT,
          "extra" TEXT,
          "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
      );
      CREATE UNIQUE INDEX IF NOT EXISTS "Favorite_itemType_itemId_key" ON "Favorite"("itemType", "itemId");
      CREATE TABLE IF NOT EXISTS "History" (
          "id" TEXT NOT NULL PRIMARY KEY,
          "itemType" TEXT NOT NULL,
          "itemId" TEXT NOT NULL,
          "name" TEXT NOT NULL,
          "logo" TEXT,
          "extra" TEXT,
          "watchedAt" DATETIME NOT NULL
      );
      CREATE UNIQUE INDEX IF NOT EXISTS "History_itemType_itemId_key" ON "History"("itemType", "itemId");
      CREATE TABLE IF NOT EXISTS "Banner" (
          "id" TEXT NOT NULL PRIMARY KEY,
          "name" TEXT NOT NULL DEFAULT '',
          "data" TEXT NOT NULL,
          "sortOrder" INTEGER NOT NULL DEFAULT 0,
          "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
      );
      CREATE TABLE IF NOT EXISTS "Product" (
          "id" TEXT NOT NULL PRIMARY KEY,
          "name" TEXT NOT NULL,
          "price" TEXT NOT NULL DEFAULT '',
          "description" TEXT NOT NULL DEFAULT '',
          "image" TEXT,
          "sortOrder" INTEGER NOT NULL DEFAULT 0,
          "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
      );
`

async function main() {
  const url = process.env.TURSO_DATABASE_URL
  if (!url || !url.startsWith('libsql://')) {
    console.error('❌ TURSO_DATABASE_URL دابنێ (libsql://...) و TURSO_AUTH_TOKEN')
    process.exit(1)
  }
  const token = process.env.TURSO_AUTH_TOKEN

  // خوێندنەوە لە ناوخۆ
  const local = new PrismaClient()
  // نووسین بۆ Turso
  const adapter = new PrismaLibSQL({ url, authToken: token })
  const remote = new PrismaClient({ adapter }) as unknown as PrismaClient
  const r = remote as any

  // خشتەکان دروست بکە (ئەگەر نەبوون)
  const { createClient } = await import('@libsql/client')
  const raw = createClient({ url, authToken: token })
  await raw.executeMultiple(DDL)
  console.log('✓ خشتەکان ئامادەن')

  // Settings
  const settings = await (local as any).settings.findMany()
  for (const s of settings) {
    await r.settings.upsert({
      where: { id: s.id },
      update: { ...s },
      create: { ...s },
    })
  }
  console.log(`✓ Settings: ${settings.length}`)

  // Banners
  const banners = await (local as any).banner.findMany()
  await r.banner.deleteMany()
  for (const b of banners) {
    await r.banner.create({ data: { ...b } })
  }
  console.log(`✓ Banner: ${banners.length}`)

  // Products
  const products = await (local as any).product.findMany()
  await r.product.deleteMany()
  for (const p of products) {
    await r.product.create({ data: { ...p } })
  }
  console.log(`✓ Product: ${products.length}`)

  // Favorites
  const favs = await (local as any).favorite.findMany()
  await r.favorite.deleteMany()
  for (const f of favs) {
    await r.favorite.create({ data: { ...f } })
  }
  console.log(`✓ Favorite: ${favs.length}`)

  // History
  const hist = await (local as any).history.findMany()
  await r.history.deleteMany()
  for (const h of hist) {
    await r.history.create({ data: { ...h } })
  }
  console.log(`✓ History: ${hist.length}`)

  console.log('🎉 گواستنەوە تەواو بوو!')
  await local.$disconnect()
  process.exit(0)
}

main().catch((e) => {
  console.error('❌ هەڵە:', e?.message ?? e)
  process.exit(1)
})
