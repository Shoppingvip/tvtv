#!/usr/bin/env python3
# دروستکردنی فایلی پاشکۆی JSON — هەمان فۆرماتی ئەپی خۆی (پاشکۆ/هێنانەوە)
# بۆ ئەوەی بەکارهێنەر بتوانێت لە ڕێگەی پانێلی بەڕێوەبەرەوە دووبارە بهێنێتەوە
import sqlite3
import json
from datetime import datetime, timezone, timedelta

DB = '/home/z/my-project/db/custom.db'
OUT = '/home/z/my-project/download/iptv-backup-2026-11-03.json'

con = sqlite3.connect(f'file:{DB}?mode=ro', uri=True)
con.row_factory = sqlite3.Row
cur = con.cursor()

settings = [dict(r) for r in cur.execute('SELECT * FROM Settings')]
banners = [dict(r) for r in cur.execute('SELECT id, name, data, sortOrder, createdAt FROM Banner ORDER BY sortOrder')]
products = [dict(r) for r in cur.execute('SELECT id, name, price, description, image, sortOrder, createdAt FROM Product ORDER BY sortOrder')]
favorites = [dict(r) for r in cur.execute('SELECT * FROM Favorite')]
history = [dict(r) for r in cur.execute('SELECT * FROM History')]

# DateTime یەکان بۆ ISO
def iso(v):
    return v if isinstance(v, str) else datetime.fromtimestamp(v / 1000, tz=timezone(timedelta(hours=3))).isoformat()

payload = {
    'app': 'iptv-web',
    'version': 1,
    'exportedAt': datetime.now(timezone(timedelta(hours=3))).isoformat(),
    'settings': [{**s, 'updatedAt': iso(s['updatedAt'])} for s in settings],
    'banners': [{**b, 'createdAt': iso(b['createdAt'])} for b in banners],
    'products': [{**p, 'createdAt': iso(p['createdAt'])} for p in products],
    'favorites': favorites,
    'history': history,
}

with open(OUT, 'w', encoding='utf-8') as f:
    json.dump(payload, f, ensure_ascii=False, indent=2)

print(f'✓ پاشکۆ لە {OUT} دانرا')
print(f"  settings: {len(settings)} (appName={settings[0]['appName']!r}, m3uUrl={settings[0]['m3uUrl']!r})")
print(f'  banners: {len(banners)}, products: {len(products)}, favorites: {len(favorites)}, history: {len(history)}')
con.close()
