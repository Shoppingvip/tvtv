# دروستکردنی ئایکۆنی ئەپی IPTV — TV + play بە ستایلی تاریک
from PIL import Image, ImageDraw

def make_icon(size: int, path: str):
    S = 4  # supersample
    W = size * S
    img = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    # پاشبنەمای گڕادایەنت تاریک — سووڕی گۆشە تیژ (نەرم)
    bg = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    bd = ImageDraw.Draw(bg)
    r = int(W * 0.22)  # ڕادیوسی گۆشەکان
    # گرادیێنت ڕەساسی شین → مۆر بە هێڵی ستوونی
    top = (10, 10, 24)
    bottom = (28, 16, 48)
    for y in range(W):
        t = y / W
        col = tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(3)) + (255,)
        bd.line([(0, y), (W, y)], fill=col)
    mask = Image.new("L", (W, W), 0)
    md = ImageDraw.Draw(mask)
    md.rounded_rectangle([0, 0, W - 1, W - 1], radius=r, fill=255)
    img.paste(bg, (0, 0), mask)

    # گڵۆوی پاشبنەما — بازنەی مۆر لە گۆشەکاندا
    glow = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse([int(-W*0.25), int(-W*0.25), int(W*0.55), int(W*0.55)], fill=(99, 102, 241, 90))
    gd.ellipse([int(W*0.45), int(W*0.45), int(W*1.25), int(W*1.25)], fill=(168, 85, 247, 80))
    # بڕین بە شێوەی ئایکۆن
    img.paste(glow, (0, 0), Image.composite(mask, Image.new("L", (W, W), 0), mask))

    # جەستەی تیڤی — چوارگۆشەی نەرم
    tv_color = (129, 140, 248)      # indigo-400
    screen_dark = (15, 15, 30)
    white = (255, 255, 255)

    # فرێیمی تیڤی
    m = int(W * 0.18)               # مارجن
    tv = [m, int(W * 0.26), W - m, int(W * 0.68)]
    d.rounded_rectangle(tv, radius=int(W * 0.08), outline=tv_color, width=int(W * 0.045))

    # سکرینی ناوەوە
    inset = int(W * 0.055)
    scr = [tv[0] + inset, tv[1] + inset, tv[2] - inset, tv[3] - inset]
    d.rounded_rectangle(scr, radius=int(W * 0.05), fill=screen_dark, outline=tv_color, width=int(W*0.02))

    # دوگمەی پلەی لە ناوەڕاستی سکرین
    cx, cy = (scr[0] + scr[2]) // 2, (scr[1] + scr[3]) // 2
    pr = int(W * 0.085)
    # سێگۆشەی پلەی — لارد کراوە
    play = [(cx - int(pr*0.6), cy - pr), (cx - int(pr*0.6), cy + pr), (cx + int(pr*0.9), cy)]
    d.polygon(play, fill=white)

    # پێی تیڤی — دوو هێڵی بچووک
    leg_w = int(W * 0.035)
    ly = int(W * 0.68)
    d.line([(int(W*0.34), ly), (int(W*0.28), int(W*0.78))], fill=tv_color, width=leg_w)
    d.line([(int(W*0.66), ly), (int(W*0.72), int(W*0.78))], fill=tv_color, width=leg_w)
    # هێڵی ئاسۆیی ژێر پێیەکان
    d.line([(int(W*0.24), int(W*0.78)), (int(W*0.76), int(W*0.78))], fill=tv_color, width=leg_w)

    img = img.resize((size, size), Image.LANCZOS)
    img.save(path)
    print("saved", path, size)

make_icon(512, "/home/z/my-project/public/icon-512.png")
make_icon(192, "/home/z/my-project/public/icon-192.png")
make_icon(180, "/home/z/my-project/public/apple-touch-icon.png")
make_icon(32, "/home/z/my-project/public/favicon-32.png")
