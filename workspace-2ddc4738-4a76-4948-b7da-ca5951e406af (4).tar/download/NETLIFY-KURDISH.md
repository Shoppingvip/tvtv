# ڕێنمایی: ئەپی IPTV لەسەر Netlify — بەخۆڕایی

ئەپەکە بە تەواوی لەسەر **Netlify** (https://app.netlify.com) کار دەکات — دوو ڕێگا هەیە:

| | ڕێگای ١ — تەواو (پێشنیارکراو) | ڕێگای ٢ — خێرا |
|---|---|---|
| چی دادەمەزرێت | فرۆنت + API + داتابەیس — هەموو شت لەسەر Netlify | تەنها فرۆنت لەسەر Netlify + API لەسەر Vercel |
| چۆن | بە Git (GitHub) | ڕاکێشان و دانان (drag & drop) |
| کات | ~١٥–٢٠ خولەک | ~٥ خولەک |
| پێویستت بە | هەژماری GitHub + Netlify + Turso | هەژماری Netlify + Vercel + Turso |
| فایلی PHP | — | — (لەسەر Netlify کار ناکات) |

هەردوو ڕێگا هەمان داتابەیسی **Turso** بەکاردەهێنن — کە پێشتر بۆ وەشانی InfinityFree و Vercel دروستت کردووە، بەبێ ئەوەش کار دەکات، چونکە یەکەم جار داتابەیسەکە بە خۆی دروست دەکرێت.

---

## ڕێگای ١ — تەواوی ئەپەکە لەسەر Netlify (پێشنیارکراو)

ئەم ڕێگایە باشترینە: API ەکە دەبێتە **Serverless Functions** و middleware ەکە دەبێتە **Edge Function** — هەمووی بە خۆکار، چونکە فایلی `netlify.toml` لە پرۆژەکەدا هەیە.

### هەنگاوی ١ — داتابەیسی Turso ئامادە بکە

١. بچۆ بۆ https://app.turso.tech — ئەگەر داتابەیست پێشتر دروستکردووە (بۆ InfinityFree)، هەمان بەکاربهێنە.
٢. ئەگەر نوێیە: «Create Database» → ناوێک دابنێ (بۆ نموونە `iptv`) → شوێنێک نزیک هەڵبژێرە (بۆ نموونە `fra` یان `ams`).
٣. لە بەشی **Database URL** ناونیشانەکە کۆپی بکە — وەک `libsql://iptv-yourname.turso.io`
٤. لە بەشی **API Tokens** → «Create Token» → توکنەکە کۆپی بکە.

### هەنگاوی ٢ — کۆدەکە بسەپێ بۆ GitHub

١. هەژمارێکی GitHub دروست بکە ئەگەر نییەت (https://github.com).
٢. ریپۆزیتۆریێکی نوێ دروست بکە (بۆ نموونە `iptv-app`) — **Private** باشترە.
٣. کۆدەکە بارکە (upload) — یان بە فەرمانەکانی Git:

```bash
git init
git add .
git commit -m "IPTV app"
git branch -M main
git remote add origin https://github.com/ناوی_تۆ/iptv-app.git
git push -u origin main
```

### هەنگاوی ٣ — Netlify پەیوەندی بکە

١. بچۆ بۆ https://app.netlify.com → تۆمار بکە (بە GitHub خێراترینە).
٢. «Add new site» → **Import an existing project** → **Deploy with GitHub**.
٣. ریپۆزیتۆری `iptv-app` هەڵبژێرە.
٤. Netlify خۆی دەزانێت Next.js ـە — هەموو ڕێکخستنەکان لە `netlify.toml` ەوە دێن:
   - Build command: `npm run build:netlify`
   - پلاگین: `@netlify/plugin-nextjs`
   - Node.js: 22
٥. **پێش «Deploy» کلیک بکەیت** → بەشی **Show advanced → Environment variables** ئەم دوو دانە زیاد بکە:

| Key | Value |
|---|---|
| `TURSO_DATABASE_URL` | `libsql://iptv-yourname.turso.io` |
| `TURSO_AUTH_TOKEN` | توکنەکەی هەنگاوی ١ |

٦. «Deploy» بکە → ٢–٣ خولەک چاوەڕێ بکە.

✅ تەواو — ماڵپەڕەکەت لەم ناونیشانەیە: `https://ناوی_سایت.netlify.app`

### هەنگاوی ٤ — پشکنین

١. ماڵپەڕەکە بکەرەوە — پێویستە ئەپەکە دەربکەوێت.
٢. `https://ناوی_سایت.netlify.app/api/settings` بکەرەوە — پێویستە JSON بگەڕێنێتەوە (واتە API کار دەکات).
٣. یەکەم جار کۆدی بەڕێوەبەر (PIN) لە ناو ئەپەکە دانێ.

### ناوی سایت و دۆمەین

- **Site configuration → Change site name** — ناوێکی کورت هەڵبژێرە.
- دۆمەینی تایبەت: **Domain management → Add a domain** — SSL بە خۆکار و بەخۆڕاییە.

---

## ڕێگای ٢ — خێرا: فرۆنتی جێگیر بە drag & drop

ئەگەر ناتەوێت GitHub بەکاربهێنیت — تەنها فرۆنتەکە لەسەر Netlify دادەنێیت و API ەکە لەسەر Vercel دەمێنێتەوە (هەمان سیستەمی InfinityFree — Phase ١).

**فایلی پێویست: `iptv-netlify-static.zip`** (لە پاکێجەکەدا هەیە)

١. **API لەسەر Vercel:** ڕێنمایی `DEPLOY-VERCEL-KURDISH.md` ببینە — ناونیشانێکی وەک `https://iptv-yourname.vercel.app` وەردەگریت. (کورتەکەی: پرۆژەکە بسەپێ بۆ GitHub → Vercel → Import → دوو گۆڕاوەکانی Turso دابنێ → Deploy)

٢. **config.js بگۆڕە:** فایلەکە بکەرەوە و `window.__API_BASE__ = "";` بکە بە:
   `window.__API_BASE__ = "https://iptv-yourname.vercel.app";`

٣. **Netlify:** https://app.netlify.com → بەشە **Deploys** → **Deploy manually** → zip ەکە ڕابکێشە بۆ چوارچێوەکە.

٤. چەند چرکەیەک → `https://ناوی_سایت.netlify.app` ئامادەیە.

> ⚠️ لەم ڕێگایەدا فایلی PHP ی InfinityFree کار ناکات — پاکێجی Netlify بێ API یە. هەموو داواکارییەکان دەڕۆن بۆ Vercel.

---

## سنوورەکانی پلانی بەخۆڕایی (مهم!)

Netlify ئێستا سیستەمی **کرێدیت** بەکاردەهێنێت — هەر مانگێک **٣٠٠ کرێدی**:

| کردار | تێچووەکەی | نزیکەی |
|---|---|---|
| هەر Deploy ـێکی سەرکەوتوو | ١٥ کرێدی | ~٢٠ جار لە مانگێکدا |
| Bandwidth (هەر GB) | ٢٠ کرێدی | ~١٥ GB لە مانگێکدا |
| داواکارییەکان (هەر ١٠,٠٠٠) | ٢ کرێدی | ~١.٥ ملیۆن داواکاری |
| Compute ی Functions | ١٠ کرێدی/GB-کاتژمێر | بەکارهێنانی زۆری API کاریگەری دەکات |

**بۆ ئەپی خێزانی/کەسی بەسە** — بەڵام ئاگادار بە:
- هەر push ـێک بۆ GitHub = یەک deploy = ١٥ کرێدی. زۆر مەسەپێ.
- پەخشەکان **نا** لە ڕێگەی Netlify ـەوە دەڕۆن (ڕاستەوخۆ لە سێرڤەری Xtream ـەوەیە) — بۆیە Bandwidth کەم دەمێنێتەوە.
- ئەگەر کرێدییەکان تەواو بوون → سایتەکە وادەستێت تا سەرەتای مانگی داهاتوو.
- هەژمارە کۆنەکان (پێش ئەیلوول ٢٠٢٥) لەوانەیە هێشتا سنووری کۆنیان هەبێت (100GB).

---

## کێشە باوەکان و چارەسەرەکان

| کێشە | هۆکار | چارەسەر |
|---|---|---|
| Build فەیل بوو | Node کۆنە | لە `netlify.toml` ەکەدا NODE_VERSION=22 هەیە — دڵنیابە لە پاکێجەکە |
| API ەکە 500 دەدات | گۆڕاوەکانی Turso ونن | Site configuration → Environment variables → هەردووکیان بە دروستی دابنێ |
| «Query engine not found» | prisma generate نەڕەسە | لە Build command دا `npm run build:netlify` بێت (خۆی generate دەکات) |
| هەڵە لە Edge/Middleware | کتێبخانەیەکی ناگونجۆز | middleware ەکەی ئەپەکە سەلامەتە — ئەگەر دەستکارت کرد، تەنها NextRequest/NextResponse بەکاربهێنە |
| سایتەکە وەستاوە | کرێدییەکان تەواو بوون | تا مانگی داهاتوو چاوەڕێ بکە یان پلانی Personal ($9/مانگ) |
| Deploy زۆر قورسە | هەر push ـێک ١٥ کرێدی دەخوات | تەنها کاتێک push بکە کە گۆڕانی تەواو هەیە |
| داتاکانی ون بوون | دوو داتابەیسی جیاواز | هەمان Turso لە هەموو شوێنێک بەکاربهێنە — هەمان URL و Token |

---

## بەراوردی هۆستەکان

| | InfinityFree | Netlify | Vercel |
|---|---|---|---|
| API | PHP (ئێمە نوومانە) | Serverless Functions | Serverless Functions |
| دۆمەین | great-site.net وەک خۆڕایی | .netlify.app وەک خۆڕایی | .vercel.app وەک خۆڕایی |
| SSL | ✓ خۆکار | ✓ خۆکار | ✓ خۆکار |
| سنووری بەخۆڕایی | زۆر فراوان (بەڵام PHP وێستگەیی) | ٣٠٠ کرێدی/مانگ | فراوان بۆ کەسی |
| بۆ ئەم ئەپە | ✓ پاکێجی PHP ئامادەیە | ✓ پێویستی بە Git یە | ✓ ئاساییترین ڕێگا |

**پێشنیار:** ئەگەر GitHub ـت هەیە → ڕێگای ١ لەسەر Netlify یان ڕاستەوخۆ Vercel. ئەگەر GitHub ناتەوێت → InfinityFree (PHP) یان ڕێگای ٢ ی Netlify.
