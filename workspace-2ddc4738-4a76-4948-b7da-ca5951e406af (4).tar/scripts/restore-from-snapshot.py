#!/usr/bin/env python3
# گەڕاندنەوەی داتاکان لە نوسخەی snapshot ەوە (/tmp/my-project/db/custom.db)
# داتای snapshot: ٢ی تشرینی دووەم ٠١:٥٠ UTC — appName, m3uUrl, ٧ بانەر, ٥ کاڵا
# کۆدی بەڕێوەبەری ئێستا (۹۹۸٨) دەمێنێتەوە — ئەوەی بەکارهێنەر ئەمڕۆ داناویەتی
import sqlite3
import shutil
import sys
from datetime import datetime, timezone

SNAPSHOT = 'file:/tmp/my-project/db/custom.db?mode=ro'
CURRENT = '/home/z/my-project/db/custom.db'
BACKUP_DIR = '/home/z/my-project/db/backups'

stamp = datetime.now().strftime('%Y%m%d-%H%M%S')

# ١ — پاشکۆ لە دۆخی ئێستا پێش گۆڕین
import os
os.makedirs(BACKUP_DIR, exist_ok=True)
shutil.copy2(CURRENT, f'{BACKUP_DIR}/custom-{stamp}-before-restore.db')
shutil.copy2('/tmp/my-project/db/custom.db', f'{BACKUP_DIR}/custom-{stamp}-snapshot-source.db')
print(f'✓ پاشکۆکان لە {BACKUP_DIR} دانران')

src = sqlite3.connect(SNAPSHOT, uri=True)
src.row_factory = sqlite3.Row
dst = sqlite3.connect(CURRENT)

try:
    # ٢ — خوێندنەوەی داتاکان لە snapshot
    s = src.execute('SELECT * FROM Settings WHERE id = ?', ('main',)).fetchone()
    banners = src.execute('SELECT * FROM Banner ORDER BY sortOrder').fetchall()
    products = src.execute('SELECT * FROM Product ORDER BY sortOrder').fetchall()
    favorites = src.execute('SELECT * FROM Favorite').fetchall()
    history = src.execute('SELECT * FROM History').fetchall()
    print(f"snapshot: appName='{s['appName']}', m3uUrl='{s['m3uUrl']}', banners={len(banners)}, products={len(products)}, favorites={len(favorites)}, history={len(history)}")

    # ٣ — نووسینەوە بۆ داتابەیسی ئێستا (transaction یەک)
    now = datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S.%f')[:-3] + 'Z'
    dst.execute('BEGIN')
    # ڕێکخستنەکان — pin ی ئێستا دەمێنێتەوە، تەنها ناو + m3u دەگەڕێنرێنەوە
    dst.execute(
        'UPDATE Settings SET appName = ?, m3uUrl = ?, updatedAt = ? WHERE id = ?',
        (s['appName'], s['m3uUrl'], now, 'main'),
    )
    # بانەر و کاڵاکان — سڕینەوەی کۆنەکان (بەتاڵن) و زیادکردنی snapshot
    dst.execute('DELETE FROM Banner')
    dst.execute('DELETE FROM Product')
    for b in banners:
        dst.execute(
            'INSERT INTO Banner (id, name, data, sortOrder, createdAt) VALUES (?,?,?,?,?)',
            (b['id'], b['name'], b['data'], b['sortOrder'], b['createdAt']),
        )
    for p in products:
        dst.execute(
            'INSERT INTO Product (id, name, price, description, image, sortOrder, createdAt) VALUES (?,?,?,?,?,?,?)',
            (p['id'], p['name'], p['price'], p['description'], p['image'], p['sortOrder'], p['createdAt']),
        )
    dst.execute('COMMIT')
    print('✓ نووسینەوە تەواو بوو')

    # ٤ — پشکنین
    n_b = dst.execute('SELECT COUNT(*) FROM Banner').fetchone()[0]
    n_p = dst.execute('SELECT COUNT(*) FROM Product').fetchone()[0]
    row = dst.execute('SELECT appName, adminPin, m3uUrl FROM Settings WHERE id = ?', ('main',)).fetchone()
    print(f'✓ دوای گەڕاندنەوە: Banner={n_b}, Product={n_p}')
    print(f'✓ Settings: appName={row[0]!r}, adminPin=***{row[1][-2:] if row[1] else None}, m3uUrl={row[2]!r}')
except Exception as e:
    dst.execute('ROLLBACK')
    print('❌ هەڵە — گەڕانەوە:', e)
    sys.exit(1)
finally:
    src.close()
    dst.close()
