import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { isAdminRequest, forbidden } from '@/lib/admin'

export const dynamic = 'force-dynamic'

// وێنە ڕیکلامییەکانی بەشی ماڵەوە
// GET — بۆ هەمووان (تەماشاکەر پێویستی بە نیشاندانی ڕیکلامە)
export async function GET() {
  try {
    const items = await db.banner.findMany({
      orderBy: [{ sortOrder: 'asc' }, { createdAt: 'asc' }],
      select: { id: true, name: true, data: true },
    })
    return NextResponse.json({ items })
  } catch {
    return NextResponse.json({ items: [] })
  }
}

// POST — زیادکردنی وێنە (تەنها بەڕێوەبەر)
export async function POST(req: NextRequest) {
  try {
    if (!(await isAdminRequest(req))) return forbidden()

    const body = (await req.json()) as { data?: string; name?: string }
    const data = (body.data ?? '').trim()

    // پشکنینی شێوەی وێنە — دەبێت data URL بێت
    if (!/^data:image\/(png|jpe?g|webp|gif);base64,[A-Za-z0-9+/=]+$/.test(data)) {
      return NextResponse.json({ error: 'فایلەکە وێنە نییە (PNG، JPG، WEBP یان GIF)' }, { status: 400 })
    }
    // سنووری قەبارە — ٢.٥ مێگابایت
    if (data.length > 2_500_000) {
      return NextResponse.json({ error: 'قەبارەی وێنەکە زۆر گەورەیە — وێنەی بچووکتر هەڵبژێرە' }, { status: 400 })
    }

    const count = await db.banner.count()
    const banner = await db.banner.create({
      data: { data, name: (body.name ?? '').slice(0, 100), sortOrder: count },
    })
    return NextResponse.json({ ok: true, id: banner.id })
  } catch {
    return NextResponse.json({ error: 'هەڵەیەک ڕوویدا لە زیادکردنی وێنە' }, { status: 500 })
  }
}

// DELETE — سڕینەوەی وێنە (تەنها بەڕێوەبەر) — ?id=xxx یان ?id=ALL
export async function DELETE(req: NextRequest) {
  try {
    if (!(await isAdminRequest(req))) return forbidden()

    const id = new URL(req.url).searchParams.get('id') ?? ''
    if (id === 'ALL') {
      await db.banner.deleteMany({})
      return NextResponse.json({ ok: true })
    }
    if (!id) return NextResponse.json({ error: 'ناسنامەی وێنە نەنێردرا' }, { status: 400 })
    await db.banner.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'هەڵەیەک ڕوویدا لە سڕینەوەی وێنە' }, { status: 500 })
  }
}
