// پارێزەری داتابەیس — پێش هەر دەستپێکردنەوەی سێرڤەر جێبەجێ دەبێت (لە keep-dev.sh)
// ئەرکەکانی:
//   ١. دڵنیابوون لە بوونی خشتەکان (ئەگەر داتابەیس نوێ بێت)
//   ٢. چاککردنەوەی خۆکار — ئەگەر داتابەیس زیانبیاوە یان زانیاری سەرچاوەکەی ون بووە،
//      لە دوایین پاشکۆی چاکەوە دەیگەڕێنێتەوە
//   ٣. هیچ کاتێک زانیاری چاک ناسڕێتەوە — تەنها کاتێک دەگەڕێنرێتەوە کە داتای ڕاستەقینە ون بێت
import { createClient, type Client } from '@libsql/client'
import { existsSync, readdirSync, statSync, copyFileSync, mkdirSync } from 'fs'
import { join, dirname } from 'path'

const DATABASE_URL = process.env.DATABASE_URL ?? 'file:/home/z/my-project/db/custom.db'
const dbPath = DATABASE_URL.replace(/^file:/, '')
const backupDir = join(dirname(dbPath), 'backups')

function log(msg: string) {
  console.log(`[db-guard] ${new Date().toISOString()} ${msg}`)
}

// کردنەوەی داتابەیس — ئەگەر زیانبیبوو null دەگەڕێنێتەوە
async function openSafe(path: string): Promise<Client | null> {
  let c: Client | null = null
  try {
    c = createClient({ url: `file:${path}` })
    await c.execute('SELECT count(*) FROM sqlite_master')
    return c
  } catch {
    try {
      await c?.close()
    } catch {}
    return null
  }
}

const SCHEMA = `
CREATE TABLE IF NOT EXISTS "Settings" (
  "id" TEXT NOT NULL PRIMARY KEY DEFAULT 'main',
  "appName" TEXT NOT NULL DEFAULT 'تیڤی ئەپی من',
  "adminPin" TEXT,
  "xtreamHost" TEXT,
  "xtreamUsername" TEXT,
  "xtreamPassword" TEXT,
  "m3uUrl" TEXT,
  "updatedAt" DATETIME NOT NULL
);
CREATE TABLE IF NOT EXISTS "Favorite" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "itemType" TEXT NOT NULL,
  "itemId" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "logo" TEXT,
  "extra" TEXT,
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX IF NOT EXISTS "Favorite_itemType_itemId_key" ON "Favorite"("itemType", "itemId");
CREATE TABLE IF NOT EXISTS "History" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "itemType" TEXT NOT NULL,
  "itemId" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "logo" TEXT,
  "extra" TEXT,
  "watchedAt" DATETIME NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS "History_itemType_itemId_key" ON "History"("itemType", "itemId");
CREATE TABLE IF NOT EXISTS "Banner" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "name" TEXT NOT NULL DEFAULT '',
  "data" TEXT NOT NULL,
  "sortOrder" INTEGER NOT NULL DEFAULT 0,
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS "Product" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "name" TEXT NOT NULL,
  "price" TEXT NOT NULL DEFAULT '',
  "description" TEXT NOT NULL DEFAULT '',
  "image" TEXT,
  "sortOrder" INTEGER NOT NULL DEFAULT 0,
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`

interface BackupInfo {
  path: string
  mtime: number
  hasSource: boolean
  readable: boolean
}

// لیستی پاشکۆکان — لە نوێترین بۆ کۆنترین
function listBackups(): string[] {
  if (!existsSync(backupDir)) return []
  return readdirSync(backupDir)
    .filter((f) => f.endsWith('.db'))
    .map((f) => join(backupDir, f))
    .sort((a, b) => statSync(b).mtimeMs - statSync(a).mtimeMs)
}

// ئایا ئەم داتابەیسە زانیاری سەرچاوەی تێدایە؟
async function hasSource(client: Client): Promise<boolean> {
  try {
    const r = await client.execute(
      `SELECT "m3uUrl", "xtreamHost", "xtreamPassword" FROM "Settings" WHERE "id" = 'main'`
    )
    const row = r.rows[0]
    if (!row) return false
    return !!(row.m3uUrl || (row.xtreamHost && row.xtreamPassword))
  } catch {
    return false
  }
}

// لەبەرگرتنەوەی هەموو داتاکان لە یەک داتابەیسەوە بۆ ئەوەی تر
async function copyAll(from: Client, to: Client) {
  // Settings — تۆماری تاک
  const s = await from.execute(`SELECT * FROM "Settings" WHERE "id" = 'main'`)
  const row = s.rows[0]
  if (row) {
    await to.execute({
      sql: `INSERT INTO "Settings" ("id","appName","adminPin","xtreamHost","xtreamUsername","xtreamPassword","m3uUrl","updatedAt")
            VALUES (?,?,?,?,?,?,?,?)
            ON CONFLICT("id") DO UPDATE SET
              "appName"=excluded."appName", "adminPin"=excluded."adminPin",
              "xtreamHost"=excluded."xtreamHost", "xtreamUsername"=excluded."xtreamUsername",
              "xtreamPassword"=excluded."xtreamPassword", "m3uUrl"=excluded."m3uUrl",
              "updatedAt"=excluded."updatedAt"`,
      args: [
        String(row.id ?? 'main'),
        String(row.appName ?? 'تیڤی ئەپی من'),
        row.adminPin == null ? null : String(row.adminPin),
        row.xtreamHost == null ? null : String(row.xtreamHost),
        row.xtreamUsername == null ? null : String(row.xtreamUsername),
        row.xtreamPassword == null ? null : String(row.xtreamPassword),
        row.m3uUrl == null ? null : String(row.m3uUrl),
        String(row.updatedAt ?? new Date().toISOString()),
      ],
    })
  }

  // خشتە گەورەکان — سڕینەوە و دووبارە دانان
  for (const [table, cols] of [
    ['Banner', ['id', 'name', 'data', 'sortOrder', 'createdAt']],
    ['Product', ['id', 'name', 'price', 'description', 'image', 'sortOrder', 'createdAt']],
    ['Favorite', ['id', 'itemType', 'itemId', 'name', 'logo', 'extra', 'createdAt']],
    ['History', ['id', 'itemType', 'itemId', 'name', 'logo', 'extra', 'watchedAt']],
  ] as const) {
    await to.execute(`DELETE FROM "${table}"`)
    const rows = await from.execute(`SELECT * FROM "${table}"`)
    for (const r of rows.rows) {
      const vals = cols.map((c) => (r[c] == null ? null : String(r[c])))
      const ph = cols.map(() => '?').join(',')
      await to.execute({
        sql: `INSERT OR IGNORE INTO "${table}" (${cols.map((c) => `"${c}"`).join(',')}) VALUES (${ph})`,
        args: vals,
      })
    }
  }
}

async function main() {
  mkdirSync(dirname(dbPath), { recursive: true })
  let db = await openSafe(dbPath)

  // ---- حالەتی ١: داتابەیس زیانبیاوە یان نییە — گەڕاندنەوە لە پاشکۆ ----
  if (!db) {
    log('داتابەیس زیانبیاوە یان بوونی نییە — گەڕانەوە بۆ پاشکۆ...')
    const backups = listBackups()
    for (const b of backups) {
      try {
        if (statSync(b).size < 4096) continue
        copyFileSync(b, dbPath)
        db = await openSafe(dbPath)
        if (db) {
          log(`داتابەیس لە پاشکۆوە گەڕایەوە: ${b}`)
          break
        }
      } catch {
        continue
      }
    }
    if (!db) {
      log('هیچ پاشکۆیەکی چاک نییە — داتابەیسێکی نوێ دروست دەکرێت')
      db = createClient({ url: `file:${dbPath}` })
    }
  }

  // ---- خشتەکان دڵنیابە ----
  await db.executeMultiple(SCHEMA)

  // ---- حالەتی ٢: زانیاری سەرچاوە ون بووە — گەڕاندنەوە لە پاشکۆ ----
  if (!(await hasSource(db))) {
    log('زانیاری سەرچاوە لە داتابەیسدا نییە — گەڕان بەدوای پاشکۆی چاک...')
    for (const b of listBackups()) {
      if (b === dbPath) continue
      if (statSync(b).size < 4096) continue
      const bc = await openSafe(b)
      if (!bc) continue
      try {
        await bc.executeMultiple(SCHEMA)
        if (!(await hasSource(bc))) {
          await bc.close()
          continue
        }
        await copyAll(bc, db)
        await bc.close()
        log(`✅ زانیارییەکان لە پاشکۆوە گەڕاندرێنەوە: ${b}`)
        return
      } catch (e) {
        log(`پاشکۆی خراپ: ${b} — ${String(e).slice(0, 80)}`)
        try {
          await bc.close()
        } catch {}
        continue
      }
    }
    log('هیچ پاشکۆیەک زانیاری سەرچاوەی نەبوو — داتابەیس بەتاڵی دەمێنێتەوە (بەکارهێنەر زانیارییەکان دادەنێت)')
  } else {
    log('داتابەیس چاکە — زانیاری سەرچاوە هەیە، هیچ پێویست نەبوو')
  }
}

main()
  .then(() => process.exit(0))
  .catch((e) => {
    log(`هەڵە: ${String(e).slice(0, 200)}`)
    process.exit(0) // هەرگیز ڕێگر لە دەستپێکی سێرڤەر مەبە
  })
