// تاقیکردنەوەی Prisma + adapter-libsql — بە فایلی ناوخۆیی libSQL
// ئەگەر ئەمە کاری کرد، پەیوەندی بە Turso-ی دوورەپەرەزیش کاردەکات (هەمان client)
import { PrismaClient } from '@prisma/client'
import { PrismaLibSQL } from '@prisma/adapter-libsql'

async function main() {
  // پاککردنەوەی تێستەکەی پێشوو
  const fs = await import('fs')
  for (const f of ['/tmp/turso-test.db', '/tmp/turso-test.db-journal']) {
    if (fs.existsSync(f)) fs.unlinkSync(f)
  }

  const adapter = new PrismaLibSQL({ url: 'file:/tmp/turso-test.db' })
  const db = new PrismaClient({ adapter }) as unknown as PrismaClient

  // خشتە دروست بکە (وەک instrumentation)
  const { createClient } = await import('@libsql/client')
  const raw = createClient({ url: 'file:/tmp/turso-test.db' })
  await raw.executeMultiple(
    `CREATE TABLE IF NOT EXISTS "Settings" (
      "id" TEXT NOT NULL PRIMARY KEY DEFAULT 'main',
      "appName" TEXT NOT NULL DEFAULT 'تیڤی ئەپی من',
      "pin" TEXT,
      "adminPin" TEXT,
      "xtreamHost" TEXT,
      "xtreamUsername" TEXT,
      "xtreamPassword" TEXT,
      "m3uUrl" TEXT,
      "updatedAt" DATETIME NOT NULL
    );`
  )

  // نووسین و خوێندنەوە بە Prisma
  await (db as any).settings.create({
    data: { id: 'main', appName: 'تێستی کوردی ✓' },
  })
  const s = await (db as any).settings.findUnique({ where: { id: 'main' } })
  console.log('RESULT:', s?.appName)

  await (db as any).settings.update({
    where: { id: 'main' },
    data: { appName: 'نوێکرایەوە ✓' },
  })
  const s2 = await (db as any).settings.findUnique({ where: { id: 'main' } })
  console.log('RESULT2:', s2?.appName)

  console.log('ADAPTER-TEST-PASSED')
}

main().catch((e) => {
  console.error('ADAPTER-TEST-FAILED:', e?.message ?? e)
  process.exit(1)
})
