import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ADMIN_COOKIE, adminToken, adminCookieOptions, isAdminRequest } from '@/lib/admin'

export const dynamic = 'force-dynamic'

// بارودۆخی بەڕێوەبەر — ئایا کۆد هەیە؟ ئایا ئەم وێبگەڕە کردنەوەیە؟
export async function GET(req: NextRequest) {
  try {
    const s = await db.settings.findUnique({ where: { id: 'main' } })
    if (!s) await db.settings.create({ data: { id: 'main' } })
    return NextResponse.json({
      hasAdminPin: !!s?.adminPin,
      isAdmin: await isAdminRequest(req),
    })
  } catch {
    return NextResponse.json({ hasAdminPin: false, isAdmin: false })
  }
}

// کردنەوەی دەسەڵاتی بەڕێوەبەر بە کۆد — یان دروستکردنی کۆد بۆ یەکەم جار
export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as { pin?: string }
    const pin = (body.pin ?? '').trim()
    if (!/^\d{3,6}$/.test(pin)) {
      return NextResponse.json({ error: 'کۆدەکە دەبێت ٣ بۆ ٦ ژمارە بێت' }, { status: 400 })
    }

    let s = await db.settings.findUnique({ where: { id: 'main' } })
    if (!s) s = await db.settings.create({ data: { id: 'main' } })

    if (!s.adminPin) {
      // یەکەم جارە — ئەم کۆدە دەبێت کۆدی بەڕێوەبەر (خاوەن ئەپەکە)
      await db.settings.update({ where: { id: 'main' }, data: { adminPin: pin } })
      const res = NextResponse.json({ ok: true, claimed: true })
      res.cookies.set(ADMIN_COOKIE, adminToken(pin), adminCookieOptions())
      return res
    }

    if (pin !== s.adminPin) {
      return NextResponse.json({ error: 'کۆدی بەڕێوەبەر هەڵەیە' }, { status: 401 })
    }

    const res = NextResponse.json({ ok: true, claimed: false })
    res.cookies.set(ADMIN_COOKIE, adminToken(pin), adminCookieOptions())
    return res
  } catch {
    return NextResponse.json({ error: 'هەڵەیەک ڕوویدا' }, { status: 500 })
  }
}

// قوفڵکردنەوە — دەرچوونی بەڕێوەبەر
export async function DELETE() {
  const res = NextResponse.json({ ok: true })
  res.cookies.set(ADMIN_COOKIE, '', { path: '/', maxAge: 0 })
  return res
}
