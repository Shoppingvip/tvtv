import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

// وەرگێڕانی هەڵەی تۆڕ بۆ کوردی
function netErrMsg(e: unknown): string {
  const m = e instanceof Error ? e.message : String(e)
  if (/fetch failed|ENOTFOUND|EAI_AGAIN|getaddrinfo/i.test(m)) {
    return 'نەکرا پەیوەندی بە سێرڤەرەکە بکرێت — ناونیشانەکە پشکنین بکە'
  }
  if (/ECONNREFUSED/i.test(m)) return 'سێرڤەرەکە ڕەتی کردەوە — پۆرتەکە هەڵەیە لەوانەیە'
  if (/abort|timeout|timed out/i.test(m)) return 'وەڵام نەگەڕایەوە — سێرڤەرەکە خاوە یان داخڵە'
  if (/certificate|SSL|TLS/i.test(m)) return 'کێشەی گوێپاراستن (SSL) لە سێرڤەرەکەدا هەیە'
  return m
}

// ---- کاشی بیرگەی سێرڤەر ----
// لیست و زانیارییەکان بۆ ماوەیەک لە بیرگەدا دەمێننەوە — دووبارە کردنەوەی بەش یەکسەر دەبێت
// داواکاری هاوشێوەکان یەکدەخرێن (inflight dedup) — سێرڤەری سەرەوە بە داواکاری زۆر ماندوو نابێت
interface XCacheEntry {
  data: unknown
  at: number
}
const cacheG = globalThis as unknown as {
  __iptvXtreamCache?: { c: Map<string, XCacheEntry>; f: Map<string, Promise<unknown>> }
}
const store = cacheG.__iptvXtreamCache ?? (cacheG.__iptvXtreamCache = { c: new Map(), f: new Map() })

const MAX_CACHE_ENTRIES = 80

function ttlForAction(action: string): number | null {
  // لیستەکان — بە زۆری ناگۆڕێن (١٠ خولەک)
  if (/^get_(live|vod|series)_categories$/.test(action)) return 10 * 60_000
  if (action === 'get_live_streams' || action === 'get_vod_streams' || action === 'get_series') return 10 * 60_000
  // زانیاری فلیم و زنجیرە (٥ خولەک)
  if (action === 'get_vod_info' || action === 'get_series_info') return 5 * 60_000
  // ئیپیدی — کورت (٦٠ چرکە) چونکە بەرنامەکان دەگۆڕێن
  if (action === 'get_short_epg' || action === 'get_simple_data_table') return 60_000
  return null
}

// پرۆکسی بۆ APIی Xtream Codes — ڕێگری لە کێشەی CORS دەکات + کاشی خێرا
export async function POST(req: NextRequest) {
  try {
    const s = await db.settings.findUnique({ where: { id: 'main' } })
    if (!s || !s.xtreamHost || !s.xtreamUsername || !s.xtreamPassword) {
      return NextResponse.json({ error: 'سەرەتا زانیارییەکان دابنێ' }, { status: 400 })
    }

    const body = (await req.json()) as {
      action?: string
      categoryId?: string
      id?: string
      limit?: number
    }

    const action = body.action ?? ''
    const ttl = ttlForAction(action)
    const key = ttl !== null ? `${action}|${body.categoryId ?? ''}|${body.id ?? ''}|${body.limit ?? ''}` : null

    const base = s.xtreamHost.replace(/\/+$/, '')
    const user = encodeURIComponent(s.xtreamUsername)
    const pass = encodeURIComponent(s.xtreamPassword)

    const load = async (): Promise<unknown> => {
      const params = new URLSearchParams({
        username: user,
        password: pass,
      })
      if (action) params.set('action', action)
      if (body.categoryId) params.set('category_id', body.categoryId)
      if (body.id) {
        if (action === 'get_series_info') params.set('series_id', body.id)
        else if (action === 'get_vod_info') params.set('vod_id', body.id)
        else params.set('stream_id', body.id)
      }
      if (body.limit) params.set('limit', String(body.limit))

      let res: Response
      try {
        res = await fetch(`${base}/player_api.php?${params.toString()}`, {
          signal: AbortSignal.timeout(20000),
          headers: { 'User-Agent': 'Mozilla/5.0 (IPTV Web Player)' },
        })
      } catch (e) {
        throw new Error(netErrMsg(e))
      }
      if (!res.ok) {
        throw new Error('سێرڤەر وەڵام نەدایەوە')
      }
      const data = await res.json().catch(() => null)
      if (data === null) {
        throw new Error('وەڵامی سێرڤەر دروست نییە')
      }
      return data
    }

    // داواکاری بێ کاش — ڕاستەوخۆ
    if (!key || !ttl) {
      return NextResponse.json(await load())
    }

    // کاشی تازە — یەکسەر بیگەڕێنەوە
    const hit = store.c.get(key)
    const now = Date.now()
    if (hit && now - hit.at < ttl) {
      return NextResponse.json(hit.data)
    }

    // داواکاری هاوشێوە لە جێبەجێکردندایە — چاوەڕوانی بە (یان کاشی کۆن بگەڕێنە)
    const inflight = store.f.get(key)
    if (inflight) {
      if (hit) return NextResponse.json(hit.data) // کاشی کۆن — باشتر لە چاوەڕوانی
      return NextResponse.json(await inflight)
    }

    if (hit) {
      // کاشی کۆن — هەر ئێستا وەڵام بدەرەوە و لە پاشبنەمادا نوێی بکەرەوە
      const p = load()
        .then((d) => {
          store.c.set(key, { data: d, at: Date.now() })
          store.f.delete(key)
          return d
        })
        .catch(() => {
          store.f.delete(key)
        })
      store.f.set(key, p)
      return NextResponse.json(hit.data)
    }

    // یەکەم داواکاری — بکێشە و کاشی بکە
    const p = load()
      .then((d) => {
        store.c.set(key, { data: d, at: Date.now() })
        store.f.delete(key)
        // سنووری قەبارەی کاش — کۆنترین بخەرەوە
        if (store.c.size > MAX_CACHE_ENTRIES) {
          const first = store.c.keys().next().value
          if (first !== undefined) store.c.delete(first)
        }
        return d
      })
      .catch((e) => {
        store.f.delete(key)
        throw e
      })
    store.f.set(key, p)
    return NextResponse.json(await p)
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error && e.message ? e.message : netErrMsg(e) }, { status: 502 })
  }
}
