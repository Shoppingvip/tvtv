#!/usr/bin/env bash
# Static export build for Netlify (fast path: drag-and-drop, no Git).
# - Same stash/restore approach as build-static.sh so the running dev
#   server's .next directory is never touched.
# - Netlify does NOT run PHP → this package has no api/ folder and no .htaccess.
#   API lives elsewhere (e.g. Vercel) — config.js points to it.
# - Adds _redirects (SPA fallback) + README-NETLIFY.txt.
# - Output: download/iptv-netlify-static.zip
set -euo pipefail
cd /home/z/my-project

STASH=".static-stash"
restore() {
  if [ -d "$STASH/api" ]; then mv "$STASH/api" src/app/api; fi
  if [ -f "$STASH/middleware.ts" ]; then mv "$STASH/middleware.ts" src/middleware.ts; fi
  if [ -f "$STASH/instrumentation.ts" ]; then mv "$STASH/instrumentation.ts" src/instrumentation.ts; fi
  rmdir "$STASH" 2>/dev/null || true
}
trap restore EXIT

rm -rf "$STASH" .next-static
mkdir -p "$STASH"
mv src/app/api "$STASH/api"
[ -f src/middleware.ts ] && mv src/middleware.ts "$STASH/"
[ -f src/instrumentation.ts ] && mv src/instrumentation.ts "$STASH/"

echo ">>> Building static export (server files stashed)…"
BUILD_STATIC=1 npx next build

trap - EXIT
restore

echo ">>> Verifying .next-static/ …"
for f in .next-static/index.html .next-static/config.js .next-static/sw.js .next-static/manifest.webmanifest .next-static/icon-192.png; do
  [ -f "$f" ] || { echo "MISSING: $f"; exit 1; }
done
echo ">>> .next-static OK"

echo ">>> Creating download/iptv-netlify-static.zip …"
rm -f download/iptv-netlify-static.zip

# _redirects + README بۆ Netlify — هیچ PHP ەک نایەت (Netlify فایلی PHP جێبەجێ ناکات)
cp deploy/netlify-static/_redirects .next-static/_redirects
cp deploy/netlify-static/README-NETLIFY.txt .next-static/README-NETLIFY.txt

cd .next-static && zip -qr ../download/iptv-netlify-static.zip . && cd ..
echo ">>> Done: download/iptv-netlify-static.zip"
unzip -l download/iptv-netlify-static.zip | head -8
