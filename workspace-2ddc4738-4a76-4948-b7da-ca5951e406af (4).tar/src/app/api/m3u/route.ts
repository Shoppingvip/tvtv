import { NextRequest, NextResponse } from 'next/server'
import type { M3UChannel } from '@/lib/iptv'
import { aggregateChannels, type M3uTaggedChannel } from '@/lib/m3u'

export const dynamic = 'force-dynamic'

// شیکەرەوەی M3U — خوێندنەوەی لیستی پەخشەکان و گروپکردنیان
// ?section=live یان movie — تەنها سەرچاوەکانی ئەو بەشە دەکێشرێت (بۆ شاشەی کەناڵ / فلیم بە جیا)

function groupsOf(list: M3uTaggedChannel[]) {
  const groupMap = new Map<string, number>()
  for (const c of list) groupMap.set(c.group, (groupMap.get(c.group) ?? 0) + 1)
  return Array.from(groupMap.entries())
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count)
}

export async function GET(req: NextRequest) {
  try {
    const section = req.nextUrl.searchParams.get('section')
    const { bySection, error } = await aggregateChannels()

    let list: M3uTaggedChannel[]
    if (section === 'live' || section === 'movie') {
      list = bySection[section]
    } else {
      list = bySection.all
    }

    if (list.length === 0 && error) {
      return NextResponse.json({ error }, { status: 502 })
    }
    return NextResponse.json({ groups: groupsOf(list), total: list.length })
  } catch (e) {
    const msg = e instanceof Error ? e.message : 'هەڵە لە خوێندنەوەی لیست'
    return NextResponse.json({ error: msg }, { status: 502 })
  }
}

// گەڕان بەدوای کەناڵەکان لە گروپێکدا
export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as {
      group?: string
      kind?: string
      search?: string
      limit?: number
      section?: string
    }
    const { bySection } = await aggregateChannels()

    let list: M3uTaggedChannel[]
    if (body.section === 'live' || body.section === 'movie') {
      list = bySection[body.section]
    } else if (body.kind === 'live') {
      list = bySection.live
    } else if (body.kind === 'movie') {
      list = bySection.movie
    } else {
      list = bySection.all
    }

    if (body.group && body.group !== 'all') list = list.filter((c) => c.group === body.group)
    if (body.search?.trim()) {
      const q = body.search.trim().toLowerCase()
      list = list.filter((c) => c.name.toLowerCase().includes(q))
    }

    // کورتکردنەوە بۆ شێوەی کەناڵی ئاسایی
    const channels: M3UChannel[] = list.map(({ srcSection: _s, ...ch }) => ch)
    const limit = Math.min(body.limit ?? 400, 1000)
    return NextResponse.json({ channels: channels.slice(0, limit), total: channels.length })
  } catch {
    return NextResponse.json({ error: 'هەڵەیەک ڕوویدا' }, { status: 500 })
  }
}
