// Middleware بۆ API — تەنها لە مۆدی سێرڤەر (Vercel/standalone) کار دەکات.
// دواکارییەکی preflight (OPTIONS) ی CORS وەڵام دەداتەوە بۆ ئەوەی فرۆنتی
// InfinityFree بتوانێت POST/DELETE بکات سەرێکی ئەم دۆمەینەوە.
import { NextRequest, NextResponse } from 'next/server'

const CORS: Record<string, string> = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Admin-Token',
  'Access-Control-Max-Age': '86400',
}

export function middleware(req: NextRequest) {
  if (req.method === 'OPTIONS') {
    return new NextResponse(null, { status: 204, headers: CORS })
  }
  return NextResponse.next()
}

export const config = {
  matcher: ['/api/:path*'],
}
